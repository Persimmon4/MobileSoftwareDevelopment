package com.example.myapp.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import com.example.myapp.data.entity.HabitRecordEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface HabitRecordDao {

    @Query("SELECT * FROM habit_records WHERE habit_id = :habitId ORDER BY date DESC")
    fun getRecordsByHabitId(habitId: Long): Flow<List<HabitRecordEntity>>

    @Query("SELECT * FROM habit_records WHERE habit_id = :habitId AND date = :date LIMIT 1")
    suspend fun getRecordByHabitIdAndDate(habitId: Long, date: Long): HabitRecordEntity?

    @Insert
    suspend fun insertRecord(record: HabitRecordEntity): Long

    @Delete
    suspend fun deleteRecord(record: HabitRecordEntity)

    @Query("SELECT COUNT(*) FROM habit_records WHERE habit_id = :habitId AND completed = 1")
    fun getCompletedCount(habitId: Long): Flow<Int>

    @Query("SELECT COUNT(*) FROM habit_records WHERE habit_id = :habitId AND completed = 1")
    suspend fun getCompletedCountOnce(habitId: Long): Int

    @Query("SELECT * FROM habit_records WHERE habit_id = :habitId AND completed = 1 ORDER BY date DESC LIMIT 1")
    suspend fun getLatestCompletedRecord(habitId: Long): HabitRecordEntity?

    @Query("SELECT * FROM habit_records WHERE habit_id = :habitId AND date >= :startDate ORDER BY date ASC")
    suspend fun getRecordsSince(habitId: Long, startDate: Long): List<HabitRecordEntity>
}
