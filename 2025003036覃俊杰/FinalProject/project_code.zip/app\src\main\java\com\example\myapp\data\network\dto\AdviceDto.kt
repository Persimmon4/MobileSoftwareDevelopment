package com.example.myapp.data.network.dto

import com.google.gson.annotations.SerializedName

data class AdviceResponse(
    val slip: AdviceSlip
)

data class AdviceSlip(
    val id: Int,
    val advice: String
)
