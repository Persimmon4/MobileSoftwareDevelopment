package com.example.myapp.data.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "habits")
data class HabitEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val description: String = "",
    val icon: String = "check_circle",
    @ColumnInfo(name = "color_hex") val colorHex: String = "#FF6650a4",
    @ColumnInfo(name = "created_at") val createdAt: Long = System.currentTimeMillis()
)
