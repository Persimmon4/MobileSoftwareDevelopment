package com.example.myapp.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private fun getLightColorScheme(preset: ThemePreset) = when (preset) {
    ThemePreset.APRICOT_SAGE -> lightColorScheme(
        primary = ApricotSage.LightPrimary,
        onPrimary = ApricotSage.LightOnPrimary,
        primaryContainer = ApricotSage.LightPrimaryContainer,
        onPrimaryContainer = ApricotSage.LightOnPrimaryContainer,
        secondary = ApricotSage.LightSecondary,
        onSecondary = ApricotSage.LightOnSecondary,
        background = ApricotSage.LightBackground,
        onBackground = ApricotSage.LightOnBackground,
        surface = ApricotSage.LightSurface,
        onSurface = ApricotSage.LightOnSurface,
        surfaceVariant = ApricotSage.LightSurfaceVariant,
        onSurfaceVariant = ApricotSage.LightOnSurfaceVariant,
        error = ApricotSage.LightError,
        outline = ApricotSage.LightOutline
    )
    ThemePreset.COOL_GRAY -> lightColorScheme(
        primary = CoolGray.LightPrimary,
        onPrimary = CoolGray.LightOnPrimary,
        primaryContainer = CoolGray.LightPrimaryContainer,
        onPrimaryContainer = CoolGray.LightOnPrimaryContainer,
        secondary = CoolGray.LightSecondary,
        onSecondary = CoolGray.LightOnSecondary,
        background = CoolGray.LightBackground,
        onBackground = CoolGray.LightOnBackground,
        surface = CoolGray.LightSurface,
        onSurface = CoolGray.LightOnSurface,
        surfaceVariant = CoolGray.LightSurfaceVariant,
        onSurfaceVariant = CoolGray.LightOnSurfaceVariant,
        error = CoolGray.LightError,
        outline = CoolGray.LightOutline
    )
    ThemePreset.DOPAMINE -> lightColorScheme(
        primary = Dopamine.LightPrimary,
        onPrimary = Dopamine.LightOnPrimary,
        primaryContainer = Dopamine.LightPrimaryContainer,
        onPrimaryContainer = Dopamine.LightOnPrimaryContainer,
        secondary = Dopamine.LightSecondary,
        onSecondary = Dopamine.LightOnSecondary,
        background = Dopamine.LightBackground,
        onBackground = Dopamine.LightOnBackground,
        surface = Dopamine.LightSurface,
        onSurface = Dopamine.LightOnSurface,
        surfaceVariant = Dopamine.LightSurfaceVariant,
        onSurfaceVariant = Dopamine.LightOnSurfaceVariant,
        error = Dopamine.LightError,
        outline = Dopamine.LightOutline
    )
}

private fun getDarkColorScheme(preset: ThemePreset) = when (preset) {
    ThemePreset.APRICOT_SAGE -> darkColorScheme(
        primary = ApricotSage.DarkPrimary,
        onPrimary = ApricotSage.DarkOnPrimary,
        primaryContainer = ApricotSage.DarkPrimaryContainer,
        onPrimaryContainer = ApricotSage.DarkOnPrimaryContainer,
        secondary = ApricotSage.DarkSecondary,
        onSecondary = ApricotSage.DarkOnSecondary,
        background = ApricotSage.DarkBackground,
        onBackground = ApricotSage.DarkOnBackground,
        surface = ApricotSage.DarkSurface,
        onSurface = ApricotSage.DarkOnSurface,
        surfaceVariant = ApricotSage.DarkSurfaceVariant,
        onSurfaceVariant = ApricotSage.DarkOnSurfaceVariant,
        error = ApricotSage.DarkError,
        outline = ApricotSage.DarkOutline
    )
    ThemePreset.COOL_GRAY -> darkColorScheme(
        primary = CoolGray.DarkPrimary,
        onPrimary = CoolGray.DarkOnPrimary,
        primaryContainer = CoolGray.DarkPrimaryContainer,
        onPrimaryContainer = CoolGray.DarkOnPrimaryContainer,
        secondary = CoolGray.DarkSecondary,
        onSecondary = CoolGray.DarkOnSecondary,
        background = CoolGray.DarkBackground,
        onBackground = CoolGray.DarkOnBackground,
        surface = CoolGray.DarkSurface,
        onSurface = CoolGray.DarkOnSurface,
        surfaceVariant = CoolGray.DarkSurfaceVariant,
        onSurfaceVariant = CoolGray.DarkOnSurfaceVariant,
        error = CoolGray.DarkError,
        outline = CoolGray.DarkOutline
    )
    ThemePreset.DOPAMINE -> darkColorScheme(
        primary = Dopamine.DarkPrimary,
        onPrimary = Dopamine.DarkOnPrimary,
        primaryContainer = Dopamine.DarkPrimaryContainer,
        onPrimaryContainer = Dopamine.DarkOnPrimaryContainer,
        secondary = Dopamine.DarkSecondary,
        onSecondary = Dopamine.DarkOnSecondary,
        background = Dopamine.DarkBackground,
        onBackground = Dopamine.DarkOnBackground,
        surface = Dopamine.DarkSurface,
        onSurface = Dopamine.DarkOnSurface,
        surfaceVariant = Dopamine.DarkSurfaceVariant,
        onSurfaceVariant = Dopamine.DarkOnSurfaceVariant,
        error = Dopamine.DarkError,
        outline = Dopamine.DarkOutline
    )
}

@Composable
fun MyAppTheme(
    darkTheme: Boolean = false,
    themePreset: ThemePreset = ThemePreset.APRICOT_SAGE,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) {
        getDarkColorScheme(themePreset)
    } else {
        getLightColorScheme(themePreset)
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
