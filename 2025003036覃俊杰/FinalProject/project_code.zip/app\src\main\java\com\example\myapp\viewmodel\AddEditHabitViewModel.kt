package com.example.myapp.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.myapp.data.entity.HabitEntity
import com.example.myapp.data.repository.HabitRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.Calendar

class AddEditHabitViewModel(
    private val repository: HabitRepository,
    private val habitId: Long?
) : ViewModel() {

    private val _uiState = MutableStateFlow(AddEditHabitUiState())
    val uiState: StateFlow<AddEditHabitUiState> = _uiState.asStateFlow()

    companion object {
        val HABIT_COLORS = listOf(
            "#FF6650a4", // Purple
            "#FFE91E63", // Pink
            "#FFF44336", // Red
            "#FFFF9800", // Orange
            "#FFFFEB3B", // Yellow
            "#FF4CAF50", // Green
            "#FF009688", // Teal
            "#FF2196F3", // Blue
            "#FF3F51B5", // Indigo
            "#FF607D8B"  // Blue Grey
        )

    }

    init {
        if (habitId != null && habitId > 0) {
            loadHabit(habitId)
        }
    }

    private fun loadHabit(id: Long) {
        viewModelScope.launch {
            val habit = repository.getHabitById(id)
            if (habit != null) {
                _uiState.update {
                    it.copy(
                        name = habit.name,
                        description = habit.description,
                        selectedColorHex = habit.colorHex,
                        selectedIcon = habit.icon,
                        isEditing = true,
                        existingHabit = habit
                    )
                }
            }
        }
    }

    fun updateName(name: String) {
        _uiState.update { it.copy(name = name, nameError = null) }
    }

    fun updateDescription(description: String) {
        _uiState.update { it.copy(description = description) }
    }

    fun selectColor(colorHex: String) {
        _uiState.update { it.copy(selectedColorHex = colorHex) }
    }

    fun selectIcon(icon: String) {
        _uiState.update { it.copy(selectedIcon = icon) }
    }

    fun save() {
        val state = _uiState.value
        if (state.name.isBlank()) {
            _uiState.update { it.copy(nameError = "习惯名称不能为空") }
            return
        }

        viewModelScope.launch {
            try {
                _uiState.update { it.copy(isSaving = true, nameError = null) }
                if (state.isEditing && state.existingHabit != null) {
                    repository.updateHabit(
                        state.existingHabit.copy(
                            name = state.name.trim(),
                            description = state.description.trim(),
                            colorHex = state.selectedColorHex,
                            icon = state.selectedIcon
                        )
                    )
                } else {
                    repository.insertHabit(
                        HabitEntity(
                            name = state.name.trim(),
                            description = state.description.trim(),
                            colorHex = state.selectedColorHex,
                            icon = state.selectedIcon
                        )
                    )
                }
                _uiState.update { it.copy(isSaving = false, saveSuccess = true) }
            } catch (e: Exception) {
                android.util.Log.e("AddEditHabitVM", "保存习惯失败", e)
                _uiState.update { it.copy(isSaving = false, nameError = "保存失败，请重试") }
            }
        }
    }

    class Factory(
        private val repository: HabitRepository,
        private val habitId: Long?
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return AddEditHabitViewModel(repository, habitId) as T
        }
    }
}
