package com.example.myapp.datastore

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.myapp.ui.theme.ThemePreset
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "user_preferences")

class UserPreferencesRepository(private val context: Context) {

    private object PreferencesKeys {
        val DARK_MODE = booleanPreferencesKey("dark_mode")
        val THEME_PRESET = stringPreferencesKey("theme_preset")
        val FIRST_LAUNCH = booleanPreferencesKey("first_launch")
        val SEARCH_HISTORY = stringPreferencesKey("search_history")
    }

    val isDarkMode: Flow<Boolean> = context.dataStore.data.map { preferences ->
        preferences[PreferencesKeys.DARK_MODE] ?: false
    }

    val themePreset: Flow<ThemePreset> = context.dataStore.data.map { preferences ->
        val raw = preferences[PreferencesKeys.THEME_PRESET] ?: ""
        try { ThemePreset.valueOf(raw) } catch (_: Exception) { ThemePreset.APRICOT_SAGE }
    }

    val isFirstLaunch: Flow<Boolean> = context.dataStore.data.map { preferences ->
        preferences[PreferencesKeys.FIRST_LAUNCH] ?: true
    }

    val searchHistory: Flow<List<String>> = context.dataStore.data.map { preferences ->
        val raw = preferences[PreferencesKeys.SEARCH_HISTORY] ?: ""
        if (raw.isBlank()) emptyList() else raw.split("|||").filter { it.isNotBlank() }
    }

    suspend fun setDarkMode(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.DARK_MODE] = enabled
        }
    }

    suspend fun setThemePreset(preset: ThemePreset) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.THEME_PRESET] = preset.name
        }
    }

    suspend fun setFirstLaunchComplete() {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.FIRST_LAUNCH] = false
        }
    }

    suspend fun addSearchQuery(query: String) {
        if (query.isBlank()) return
        context.dataStore.edit { preferences ->
            val raw = preferences[PreferencesKeys.SEARCH_HISTORY] ?: ""
            val list = (if (raw.isBlank()) emptyList() else raw.split("|||")).toMutableList()
            list.remove(query)
            list.add(0, query)
            if (list.size > 5) list.removeAt(list.lastIndex)
            preferences[PreferencesKeys.SEARCH_HISTORY] = list.joinToString("|||")
        }
    }

    suspend fun clearSearchHistory() {
        context.dataStore.edit { preferences ->
            preferences.remove(PreferencesKeys.SEARCH_HISTORY)
        }
    }
}
