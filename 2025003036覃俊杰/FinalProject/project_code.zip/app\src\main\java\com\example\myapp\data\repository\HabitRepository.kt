package com.example.myapp.data.repository

import com.example.myapp.data.dao.HabitDao
import com.example.myapp.data.dao.HabitRecordDao
import com.example.myapp.data.entity.HabitEntity
import com.example.myapp.data.entity.HabitRecordEntity
import com.example.myapp.data.network.ApiService
import kotlinx.coroutines.flow.Flow

class HabitRepository(
    private val habitDao: HabitDao,
    private val habitRecordDao: HabitRecordDao,
    private val apiService: ApiService = ApiService.create()
) {
    // ===== Habit operations =====

    val allHabits: Flow<List<HabitEntity>> = habitDao.getAllHabits()

    suspend fun getAllHabitsDirect(): List<HabitEntity> = habitDao.getAllHabitsDirect()

    suspend fun getHabitById(id: Long): HabitEntity? = habitDao.getHabitById(id)

    fun searchHabits(query: String): Flow<List<HabitEntity>> = habitDao.searchHabits(query)

    suspend fun searchHabitsDirect(query: String): List<HabitEntity> = habitDao.searchHabitsDirect(query)

    suspend fun insertHabit(habit: HabitEntity): Long = habitDao.insertHabit(habit)

    suspend fun updateHabit(habit: HabitEntity) = habitDao.updateHabit(habit)

    suspend fun deleteHabit(habit: HabitEntity) = habitDao.deleteHabit(habit)

    // ===== Record operations =====

    fun getRecordsByHabitId(habitId: Long): Flow<List<HabitRecordEntity>> =
        habitRecordDao.getRecordsByHabitId(habitId)

    suspend fun getRecordByHabitIdAndDate(habitId: Long, date: Long): HabitRecordEntity? =
        habitRecordDao.getRecordByHabitIdAndDate(habitId, date)

    suspend fun toggleRecord(habitId: Long, date: Long): Boolean {
        val existing = habitRecordDao.getRecordByHabitIdAndDate(habitId, date)
        return if (existing != null) {
            habitRecordDao.deleteRecord(existing)
            false
        } else {
            habitRecordDao.insertRecord(
                HabitRecordEntity(habitId = habitId, date = date, completed = true)
            )
            true
        }
    }

    suspend fun addRecord(record: HabitRecordEntity) = habitRecordDao.insertRecord(record)

    suspend fun deleteRecord(record: HabitRecordEntity) = habitRecordDao.deleteRecord(record)

    fun getCompletedCount(habitId: Long): Flow<Int> = habitRecordDao.getCompletedCount(habitId)

    // ===== Network =====

    suspend fun getDailyAdvice(): Result<String> {
        return try {
            val response = apiService.getRandomAdvice()
            Result.success(response.slip.advice)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ===== Streak calculation =====

    suspend fun calculateStreak(habitId: Long): Int {
        val latest = habitRecordDao.getLatestCompletedRecord(habitId) ?: return 0
        val todayStart = getTodayStart()
        val latestDate = normalizeDate(latest.date)

        // If latest record is not today or yesterday, streak is broken
        if (latestDate < todayStart - 86400000L) return 0

        var streak = 1
        var checkDate = latestDate - 86400000L
        val records = habitRecordDao.getRecordsSince(habitId, checkDate)
            .associate { normalizeDate(it.date) to it }

        while (records.containsKey(checkDate) && records[checkDate]?.completed == true) {
            streak++
            checkDate -= 86400000L
        }
        return streak
    }

    private fun getTodayStart(): Long {
        val cal = java.util.Calendar.getInstance()
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
        cal.set(java.util.Calendar.MINUTE, 0)
        cal.set(java.util.Calendar.SECOND, 0)
        cal.set(java.util.Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    private fun normalizeDate(timestamp: Long): Long {
        val cal = java.util.Calendar.getInstance().apply { timeInMillis = timestamp }
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
        cal.set(java.util.Calendar.MINUTE, 0)
        cal.set(java.util.Calendar.SECOND, 0)
        cal.set(java.util.Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }
}
