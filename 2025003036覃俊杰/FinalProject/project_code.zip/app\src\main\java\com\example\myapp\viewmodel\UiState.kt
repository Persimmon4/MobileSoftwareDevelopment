package com.example.myapp.viewmodel

import com.example.myapp.data.entity.HabitEntity
import com.example.myapp.data.entity.HabitRecordEntity
import com.example.myapp.ui.theme.ThemePreset

data class HomeUiState(
    val habits: List<HabitEntity> = emptyList(),
    val habitCompletionMap: Map<Long, Boolean> = emptyMap(),
    val habitStreakMap: Map<Long, Int> = emptyMap(),
    val dailyQuote: String = "",
    val isLoadingQuote: Boolean = false,
    val quoteError: String? = null,
    val isSearching: Boolean = false,
    val searchQuery: String = "",
    val filterMode: FilterMode = FilterMode.ALL,
    val searchSuggestions: List<String> = emptyList(),
    val totalHabitCount: Int = 0
)

enum class FilterMode { ALL, TODAY_COMPLETED, TODAY_PENDING }

data class AddEditHabitUiState(
    val name: String = "",
    val description: String = "",
    val nameError: String? = null,
    val isEditing: Boolean = false,
    val isSaving: Boolean = false,
    val saveSuccess: Boolean = false,
    val existingHabit: HabitEntity? = null,
    val selectedColorHex: String = "#FF6650a4",
    val selectedIcon: String = "check_circle"
)

data class HabitDetailUiState(
    val habit: HabitEntity? = null,
    val records: List<HabitRecordEntity> = emptyList(),
    val isTodayCompleted: Boolean = false,
    val streakCount: Int = 0,
    val totalCompleted: Int = 0,
    val isLoading: Boolean = true,
    val deleteSuccess: Boolean = false,
    val weeklyCompletion: List<Boolean> = List(7) { false },
    val weeklyLabels: List<String> = List(7) { "" },
    val weeklyRate: Float = 0f,
    val showNoteDialog: Boolean = false,
    val noteText: String = ""
)

data class SettingsUiState(
    val isDarkMode: Boolean = false,
    val themePreset: ThemePreset = ThemePreset.APRICOT_SAGE
)
