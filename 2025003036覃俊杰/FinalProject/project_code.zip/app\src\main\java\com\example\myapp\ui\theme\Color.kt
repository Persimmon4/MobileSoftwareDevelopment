package com.example.myapp.ui.theme

import androidx.compose.ui.graphics.Color

// ===== Theme Preset Enum =====
enum class ThemePreset(val label: String, val subtitle: String) {
    APRICOT_SAGE("晨间仪式感", "大地暖杏 · 鼠尾草绿"),
    COOL_GRAY("硬核生产力", "极简冷灰 · 电光蓝紫"),
    DOPAMINE("趣味多巴胺", "奶油白 · 渐变撞色")
}

// ===== 1. 大地暖杏 + 鼠尾草绿 =====
object ApricotSage {
    // Light
    val LightPrimary = Color(0xFF5B8C5B)
    val LightOnPrimary = Color(0xFFFFFFFF)
    val LightPrimaryContainer = Color(0xFFD4E8D4)
    val LightOnPrimaryContainer = Color(0xFF0E2E0E)
    val LightSecondary = Color(0xFFE8B88A)
    val LightOnSecondary = Color(0xFF3A2A1A)
    val LightBackground = Color(0xFFFFF8F0)
    val LightOnBackground = Color(0xFF1C1B1A)
    val LightSurface = Color(0xFFFFFDF5)
    val LightOnSurface = Color(0xFF1C1B1A)
    val LightSurfaceVariant = Color(0xFFF0EBE3)
    val LightOnSurfaceVariant = Color(0xFF4A4640)
    val LightError = Color(0xFFBA1A1A)
    val LightOutline = Color(0xFF7A766F)

    // Dark
    val DarkPrimary = Color(0xFF8FBC8F)
    val DarkOnPrimary = Color(0xFF1B3D1B)
    val DarkPrimaryContainer = Color(0xFF2D5A2D)
    val DarkOnPrimaryContainer = Color(0xFFD4E8D4)
    val DarkSecondary = Color(0xFFFFDAB9)
    val DarkOnSecondary = Color(0xFF3A2A1A)
    val DarkBackground = Color(0xFF1A1410)
    val DarkOnBackground = Color(0xFFE8E1DA)
    val DarkSurface = Color(0xFF241F1A)
    val DarkOnSurface = Color(0xFFE8E1DA)
    val DarkSurfaceVariant = Color(0xFF3A342C)
    val DarkOnSurfaceVariant = Color(0xFFCEC4B8)
    val DarkError = Color(0xFFFFB4AB)
    val DarkOutline = Color(0xFF988E83)
}

// ===== 2. 极简冷灰 + 电光蓝紫 =====
object CoolGray {
    val LightPrimary = Color(0xFF6C63FF)
    val LightOnPrimary = Color(0xFFFFFFFF)
    val LightPrimaryContainer = Color(0xFFDEDBFF)
    val LightOnPrimaryContainer = Color(0xFF120B5E)
    val LightSecondary = Color(0xFFA8B4C6)
    val LightOnSecondary = Color(0xFF1A1F28)
    val LightBackground = Color(0xFFF2F4F7)
    val LightOnBackground = Color(0xFF1A1B1E)
    val LightSurface = Color(0xFFFFFFFF)
    val LightOnSurface = Color(0xFF1A1B1E)
    val LightSurfaceVariant = Color(0xFFE8ECF1)
    val LightOnSurfaceVariant = Color(0xFF44474E)
    val LightError = Color(0xFFBA1A1A)
    val LightOutline = Color(0xFF74777F)

    val DarkPrimary = Color(0xFF8B83FF)
    val DarkOnPrimary = Color(0xFF1A1654)
    val DarkPrimaryContainer = Color(0xFF3A35A0)
    val DarkOnPrimaryContainer = Color(0xFFDEDBFF)
    val DarkSecondary = Color(0xFF8E9AAB)
    val DarkOnSecondary = Color(0xFF1A1F28)
    val DarkBackground = Color(0xFF111318)
    val DarkOnBackground = Color(0xFFE2E2E6)
    val DarkSurface = Color(0xFF1C1E24)
    val DarkOnSurface = Color(0xFFE2E2E6)
    val DarkSurfaceVariant = Color(0xFF2C2F38)
    val DarkOnSurfaceVariant = Color(0xFFC4C6CF)
    val DarkError = Color(0xFFFFB4AB)
    val DarkOutline = Color(0xFF8E9099)
}

// ===== 3. 奶油白 + 渐变撞色 =====
object Dopamine {
    val LightPrimary = Color(0xFFFF6B9D)
    val LightOnPrimary = Color(0xFFFFFFFF)
    val LightPrimaryContainer = Color(0xFFFFD9E4)
    val LightOnPrimaryContainer = Color(0xFF3D0020)
    val LightSecondary = Color(0xFFFF8C69)
    val LightOnSecondary = Color(0xFF3A1A0F)
    val LightBackground = Color(0xFFFFFDF5)
    val LightOnBackground = Color(0xFF1C1B1A)
    val LightSurface = Color(0xFFFFFFFF)
    val LightOnSurface = Color(0xFF1C1B1A)
    val LightSurfaceVariant = Color(0xFFFFF0E8)
    val LightOnSurfaceVariant = Color(0xFF4F4440)
    val LightError = Color(0xFFBA1A1A)
    val LightOutline = Color(0xFF81736E)

    val DarkPrimary = Color(0xFFFF85AC)
    val DarkOnPrimary = Color(0xFF3D0020)
    val DarkPrimaryContainer = Color(0xFF8B0048)
    val DarkOnPrimaryContainer = Color(0xFFFFD9E4)
    val DarkSecondary = Color(0xFFFF9E7A)
    val DarkOnSecondary = Color(0xFF3A1A0F)
    val DarkBackground = Color(0xFF1A1412)
    val DarkOnBackground = Color(0xFFE9DDD8)
    val DarkSurface = Color(0xFF241F1C)
    val DarkOnSurface = Color(0xFFE9DDD8)
    val DarkSurfaceVariant = Color(0xFF372C28)
    val DarkOnSurfaceVariant = Color(0xFFD1C0BA)
    val DarkError = Color(0xFFFFB4AB)
    val DarkOutline = Color(0xFF9A8A84)
}
