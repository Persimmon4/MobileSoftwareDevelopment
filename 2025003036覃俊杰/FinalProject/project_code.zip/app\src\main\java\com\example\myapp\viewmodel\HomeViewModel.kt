package com.example.myapp.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.myapp.data.entity.HabitEntity
import com.example.myapp.data.repository.HabitRepository
import com.example.myapp.datastore.UserPreferencesRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class HomeViewModel(
    private val repository: HabitRepository,
    private val preferencesRepository: UserPreferencesRepository? = null
) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    init {
        loadDailyQuote()
        loadSearchHistory()
        loadHabitsFromDb()
    }

    private fun loadSearchHistory() {
        viewModelScope.launch {
            preferencesRepository?.searchHistory?.collect { suggestions ->
                _uiState.update { it.copy(searchSuggestions = suggestions) }
            }
        }
    }

    fun refresh() {
        loadHabitsFromDb()
    }

    fun loadHabitsFromDb() {
        viewModelScope.launch {
            try {
                val habits = withContext(Dispatchers.IO) {
                    repository.getAllHabitsDirect()
                }
                val today = getTodayStart()
                val completionMap = mutableMapOf<Long, Boolean>()
                val streakMap = mutableMapOf<Long, Int>()

                habits.forEach { habit ->
                    val record = withContext(Dispatchers.IO) {
                        repository.getRecordByHabitIdAndDate(habit.id, today)
                    }
                    completionMap[habit.id] = record != null
                    streakMap[habit.id] = withContext(Dispatchers.IO) {
                        repository.calculateStreak(habit.id)
                    }
                }

                val filtered = applyFilter(habits, completionMap)
                _uiState.update { current ->
                    current.copy(
                        habits = filtered,
                        habitCompletionMap = completionMap,
                        habitStreakMap = streakMap,
                        totalHabitCount = habits.size
                    )
                }
            } catch (e: Exception) {
                android.util.Log.e("HomeVM", "加载习惯失败", e)
            }
        }
    }

    private fun applyFilter(
        habits: List<HabitEntity>,
        completionMap: Map<Long, Boolean>
    ): List<HabitEntity> {
        return when (_uiState.value.filterMode) {
            FilterMode.ALL -> habits
            FilterMode.TODAY_COMPLETED -> habits.filter { completionMap[it.id] == true }
            FilterMode.TODAY_PENDING -> habits.filter { completionMap[it.id] != true }
        }
    }

    fun setFilterMode(mode: FilterMode) {
        _uiState.update { it.copy(filterMode = mode) }
        loadHabitsFromDb()
    }

    fun loadDailyQuote() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoadingQuote = true, quoteError = null) }
            val result = withContext(Dispatchers.IO) {
                repository.getDailyAdvice()
            }
            result.fold(
                onSuccess = { advice ->
                    _uiState.update {
                        it.copy(dailyQuote = advice, isLoadingQuote = false, quoteError = null)
                    }
                },
                onFailure = { error ->
                    _uiState.update {
                        it.copy(isLoadingQuote = false, quoteError = error.message ?: "加载失败")
                    }
                }
            )
        }
    }

    fun toggleHabitCompletion(habitId: Long) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                val today = getTodayStart()
                repository.toggleRecord(habitId, today)
            }
            loadHabitsFromDb()
        }
    }

    fun deleteHabit(habitId: Long) {
        viewModelScope.launch {
            val habit = withContext(Dispatchers.IO) {
                repository.getHabitById(habitId)
            }
            if (habit != null) {
                withContext(Dispatchers.IO) {
                    repository.deleteHabit(habit)
                }
            }
            loadHabitsFromDb()
        }
    }

    fun searchHabits(query: String) {
        _uiState.update { it.copy(isSearching = query.isNotBlank(), searchQuery = query) }
        if (query.isBlank()) {
            loadHabitsFromDb()
            return
        }
        viewModelScope.launch {
            try {
                preferencesRepository?.addSearchQuery(query)
                val habits = withContext(Dispatchers.IO) {
                    repository.searchHabitsDirect(query)
                }
                val today = getTodayStart()
                val completionMap = mutableMapOf<Long, Boolean>()
                habits.forEach { habit ->
                    val record = withContext(Dispatchers.IO) {
                        repository.getRecordByHabitIdAndDate(habit.id, today)
                    }
                    completionMap[habit.id] = record != null
                }
                _uiState.update {
                    it.copy(habits = habits, habitCompletionMap = completionMap)
                }
            } catch (e: Exception) {
                android.util.Log.e("HomeVM", "搜索习惯失败", e)
            }
        }
    }

    private fun getTodayStart(): Long {
        val cal = java.util.Calendar.getInstance()
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
        cal.set(java.util.Calendar.MINUTE, 0)
        cal.set(java.util.Calendar.SECOND, 0)
        cal.set(java.util.Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    class Factory(
        private val repository: HabitRepository,
        private val preferencesRepository: UserPreferencesRepository? = null
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return HomeViewModel(repository, preferencesRepository) as T
        }
    }
}
