package com.example.myapp.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.myapp.data.entity.HabitRecordEntity
import com.example.myapp.data.repository.HabitRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class HabitDetailViewModel(
    private val repository: HabitRepository,
    private val habitId: Long
) : ViewModel() {

    private val _uiState = MutableStateFlow(HabitDetailUiState())
    val uiState: StateFlow<HabitDetailUiState> = _uiState.asStateFlow()

    init {
        loadHabitDetail()
    }

    private fun loadHabitDetail() {
        viewModelScope.launch {
            val habit = repository.getHabitById(habitId)
            if (habit == null) {
                _uiState.update { it.copy(isLoading = false) }
                return@launch
            }

            val today = getTodayStart()
            val todayRecord = repository.getRecordByHabitIdAndDate(habitId, today)
            val streakCount = repository.calculateStreak(habitId)

            // Set habit data first
            _uiState.update {
                it.copy(
                    habit = habit,
                    isTodayCompleted = todayRecord != null,
                    streakCount = streakCount
                )
            }

            // Collect records reactively
            repository.getRecordsByHabitId(habitId).collect { records ->
                val weekly = calculateWeeklyCompletion(records)
                _uiState.update {
                    it.copy(
                        habit = habit,
                        records = records,
                        isTodayCompleted = todayRecord != null,
                        streakCount = streakCount,
                        totalCompleted = records.count { r -> r.completed },
                        isLoading = false,
                        weeklyCompletion = weekly.first,
                        weeklyLabels = weekly.second,
                        weeklyRate = weekly.third
                    )
                }
            }
        }
    }

    fun refreshHabitInfo() {
        viewModelScope.launch {
            val habit = repository.getHabitById(habitId)
            if (habit != null) {
                val today = getTodayStart()
                val todayRecord = repository.getRecordByHabitIdAndDate(habitId, today)
                val streakCount = repository.calculateStreak(habitId)
                _uiState.update {
                    it.copy(
                        habit = habit,
                        isTodayCompleted = todayRecord != null,
                        streakCount = streakCount
                    )
                }
            }
        }
    }

    private fun calculateWeeklyCompletion(records: List<HabitRecordEntity>): Triple<List<Boolean>, List<String>, Float> {
        val cal = Calendar.getInstance()
        val dateFormat = SimpleDateFormat("M/d", Locale.getDefault())

        // Find the most recent Monday
        cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
        val mondayStart = getDayStart(cal.timeInMillis)

        val completion = mutableListOf<Boolean>()
        val labels = mutableListOf<String>()
        var completedCount = 0

        val recordMap = records
            .filter { it.date >= mondayStart }
            .associateBy { normalizeDate(it.date) }

        val tempCal = Calendar.getInstance()
        for (i in 0 until 7) {
            tempCal.timeInMillis = mondayStart + i * 86400000L
            val dayStart = getDayStart(tempCal.timeInMillis)
            val isCompleted = recordMap.containsKey(dayStart) && recordMap[dayStart]?.completed == true
            completion.add(isCompleted)
            labels.add(dateFormat.format(Date(dayStart)))
            if (isCompleted) completedCount++
        }

        val rate = if (completion.isEmpty()) 0f else completedCount.toFloat() / 7f
        return Triple(completion, labels, rate)
    }

    fun toggleTodayCompletion() {
        viewModelScope.launch {
            val today = getTodayStart()
            val isCompleted = repository.toggleRecord(habitId, today)
            _uiState.update { it.copy(isTodayCompleted = isCompleted) }
            _uiState.update { it.copy(streakCount = repository.calculateStreak(habitId)) }
        }
    }

    fun showNoteDialog() {
        _uiState.update { it.copy(showNoteDialog = true, noteText = "") }
    }

    fun dismissNoteDialog() {
        _uiState.update { it.copy(showNoteDialog = false, noteText = "") }
    }

    fun updateNoteText(text: String) {
        _uiState.update { it.copy(noteText = text) }
    }

    fun checkInWithNote() {
        viewModelScope.launch {
            val today = getTodayStart()
            val note = _uiState.value.noteText
            val existing = repository.getRecordByHabitIdAndDate(habitId, today)
            if (existing != null) {
                repository.deleteRecord(existing)
            }
            repository.addRecord(
                HabitRecordEntity(
                    habitId = habitId,
                    date = today,
                    completed = true,
                    note = note
                )
            )
            _uiState.update {
                it.copy(
                    isTodayCompleted = true,
                    showNoteDialog = false,
                    noteText = "",
                    streakCount = repository.calculateStreak(habitId)
                )
            }
        }
    }

    fun deleteHabit() {
        viewModelScope.launch {
            val habit = _uiState.value.habit ?: return@launch
            repository.deleteHabit(habit)
            _uiState.update { it.copy(deleteSuccess = true) }
        }
    }

    private fun getTodayStart(): Long = getDayStart(System.currentTimeMillis())

    private fun getDayStart(timestamp: Long): Long {
        val cal = Calendar.getInstance().apply { timeInMillis = timestamp }
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    private fun normalizeDate(timestamp: Long): Long = getDayStart(timestamp)

    class Factory(
        private val repository: HabitRepository,
        private val habitId: Long
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return HabitDetailViewModel(repository, habitId) as T
        }
    }
}
