package com.example.myapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.compose.rememberNavController
import com.example.myapp.data.database.AppDatabase
import com.example.myapp.data.repository.HabitRepository
import com.example.myapp.datastore.UserPreferencesRepository
import com.example.myapp.navigation.AppNavHost
import com.example.myapp.ui.theme.MyAppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val database = AppDatabase.getDatabase(applicationContext)
        val repository = HabitRepository(
            habitDao = database.habitDao(),
            habitRecordDao = database.habitRecordDao()
        )
        val preferencesRepository = UserPreferencesRepository(applicationContext)

        enableEdgeToEdge()
        setContent {
            val isDarkMode by preferencesRepository.isDarkMode.collectAsState(initial = false)
            val themePreset by preferencesRepository.themePreset.collectAsState(
                initial = com.example.myapp.ui.theme.ThemePreset.APRICOT_SAGE
            )

            MyAppTheme(darkTheme = isDarkMode, themePreset = themePreset) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val navController = rememberNavController()
                    AppNavHost(
                        navController = navController,
                        repository = repository,
                        preferencesRepository = preferencesRepository
                    )
                }
            }
        }
    }
}
