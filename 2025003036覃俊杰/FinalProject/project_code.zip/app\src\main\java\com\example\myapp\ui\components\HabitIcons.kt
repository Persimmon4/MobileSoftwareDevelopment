package com.example.myapp.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.Water
import androidx.compose.ui.graphics.vector.ImageVector

object HabitIcons {
    val ALL_ICONS = listOf(
        "check_circle", "favorite", "directions_run",
        "menu_book", "water_drop", "lightbulb",
        "self_improvement", "fitness_center", "brush",
        "music_note", "restaurant", "bedtime"
    )

    fun getIconForName(name: String): ImageVector {
        return when (name) {
            "favorite" -> Icons.Default.Favorite
            "directions_run" -> Icons.Default.DirectionsRun
            "menu_book" -> Icons.Default.MenuBook
            "water_drop" -> Icons.Default.Water
            "lightbulb" -> Icons.Default.Lightbulb
            "self_improvement" -> Icons.Default.SelfImprovement
            "fitness_center" -> Icons.Default.FitnessCenter
            "brush" -> Icons.Default.Brush
            "music_note" -> Icons.Default.MusicNote
            "restaurant" -> Icons.Default.Restaurant
            "bedtime" -> Icons.Default.Bedtime
            else -> Icons.Default.CheckCircle
        }
    }
}
