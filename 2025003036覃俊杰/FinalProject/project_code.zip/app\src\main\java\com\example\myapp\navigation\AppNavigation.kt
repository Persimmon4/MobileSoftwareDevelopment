package com.example.myapp.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.example.myapp.data.repository.HabitRepository
import com.example.myapp.datastore.UserPreferencesRepository
import com.example.myapp.ui.screens.AddEditHabitScreen
import com.example.myapp.ui.screens.HabitDetailScreen
import com.example.myapp.ui.screens.HomeScreen
import com.example.myapp.ui.screens.SettingsScreen

object Routes {
    const val HOME = "home"
    const val ADD_HABIT = "add_habit"
    const val EDIT_HABIT = "edit_habit/{habitId}"
    const val HABIT_DETAIL = "habit_detail/{habitId}"
    const val SETTINGS = "settings"

    fun editHabit(habitId: Long) = "edit_habit/$habitId"
    fun habitDetail(habitId: Long) = "habit_detail/$habitId"
}

@Composable
fun AppNavHost(
    navController: NavHostController,
    repository: HabitRepository,
    preferencesRepository: UserPreferencesRepository
) {
    NavHost(navController = navController, startDestination = Routes.HOME) {
        composable(Routes.HOME) {
            HomeScreen(
                repository = repository,
                preferencesRepository = preferencesRepository,
                onNavigateToAdd = { navController.navigate(Routes.ADD_HABIT) },
                onNavigateToDetail = { habitId -> navController.navigate(Routes.habitDetail(habitId)) },
                onNavigateToSettings = { navController.navigate(Routes.SETTINGS) }
            )
        }
        composable(Routes.ADD_HABIT) {
            AddEditHabitScreen(
                repository = repository,
                habitId = null,
                onNavigateBack = { navController.popBackStack() }
            )
        }
        composable(
            route = Routes.EDIT_HABIT,
            arguments = listOf(navArgument("habitId") { type = NavType.LongType })
        ) { backStackEntry ->
            val habitId = backStackEntry.arguments?.getLong("habitId") ?: return@composable
            AddEditHabitScreen(
                repository = repository,
                habitId = habitId,
                onNavigateBack = { navController.popBackStack() }
            )
        }
        composable(
            route = Routes.HABIT_DETAIL,
            arguments = listOf(navArgument("habitId") { type = NavType.LongType })
        ) { backStackEntry ->
            val habitId = backStackEntry.arguments?.getLong("habitId") ?: return@composable
            HabitDetailScreen(
                repository = repository,
                habitId = habitId,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToEdit = { navController.navigate(Routes.editHabit(habitId)) }
            )
        }
        composable(Routes.SETTINGS) {
            SettingsScreen(
                preferencesRepository = preferencesRepository,
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }
}
