package com.example.campusassistant.data.dao

import androidx.room.*
import com.example.campusassistant.data.entity.WorkoutGoal
import kotlinx.coroutines.flow.Flow

@Dao
interface GoalDao {

    @Query("SELECT * FROM workout_goals WHERE is_active = 1 ORDER BY created_at DESC")
    fun getActiveGoals(): Flow<List<WorkoutGoal>>

    @Query("SELECT * FROM workout_goals ORDER BY created_at DESC")
    fun getAllGoals(): Flow<List<WorkoutGoal>>

    @Query("SELECT * FROM workout_goals WHERE id = :id")
    suspend fun getById(id: Long): WorkoutGoal?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(goal: WorkoutGoal): Long

    @Update
    suspend fun update(goal: WorkoutGoal)

    @Delete
    suspend fun delete(goal: WorkoutGoal)
}
