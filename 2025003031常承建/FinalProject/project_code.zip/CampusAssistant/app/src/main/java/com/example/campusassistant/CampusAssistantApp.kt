package com.example.campusassistant

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache

/**
 * Application — 配置全局 Coil 图片加载器，启用磁盘缓存加速图片加载
 */
class CampusAssistantApp : Application(), ImageLoaderFactory {

    override fun newImageLoader(): ImageLoader {
        return ImageLoader.Builder(this)
            .memoryCache {
                MemoryCache.Builder(this)
                    .maxSizePercent(0.25) // 最多占应用内存的 25%
                    .build()
            }
            .diskCache {
                DiskCache.Builder()
                    .directory(cacheDir.resolve("coil_images"))
                    .maxSizePercent(0.05) // 最多占磁盘的 5%
                    .build()
            }
            .crossfade(true)
            .build()
    }
}
