package com.example.campusassistant.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.campusassistant.data.database.AppDatabase
import com.example.campusassistant.data.dao.WorkoutStats
import com.example.campusassistant.data.entity.WorkoutGoal
import com.example.campusassistant.data.entity.WorkoutRecord
import com.example.campusassistant.data.network.dto.ExerciseDto
import com.example.campusassistant.data.repository.WorkoutRepository
import com.example.campusassistant.datastore.UserPreferences
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class StatsData(
    val statsByType: List<WorkoutStats> = emptyList(),
    val totalWorkouts: Int = 0,
    val totalCalories: Int = 0,
    val totalDuration: Int = 0,
    val totalDistance: Float = 0f
)

sealed interface StatsUiState {
    data object Loading : StatsUiState
    data class Success(
        val stats: StatsData,
        val suggestions: List<ExerciseDto>,
        val goals: List<WorkoutGoal>,
        val recentRecords: List<WorkoutRecord>
    ) : StatsUiState
    data class Error(val message: String) : StatsUiState
}

class StatsViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val repository = WorkoutRepository(db.workoutDao(), db.goalDao())
    private val prefs = UserPreferences(application)

    private val _uiState = MutableStateFlow<StatsUiState>(StatsUiState.Loading)
    val uiState: StateFlow<StatsUiState> = _uiState.asStateFlow()

    val dailyCalorieGoal: StateFlow<String> = prefs.dailyCalorieGoal
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "500")

    init { loadStats() }

    // 模拟运动推荐数据（避免网络问题导致页面空白）
    private fun getMockExercises(): List<com.example.campusassistant.data.network.dto.ExerciseDto> {
        return listOf(
            com.example.campusassistant.data.network.dto.ExerciseDto(
                id = 1, name = "深蹲", description = "锻炼腿部和臀部肌肉的基础动作", category = 1
            ),
            com.example.campusassistant.data.network.dto.ExerciseDto(
                id = 2, name = "俯卧撑", description = "经典的胸部和手臂训练动作", category = 1
            ),
            com.example.campusassistant.data.network.dto.ExerciseDto(
                id = 3, name = "平板支撑", description = "核心力量训练，增强腹部稳定性", category = 1
            ),
            com.example.campusassistant.data.network.dto.ExerciseDto(
                id = 4, name = "开合跳", description = "有氧运动，快速提升心率", category = 2
            ),
            com.example.campusassistant.data.network.dto.ExerciseDto(
                id = 5, name = "波比跳", description = "全身燃脂的高效动作", category = 2
            ),
            com.example.campusassistant.data.network.dto.ExerciseDto(
                id = 6, name = "高抬腿", description = "腿部有氧训练，提升爆发力", category = 2
            )
        )
    }

    fun loadStats() {
        viewModelScope.launch {
            _uiState.value = StatsUiState.Loading
            try {
                val statsList = repository.getStatsByType()
                val totalWorkouts = statsList.sumOf { it.count }
                val totalCalories = statsList.sumOf { it.totalCalories }
                val totalDuration = statsList.sumOf { it.totalDuration }
                val totalDistance = statsList.sumOf { it.totalDistance.toDouble() }.toFloat()

                // 尝试网络请求，失败则使用模拟数据
                val suggestions = try {
                    val networkData = repository.fetchExercises()
                    if (networkData.isEmpty() || networkData.all { it.name.isBlank() }) {
                        getMockExercises()
                    } else networkData
                } catch (e: Exception) {
                    getMockExercises()
                }

                val goals = repository.getActiveGoals().first()
                val recent = repository.getRecentRecords(5).first()

                _uiState.value = StatsUiState.Success(
                    stats = StatsData(statsList, totalWorkouts, totalCalories, totalDuration, totalDistance),
                    suggestions = suggestions,
                    goals = goals,
                    recentRecords = recent
                )
            } catch (e: Exception) {
                _uiState.value = StatsUiState.Error(
                    e.message ?: "加载统计数据失败"
                )
            }
        }
    }

    // ==================== 目标管理 ====================

    fun insertGoal(goal: WorkoutGoal) {
        viewModelScope.launch {
            repository.insertGoal(goal)
            loadStats()
        }
    }

    fun updateGoal(goal: WorkoutGoal) {
        viewModelScope.launch {
            repository.updateGoal(goal)
            loadStats()
        }
    }

    fun deleteGoal(goal: WorkoutGoal) {
        viewModelScope.launch {
            repository.deleteGoal(goal)
            loadStats()
        }
    }
}
