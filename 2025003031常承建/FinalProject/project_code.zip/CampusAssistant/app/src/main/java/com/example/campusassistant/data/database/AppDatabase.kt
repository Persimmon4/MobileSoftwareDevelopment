package com.example.campusassistant.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.campusassistant.data.dao.GoalDao
import com.example.campusassistant.data.dao.WorkoutDao
import com.example.campusassistant.data.entity.WorkoutGoal
import com.example.campusassistant.data.entity.WorkoutRecord

@Database(
    entities = [WorkoutRecord::class, WorkoutGoal::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun workoutDao(): WorkoutDao
    abstract fun goalDao(): GoalDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "fittrack_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
