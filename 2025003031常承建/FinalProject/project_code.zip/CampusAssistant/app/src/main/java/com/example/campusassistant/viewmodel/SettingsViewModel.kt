package com.example.campusassistant.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.campusassistant.datastore.UserPreferences
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class SettingsViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = UserPreferences(application)

    val defaultType: StateFlow<String> = prefs.defaultType
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "跑步")

    val dailyCalorieGoal: StateFlow<String> = prefs.dailyCalorieGoal
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "500")

    fun setDefaultType(type: String) {
        viewModelScope.launch { prefs.setDefaultType(type) }
    }

    fun setDailyCalorieGoal(goal: String) {
        viewModelScope.launch { prefs.setDailyCalorieGoal(goal) }
    }
}
