package com.example.campusassistant.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.campusassistant.data.entity.WorkoutRecord
import com.example.campusassistant.viewmodel.WorkoutViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditScreen(
    recordId: Long = 0,
    onSaved: () -> Unit,
    viewModel: WorkoutViewModel = viewModel()
) {
    val defaultType by viewModel.defaultType.collectAsState()
    val existingRecord by viewModel.editingRecord.collectAsState()
    val types = listOf("跑步", "骑行", "游泳", "力量", "瑜伽", "其他")

    var exerciseName by remember { mutableStateOf(existingRecord?.exerciseName ?: "") }
    var selectedType by remember { mutableStateOf(existingRecord?.type ?: defaultType) }
    var duration by remember { mutableStateOf(existingRecord?.durationMinutes?.toString() ?: "") }
    var calories by remember { mutableStateOf(existingRecord?.calories?.toString() ?: "") }
    var distance by remember { mutableStateOf(if (existingRecord?.distanceKm ?: 0f > 0) existingRecord?.distanceKm.toString() else "") }
    var notes by remember { mutableStateOf(existingRecord?.notes ?: "") }
    var typeExpanded by remember { mutableStateOf(false) }
    var nameError by remember { mutableStateOf(false) }
    var durationError by remember { mutableStateOf(false) }
    var calorieError by remember { mutableStateOf(false) }

    // 加载已有记录
    LaunchedEffect(recordId) {
        if (recordId > 0) {
            viewModel.loadRecord(recordId)
        } else {
            viewModel.clearEditingRecord()
        }
    }

    // 当已有数据加载完成后更新表单
    LaunchedEffect(existingRecord) {
        existingRecord?.let { record ->
            exerciseName = record.exerciseName
            selectedType = record.type
            duration = record.durationMinutes.toString()
            calories = record.calories.toString()
            distance = if (record.distanceKm > 0) record.distanceKm.toString() else ""
            notes = record.notes
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (recordId == 0L) "新增运动" else "编辑运动") },
                navigationIcon = {
                    IconButton(onClick = onSaved) {
                        Icon(Icons.Default.ArrowBack, "返回")
                    }
                },
                actions = {
                    TextButton(onClick = {
                        nameError = exerciseName.isBlank()
                        durationError = duration.toIntOrNull()?.let { it <= 0 } ?: true
                        calorieError = calories.toIntOrNull()?.let { it <= 0 } ?: true

                        if (!nameError && !durationError && !calorieError) {
                            val record = WorkoutRecord(
                                id = if (recordId > 0) recordId else 0,
                                exerciseName = exerciseName.trim(),
                                type = selectedType,
                                durationMinutes = duration.toInt(),
                                calories = calories.toInt(),
                                distanceKm = distance.toFloatOrNull() ?: 0f,
                                date = existingRecord?.date ?: System.currentTimeMillis(),
                                notes = notes.trim()
                            )
                            if (recordId == 0L) viewModel.insertRecord(record)
                            else viewModel.updateRecord(record)
                            onSaved()
                        }
                    }) {
                        Text("保存")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 运动名称
            OutlinedTextField(
                value = exerciseName,
                onValueChange = { exerciseName = it; nameError = false },
                label = { Text("运动名称 *") },
                placeholder = { Text("如：晨跑5公里") },
                isError = nameError,
                supportingText = if (nameError) {{ Text("请输入运动名称") }} else null,
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            // 运动类型
            ExposedDropdownMenuBox(
                expanded = typeExpanded,
                onExpandedChange = { typeExpanded = it }
            ) {
                OutlinedTextField(
                    value = selectedType,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("运动类型") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = typeExpanded) },
                    modifier = Modifier.fillMaxWidth().menuAnchor()
                )
                ExposedDropdownMenu(
                    expanded = typeExpanded,
                    onDismissRequest = { typeExpanded = false }
                ) {
                    types.forEach { type ->
                        DropdownMenuItem(
                            text = { Text(type) },
                            onClick = { selectedType = type; typeExpanded = false }
                        )
                    }
                }
            }

            // 时长 & 卡路里
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = duration,
                    onValueChange = { duration = it; durationError = false },
                    label = { Text("时长(分钟) *") },
                    isError = durationError,
                    supportingText = if (durationError) {{ Text("请输入有效时长") }} else null,
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
                OutlinedTextField(
                    value = calories,
                    onValueChange = { calories = it; calorieError = false },
                    label = { Text("卡路里(千卡) *") },
                    isError = calorieError,
                    supportingText = if (calorieError) {{ Text("请输入有效数值") }} else null,
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
            }

            // 距离
            OutlinedTextField(
                value = distance,
                onValueChange = { distance = it },
                label = { Text("距离(公里)") },
                placeholder = { Text("选填，如：5.0") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            // 备注
            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("备注") },
                placeholder = { Text("如：今天状态不错！") },
                modifier = Modifier.fillMaxWidth().heightIn(min = 100.dp),
                maxLines = 3
            )
        }
    }
}
