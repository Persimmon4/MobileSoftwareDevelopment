package com.example.campusassistant.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.campusassistant.ui.screens.*
import com.example.campusassistant.viewmodel.WorkoutViewModel

sealed class Screen(val route: String, val label: String, val icon: @Composable () -> Unit) {
    data object Home : Screen("home", "记录", { Icon(Icons.Default.FitnessCenter, "记录") })
    data object Stats : Screen("stats", "统计", { Icon(Icons.Default.BarChart, "统计") })
    data object Settings : Screen("settings", "设置", { Icon(Icons.Default.Settings, "设置") })
    data object AddEdit : Screen("add_edit/{recordId}", "新增/编辑", { Icon(Icons.Default.Edit, "") })
}

val bottomNavItems = listOf(Screen.Home, Screen.Stats, Screen.Settings)

@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    // 全局 ViewModel，跨页面共享
    val workoutViewModel: WorkoutViewModel = viewModel()

    Scaffold(
        bottomBar = {
            if (currentRoute != Screen.AddEdit.route.replace("/{recordId}", "")) {
                NavigationBar {
                    bottomNavItems.forEach { screen ->
                        NavigationBarItem(
                            icon = screen.icon,
                            label = { Text(screen.label) },
                            selected = currentRoute == screen.route,
                            onClick = {
                                if (currentRoute != screen.route) {
                                    navController.navigate(screen.route) {
                                        popUpTo(Screen.Home.route) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Home.route) {
                HomeScreen(
                    onRecordClick = { id -> navController.navigate("add_edit/$id") },
                    onAddClick = { navController.navigate("add_edit/0") },
                    viewModel = workoutViewModel
                )
            }
            composable(Screen.Stats.route) {
                StatsScreen()
            }
            composable(Screen.Settings.route) {
                SettingsScreen()
            }
            composable(
                route = Screen.AddEdit.route,
                arguments = listOf(navArgument("recordId") { type = NavType.LongType; defaultValue = 0L })
            ) { backStackEntry ->
                val recordId = backStackEntry.arguments?.getLong("recordId") ?: 0L
                AddEditScreen(
                    recordId = recordId,
                    onSaved = { navController.popBackStack() },
                    viewModel = workoutViewModel
                )
            }
        }
    }
}
