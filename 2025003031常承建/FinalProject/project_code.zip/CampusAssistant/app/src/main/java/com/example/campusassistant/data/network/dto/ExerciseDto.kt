package com.example.campusassistant.data.network.dto

import com.google.gson.annotations.SerializedName

/** wger.de API 标准分页响应 */
data class WgerResponse<T>(
    @SerializedName("count") val count: Int = 0,
    @SerializedName("next") val next: String? = null,
    @SerializedName("previous") val previous: String? = null,
    @SerializedName("results") val results: List<T> = emptyList()
)

/** 运动项目 */
data class ExerciseDto(
    @SerializedName("id") val id: Int = 0,
    @SerializedName("name") val name: String = "",
    @SerializedName("description") val description: String = "",
    @SerializedName("category") val category: Int = 0,
    @SerializedName("muscles") val muscles: List<Int> = emptyList(),
    @SerializedName("equipment") val equipment: List<Int> = emptyList(),
    @SerializedName("language") val language: Int = 2
)

/** 运动分类 */
data class ExerciseCategoryDto(
    @SerializedName("id") val id: Int = 0,
    @SerializedName("name") val name: String = ""
)
