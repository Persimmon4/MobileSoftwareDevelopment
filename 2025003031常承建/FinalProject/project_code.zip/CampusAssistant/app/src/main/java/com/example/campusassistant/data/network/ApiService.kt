package com.example.campusassistant.data.network

import com.example.campusassistant.data.network.dto.ExerciseCategoryDto
import com.example.campusassistant.data.network.dto.ExerciseDto
import com.example.campusassistant.data.network.dto.WgerResponse
import retrofit2.http.GET
import retrofit2.http.Query

/**
 * Retrofit 网络接口 — wger.de Exercise API
 * 基础地址: https://wger.de/api/v2/  无需 API Key，免费调用
 */
interface ApiService {

    @GET("exercise/")
    suspend fun getExercises(
        @Query("language") language: Int = 2,
        @Query("limit") limit: Int = 20,
        @Query("offset") offset: Int = 0
    ): WgerResponse<ExerciseDto>

    @GET("exercise/search/")
    suspend fun searchExercises(
        @Query("term") term: String,
        @Query("language") language: Int = 2
    ): WgerResponse<ExerciseDto>

    @GET("exercisecategory/")
    suspend fun getCategories(): WgerResponse<ExerciseCategoryDto>
}
