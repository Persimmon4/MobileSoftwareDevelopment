package com.example.campusassistant.data.dao

import androidx.room.*
import com.example.campusassistant.data.entity.WorkoutRecord
import kotlinx.coroutines.flow.Flow

@Dao
interface WorkoutDao {

    @Query("SELECT * FROM workout_records ORDER BY date DESC")
    fun getAllRecords(): Flow<List<WorkoutRecord>>

    @Query("SELECT * FROM workout_records WHERE id = :id")
    suspend fun getById(id: Long): WorkoutRecord?

    @Query("SELECT * FROM workout_records WHERE type = :type ORDER BY date DESC")
    fun getByType(type: String): Flow<List<WorkoutRecord>>

    @Query("SELECT * FROM workout_records WHERE exercise_name LIKE '%' || :query || '%' OR notes LIKE '%' || :query || '%' ORDER BY date DESC")
    fun searchRecords(query: String): Flow<List<WorkoutRecord>>

    @Query(
        """SELECT type, SUM(calories) as totalCalories, SUM(duration_minutes) as totalDuration,
        SUM(distance_km) as totalDistance, COUNT(*) as count
        FROM workout_records GROUP BY type"""
    )
    suspend fun getStatsByType(): List<WorkoutStats>

    @Query("SELECT * FROM workout_records ORDER BY date DESC LIMIT :limit")
    fun getRecentRecords(limit: Int): Flow<List<WorkoutRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(record: WorkoutRecord): Long

    @Update
    suspend fun update(record: WorkoutRecord)

    @Delete
    suspend fun delete(record: WorkoutRecord)
}

/** 运动统计聚合 */
data class WorkoutStats(
    val type: String,
    val totalCalories: Int,
    val totalDuration: Int,
    val totalDistance: Float,
    val count: Int
)
