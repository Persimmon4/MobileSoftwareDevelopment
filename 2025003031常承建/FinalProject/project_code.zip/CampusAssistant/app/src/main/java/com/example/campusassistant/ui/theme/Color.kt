package com.example.campusassistant.ui.theme

import androidx.compose.ui.graphics.Color

// ========== 主色调 — 活力运动橙绿 ==========
val SportPrimary = Color(0xFF2E7D32)
val SportOnPrimary = Color(0xFFFFFFFF)
val SportPrimaryContainer = Color(0xFFA5D6A7)
val SportOnPrimaryContainer = Color(0xFF1B5E20)

val SportSecondary = Color(0xFFFF6F00)
val SportOnSecondary = Color(0xFFFFFFFF)
val SportSecondaryContainer = Color(0xFFFFE0B2)
val SportOnSecondaryContainer = Color(0xFFE65100)

val SportTertiary = Color(0xFF1565C0)
val SportOnTertiary = Color(0xFFFFFFFF)
val SportTertiaryContainer = Color(0xFFBBDEFB)
val SportOnTertiaryContainer = Color(0xFF0D47A1)

// ========== 暗黑模式配色 ==========
val DarkSportPrimary = Color(0xFF81C784)
val DarkSportOnPrimary = Color(0xFF1B5E20)
val DarkSportPrimaryContainer = Color(0xFF2E7D32)
val DarkSportOnPrimaryContainer = Color(0xFFC8E6C9)

val DarkSportSecondary = Color(0xFFFFB74D)
val DarkSportOnSecondary = Color(0xFFE65100)
val DarkSportSecondaryContainer = Color(0xFFFF6F00)
val DarkSportOnSecondaryContainer = Color(0xFFFFE0B2)

val DarkSportTertiary = Color(0xFF64B5F6)
val DarkSportOnTertiary = Color(0xFF0D47A1)
val DarkSportTertiaryContainer = Color(0xFF1565C0)
val DarkSportOnTertiaryContainer = Color(0xFFBBDEFB)

// ========== 运动类型颜色 ==========
val RunColor = Color(0xFFE53935)
val CycleColor = Color(0xFFFF6F00)
val SwimColor = Color(0xFF1565C0)
val StrengthColor = Color(0xFF6A1B9A)
val YogaColor = Color(0xFF2E7D32)
val OtherSportColor = Color(0xFF546E7A)

val CaloriesBurned = Color(0xFFFF6F00)
val DistanceTraveled = Color(0xFF1565C0)
val DurationElapsed = Color(0xFF2E7D32)
