package com.example.campusassistant.data.repository

import com.example.campusassistant.data.dao.GoalDao
import com.example.campusassistant.data.dao.WorkoutDao
import com.example.campusassistant.data.dao.WorkoutStats
import com.example.campusassistant.data.entity.WorkoutGoal
import com.example.campusassistant.data.entity.WorkoutRecord
import com.example.campusassistant.data.network.RetrofitClient
import com.example.campusassistant.data.network.dto.ExerciseDto
import kotlinx.coroutines.flow.Flow

class WorkoutRepository(
    private val workoutDao: WorkoutDao,
    private val goalDao: GoalDao
) {
    private val api = RetrofitClient.apiService

    // ==================== 网络操作 ====================

    /** 从 wger.de 获取运动推荐 */
    suspend fun fetchExercises(): List<ExerciseDto> {
        return try {
            api.getExercises(limit = 20).results
        } catch (e: Exception) {
            // 网络失败返回空列表，UI 层自行处理
            emptyList()
        }
    }

    /** 搜索运动项目 */
    suspend fun searchExercisesOnline(term: String): List<ExerciseDto> {
        return try {
            api.searchExercises(term).results
        } catch (e: Exception) {
            emptyList()
        }
    }

    // ==================== 运动记录 CRUD ====================

    fun getAllRecords(): Flow<List<WorkoutRecord>> = workoutDao.getAllRecords()
    fun getByType(type: String): Flow<List<WorkoutRecord>> = workoutDao.getByType(type)
    fun searchRecords(query: String): Flow<List<WorkoutRecord>> = workoutDao.searchRecords(query)
    fun getRecentRecords(limit: Int): Flow<List<WorkoutRecord>> = workoutDao.getRecentRecords(limit)
    suspend fun getRecordById(id: Long): WorkoutRecord? = workoutDao.getById(id)
    suspend fun getStatsByType(): List<WorkoutStats> = workoutDao.getStatsByType()
    suspend fun insertRecord(record: WorkoutRecord): Long = workoutDao.insert(record)
    suspend fun updateRecord(record: WorkoutRecord) = workoutDao.update(record)
    suspend fun deleteRecord(record: WorkoutRecord) = workoutDao.delete(record)

    // ==================== 运动目标 CRUD ====================

    fun getActiveGoals(): Flow<List<WorkoutGoal>> = goalDao.getActiveGoals()
    fun getAllGoals(): Flow<List<WorkoutGoal>> = goalDao.getAllGoals()
    suspend fun getGoalById(id: Long): WorkoutGoal? = goalDao.getById(id)
    suspend fun insertGoal(goal: WorkoutGoal): Long = goalDao.insert(goal)
    suspend fun updateGoal(goal: WorkoutGoal) = goalDao.update(goal)
    suspend fun deleteGoal(goal: WorkoutGoal) = goalDao.delete(goal)
}
