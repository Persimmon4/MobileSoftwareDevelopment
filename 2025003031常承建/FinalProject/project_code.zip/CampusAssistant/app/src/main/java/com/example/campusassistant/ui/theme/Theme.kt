package com.example.campusassistant.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LightColorScheme = lightColorScheme(
    primary = SportPrimary,
    onPrimary = SportOnPrimary,
    primaryContainer = SportPrimaryContainer,
    onPrimaryContainer = SportOnPrimaryContainer,
    secondary = SportSecondary,
    onSecondary = SportOnSecondary,
    secondaryContainer = SportSecondaryContainer,
    onSecondaryContainer = SportOnSecondaryContainer,
    tertiary = SportTertiary,
    onTertiary = SportOnTertiary,
    tertiaryContainer = SportTertiaryContainer,
    onTertiaryContainer = SportOnTertiaryContainer,
)

private val DarkColorScheme = darkColorScheme(
    primary = DarkSportPrimary,
    onPrimary = DarkSportOnPrimary,
    primaryContainer = DarkSportPrimaryContainer,
    onPrimaryContainer = DarkSportOnPrimaryContainer,
    secondary = DarkSportSecondary,
    onSecondary = DarkSportOnSecondary,
    secondaryContainer = DarkSportSecondaryContainer,
    onSecondaryContainer = DarkSportOnSecondaryContainer,
    tertiary = DarkSportTertiary,
    onTertiary = DarkSportOnTertiary,
    tertiaryContainer = DarkSportTertiaryContainer,
    onTertiaryContainer = DarkSportOnTertiaryContainer,
)

@Composable
fun CampusAssistantTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as androidx.activity.ComponentActivity).window
            window.statusBarColor = colorScheme.primary.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = FitTrackTypography,
        content = content
    )
}
