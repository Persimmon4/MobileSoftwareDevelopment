package com.example.campusassistant.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.campusassistant.data.database.AppDatabase
import com.example.campusassistant.data.entity.WorkoutRecord
import com.example.campusassistant.data.network.dto.ExerciseDto
import com.example.campusassistant.data.repository.WorkoutRepository
import com.example.campusassistant.datastore.UserPreferences
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

sealed interface ExerciseUiState {
    data object Idle : ExerciseUiState
    data object Loading : ExerciseUiState
    data class Success(val exercises: List<ExerciseDto>) : ExerciseUiState
    data class Error(val message: String) : ExerciseUiState
}

class WorkoutViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val repository = WorkoutRepository(db.workoutDao(), db.goalDao())
    private val prefs = UserPreferences(application)

    private val _records = MutableStateFlow<List<WorkoutRecord>>(emptyList())
    val records: StateFlow<List<WorkoutRecord>> = _records.asStateFlow()

    private val _editingRecord = MutableStateFlow<WorkoutRecord?>(null)
    val editingRecord: StateFlow<WorkoutRecord?> = _editingRecord.asStateFlow()

    private val _filterType = MutableStateFlow("全部")
    val filterType: StateFlow<String> = _filterType.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _exerciseState = MutableStateFlow<ExerciseUiState>(ExerciseUiState.Idle)
    val exerciseState: StateFlow<ExerciseUiState> = _exerciseState.asStateFlow()

    val defaultType: StateFlow<String> = prefs.defaultType
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "跑步")

    init { loadRecords() }

    fun loadRecords() {
        viewModelScope.launch {
            val query = _searchQuery.value
            val type = _filterType.value
            val flow = when {
                query.isNotBlank() -> repository.searchRecords(query)
                type != "全部" -> repository.getByType(type)
                else -> repository.getAllRecords()
            }
            flow.collect { _records.value = it }
        }
    }

    fun setFilterType(type: String) { _filterType.value = type; loadRecords() }
    fun setSearchQuery(query: String) { _searchQuery.value = query; loadRecords() }

    fun loadRecord(id: Long) {
        viewModelScope.launch {
            _editingRecord.value = repository.getRecordById(id)
        }
    }

    fun clearEditingRecord() {
        _editingRecord.value = null
    }

    // ==================== CRUD ====================

    fun insertRecord(record: WorkoutRecord) {
        viewModelScope.launch { repository.insertRecord(record) }
    }

    fun updateRecord(record: WorkoutRecord) {
        viewModelScope.launch { repository.updateRecord(record) }
    }

    fun deleteRecord(record: WorkoutRecord) {
        viewModelScope.launch { repository.deleteRecord(record) }
    }

    // ==================== 网络 ====================

    fun fetchExercises() {
        viewModelScope.launch {
            _exerciseState.value = ExerciseUiState.Loading
            try {
                val exercises = repository.fetchExercises()
                _exerciseState.value = if (exercises.isEmpty())
                    ExerciseUiState.Error("未获取到运动推荐，请检查网络连接")
                else
                    ExerciseUiState.Success(exercises)
            } catch (e: Exception) {
                _exerciseState.value = ExerciseUiState.Error(e.message ?: "网络请求失败")
            }
        }
    }
}
