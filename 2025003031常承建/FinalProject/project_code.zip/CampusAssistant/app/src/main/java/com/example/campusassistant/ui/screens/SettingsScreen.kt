package com.example.campusassistant.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.campusassistant.ui.theme.*
import com.example.campusassistant.viewmodel.SettingsViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(viewModel: SettingsViewModel = viewModel()) {
    val defaultType by viewModel.defaultType.collectAsState()
    val dailyCalorieGoal by viewModel.dailyCalorieGoal.collectAsState()
    val types = listOf("跑步", "骑行", "游泳", "力量", "瑜伽", "其他")

    var showTypeMenu by remember { mutableStateOf(false) }
    var calorieText by remember { mutableStateOf(dailyCalorieGoal) }

    Scaffold(
        topBar = {
            TopAppBar(title = {
                Text("⚙️ 设置", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            })
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // ── 默认运动类型 ──
            SectionCard(icon = Icons.Default.FitnessCenter, title = "默认运动类型", subtitle = "新增运动记录时自动选择此类型") {
                Spacer(Modifier.height(10.dp))
                ExposedDropdownMenuBox(
                    expanded = showTypeMenu,
                    onExpandedChange = { showTypeMenu = it }
                ) {
                    OutlinedTextField(
                        value = defaultType,
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = showTypeMenu) },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().menuAnchor()
                    )
                    ExposedDropdownMenu(
                        expanded = showTypeMenu,
                        onDismissRequest = { showTypeMenu = false }
                    ) {
                        types.forEach { type ->
                            DropdownMenuItem(
                                text = { Text(type) },
                                onClick = { viewModel.setDefaultType(type); showTypeMenu = false },
                                leadingIcon = {
                                    val color = when(type) {
                                        "跑步" -> RunColor; "骑行" -> CycleColor; "游泳" -> SwimColor
                                        "力量" -> StrengthColor; "瑜伽" -> YogaColor; else -> OtherSportColor
                                    }
                                    Box(Modifier.size(10.dp).clip(CircleShape).background(color))
                                }
                            )
                        }
                    }
                }
            }

            // ── 每日卡路里目标 ──
            SectionCard(icon = Icons.Default.LocalFireDepartment, title = "每日卡路里目标", subtitle = "设定每日运动的卡路里消耗目标（100-5000千卡）") {
                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = calorieText,
                        onValueChange = { calorieText = it },
                        label = { Text("目标值") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        suffix = { Text("千卡") },
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = {
                            val goal = calorieText.toIntOrNull()
                            if (goal != null && goal in 100..5000) {
                                viewModel.setDailyCalorieGoal(calorieText)
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 14.dp)
                    ) {
                        Text("保存")
                    }
                }
                // 快捷按钮
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("300", "500", "800", "1000").forEach { value ->
                        FilterChip(
                            selected = calorieText == value,
                            onClick = { calorieText = value },
                            label = { Text(value) }
                        )
                    }
                }
            }

            // ── 关于 ──
            SectionCard(icon = Icons.Default.Info, title = "关于", subtitle = null) {
                Spacer(Modifier.height(4.dp))
                Text("运动记录 v1.0", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                Text(
                    "Jetpack Compose + Material 3 + Room + DataStore",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    "运动推荐数据来源：wger.de 开放 API",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(Modifier.height(80.dp))
        }
    }
}

@Composable
private fun SectionCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String?,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, null, Modifier.size(20.dp), tint = MaterialTheme.colorScheme.primary)
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    if (subtitle != null) {
                        Text(subtitle, style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            content()
        }
    }
}
