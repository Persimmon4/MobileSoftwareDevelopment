package com.example.campusassistant.data.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "workout_goals")
data class WorkoutGoal(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    @ColumnInfo(name = "title") val title: String,
    @ColumnInfo(name = "goal_type") val goalType: String,
    @ColumnInfo(name = "target_value") val targetValue: Float,
    @ColumnInfo(name = "current_value") val currentValue: Float = 0f,
    @ColumnInfo(name = "is_active") val isActive: Boolean = true,
    @ColumnInfo(name = "created_at") val createdAt: Long = System.currentTimeMillis()
)
