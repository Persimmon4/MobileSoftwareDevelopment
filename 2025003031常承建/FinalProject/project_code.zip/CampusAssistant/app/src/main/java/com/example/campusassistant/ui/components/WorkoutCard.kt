package com.example.campusassistant.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.campusassistant.data.entity.WorkoutRecord
import com.example.campusassistant.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

fun getTypeIconAndColor(type: String): Pair<@Composable () -> Unit, Color> {
    return when (type) {
        "跑步" -> Pair({ Icon(Icons.Default.DirectionsRun, null, tint = Color.White) }, RunColor)
        "骑行" -> Pair({ Icon(Icons.Default.DirectionsBike, null, tint = Color.White) }, CycleColor)
        "游泳" -> Pair({ Icon(Icons.Default.Pool, null, tint = Color.White) }, SwimColor)
        "力量" -> Pair({ Icon(Icons.Default.FitnessCenter, null, tint = Color.White) }, StrengthColor)
        "瑜伽" -> Pair({ Icon(Icons.Default.SelfImprovement, null, tint = Color.White) }, YogaColor)
        else -> Pair({ Icon(Icons.Default.SportsHandball, null, tint = Color.White) }, OtherSportColor)
    }
}

@Composable
fun WorkoutCard(
    record: WorkoutRecord,
    onClick: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    val (icon, accentColor) = getTypeIconAndColor(record.type)
    val dateFormat = remember { SimpleDateFormat("MM/dd HH:mm", Locale.getDefault()) }

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        onClick = onClick
    ) {
        Row(
            modifier = Modifier.padding(14.dp).height(76.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // 左侧彩色圆形图标
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(accentColor),
                contentAlignment = Alignment.Center
            ) {
                icon()
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = record.exerciseName,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.height(22.dp)
                ) {
                    // 时长
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Timer, null, Modifier.size(13.dp), tint = DurationElapsed)
                        Spacer(Modifier.width(3.dp))
                        Text("${record.durationMinutes}分钟", style = MaterialTheme.typography.labelSmall, color = DurationElapsed, maxLines = 1)
                    }
                    // 卡路里
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.LocalFireDepartment, null, Modifier.size(13.dp), tint = CaloriesBurned)
                        Spacer(Modifier.width(3.dp))
                        Text("${record.calories}千卡", style = MaterialTheme.typography.labelSmall, color = CaloriesBurned, maxLines = 1)
                    }
                    // 距离
                    if (record.distanceKm > 0f) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Straighten, null, Modifier.size(13.dp), tint = DistanceTraveled)
                            Spacer(Modifier.width(3.dp))
                            Text("${record.distanceKm}km", style = MaterialTheme.typography.labelSmall, color = DistanceTraveled, maxLines = 1)
                        }
                    }
                }

                // 日期
                Text(
                    text = dateFormat.format(Date(record.date)),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.outline
                )
            }

            Spacer(Modifier.width(4.dp))
            IconButton(
                onClick = onDelete,
                modifier = Modifier.size(32.dp)
            ) {
                Icon(
                    Icons.Default.DeleteOutline,
                    contentDescription = "删除",
                    tint = MaterialTheme.colorScheme.error.copy(alpha = 0.5f),
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
fun StatChip(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String, color: Color) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(color.copy(alpha = 0.1f))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Icon(icon, null, Modifier.size(14.dp), tint = color)
        Spacer(Modifier.width(4.dp))
        Text(text, style = MaterialTheme.typography.labelSmall, color = color)
    }
}
