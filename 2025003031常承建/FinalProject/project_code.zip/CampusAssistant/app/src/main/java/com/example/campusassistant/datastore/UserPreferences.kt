package com.example.campusassistant.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "fittrack_settings")

class UserPreferences(private val context: Context) {

    companion object {
        private val KEY_DEFAULT_TYPE = stringPreferencesKey("default_type")
        private val KEY_DAILY_GOAL = stringPreferencesKey("daily_calorie_goal")
        private val KEY_IS_FIRST_LAUNCH = booleanPreferencesKey("is_first_launch")
    }

    /** 默认运动类型 */
    val defaultType: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_DEFAULT_TYPE] ?: "跑步"
    }

    suspend fun setDefaultType(type: String) {
        context.dataStore.edit { prefs -> prefs[KEY_DEFAULT_TYPE] = type }
    }

    /** 每日卡路里目标 */
    val dailyCalorieGoal: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[KEY_DAILY_GOAL] ?: "500"
    }

    suspend fun setDailyCalorieGoal(goal: String) {
        context.dataStore.edit { prefs -> prefs[KEY_DAILY_GOAL] = goal }
    }

    /** 是否首次启动 */
    val isFirstLaunch: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_IS_FIRST_LAUNCH] ?: true
    }

    suspend fun setFirstLaunchDone() {
        context.dataStore.edit { prefs -> prefs[KEY_IS_FIRST_LAUNCH] = false }
    }
}
