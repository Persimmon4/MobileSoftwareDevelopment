package com.example.campusassistant.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.campusassistant.ui.components.*
import com.example.campusassistant.ui.theme.*
import com.example.campusassistant.viewmodel.StatsUiState
import com.example.campusassistant.viewmodel.StatsViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StatsScreen(viewModel: StatsViewModel = viewModel()) {
    val uiState by viewModel.uiState.collectAsState()
    val calorieGoal by viewModel.dailyCalorieGoal.collectAsState()

    LaunchedEffect(Unit) { viewModel.loadStats() }

    Scaffold(
        topBar = {
            TopAppBar(title = {
                Text("📊 运动统计", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            })
        }
    ) { padding ->
        when (val state = uiState) {
            is StatsUiState.Loading -> LoadingView(Modifier.padding(padding))
            is StatsUiState.Error -> ErrorView(
                message = state.message,
                onRetry = { viewModel.loadStats() },
                modifier = Modifier.padding(padding)
            )
            is StatsUiState.Success -> {
                LazyColumn(
                    modifier = Modifier.padding(padding),
                    contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 6.dp, bottom = 88.dp),
                    verticalArrangement = Arrangement.spacedBy(18.dp)
                ) {
                    // ── 统计卡片 ──
                    item {
                        StatsGrid(
                            items = listOf(
                                StatItem("运动次数", "${state.stats.totalWorkouts}",
                                    { Icon(Icons.Default.FitnessCenter, null, tint = SportPrimary) }),
                                StatItem("总卡路里", "${state.stats.totalCalories}",
                                    { Icon(Icons.Default.LocalFireDepartment, null, tint = CaloriesBurned) }),
                                StatItem("总时长(分)", "${state.stats.totalDuration}",
                                    { Icon(Icons.Default.Timer, null, tint = DurationElapsed) }),
                                StatItem("总距离(km)", "${"%.1f".format(state.stats.totalDistance)}",
                                    { Icon(Icons.Default.Straighten, null, tint = DistanceTraveled) })
                            )
                        )
                    }

                    // ── 每日目标 ──
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                        ) {
                            Column(modifier = Modifier.padding(18.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.TrackChanges, null, Modifier.size(20.dp), tint = CaloriesBurned)
                                    Spacer(Modifier.width(8.dp))
                                    Text("每日卡路里目标", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                }
                                Spacer(Modifier.height(14.dp))
                                val goalValue = calorieGoal.toFloatOrNull() ?: 500f
                                val progress = if (goalValue > 0) (state.stats.totalCalories / goalValue).coerceIn(0f, 1f) else 0f
                                LinearProgressIndicator(
                                    progress = { progress },
                                    modifier = Modifier.fillMaxWidth().height(14.dp).clip(RoundedCornerShape(7.dp)),
                                    color = CaloriesBurned,
                                    trackColor = CaloriesBurned.copy(alpha = 0.12f),
                                )
                                Spacer(Modifier.height(8.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(
                                        "${state.stats.totalCalories} / ${goalValue.toInt()} 千卡",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Text(
                                        "${(progress * 100).toInt()}%",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = if (progress >= 1f) SportPrimary else CaloriesBurned
                                    )
                                }
                            }
                        }
                    }

                    // ── 分类统计 ──
                    if (state.stats.statsByType.isNotEmpty()) {
                        item {
                            SectionHeader("分类统计")
                        }
                        items(state.stats.statsByType) { stat ->
                            val (_, color) = getTypeIconAndColor(stat.type)
                            CategoryStatCard(stat.type, stat.count, stat.totalCalories, stat.totalDuration, stat.totalDistance, color)
                        }
                    }

                    // ── 运动推荐 ──
                    if (state.suggestions.isNotEmpty()) {
                        item { SectionHeader("运动推荐") }
                        items(state.suggestions.take(6)) { exercise ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp),
                                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(CircleShape)
                                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.Star, null, Modifier.size(20.dp),
                                            tint = MaterialTheme.colorScheme.primary)
                                    }
                                    Spacer(Modifier.width(12.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(exercise.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                        if (exercise.description.isNotBlank()) {
                                            Spacer(Modifier.height(2.dp))
                                            Text(
                                                exercise.description.take(80) + if (exercise.description.length > 80) "…" else "",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // ── 最近记录 ──
                    if (state.recentRecords.isNotEmpty()) {
                        item { SectionHeader("最近记录") }
                        items(state.recentRecords, key = { it.id }) { record ->
                            val (_, color) = getTypeIconAndColor(record.type)
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp),
                                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(CircleShape)
                                            .background(color.copy(alpha = 0.15f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.FitnessCenter, null, Modifier.size(20.dp), tint = color)
                                    }
                                    Spacer(Modifier.width(12.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(record.exerciseName, fontWeight = FontWeight.Bold)
                                        Row {
                                            Text("${record.durationMinutes}分钟", style = MaterialTheme.typography.bodySmall, color = DurationElapsed)
                                            Spacer(Modifier.width(8.dp))
                                            Text("${record.calories}千卡", style = MaterialTheme.typography.bodySmall, color = CaloriesBurned)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(top = 4.dp, bottom = 2.dp)
    )
}

@Composable
private fun CategoryStatCard(
    type: String, count: Int, calories: Int, duration: Int, distance: Float, color: androidx.compose.ui.graphics.Color
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.06f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.size(42.dp).clip(CircleShape).background(color),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.FitnessCenter, null, Modifier.size(22.dp), tint = androidx.compose.ui.graphics.Color.White)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(type, fontWeight = FontWeight.Bold)
                Text("${count}次 · ${calories}千卡 · ${duration}分钟 · ${"%.1f".format(distance)}km",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
