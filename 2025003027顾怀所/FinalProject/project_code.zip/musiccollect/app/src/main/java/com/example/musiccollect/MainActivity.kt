package com.example.musiccollect

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.rememberNavController
import com.example.musiccollect.data.network.ApiService
import com.example.musiccollect.data.network.NetworkRepository
import com.example.musiccollect.navigation.AppNavigation
import com.example.musiccollect.ui.theme.MusiccollectTheme
import com.example.musiccollect.viewmodel.MainViewModel
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MusiccollectTheme {
                AppRoot()
            }
        }
    }
}

// 使用真实 API
fun provideRetrofit(): Retrofit {
    return Retrofit.Builder()
        .baseUrl("https://api.apiopen.top/")
        .addConverterFactory(GsonConverterFactory.create())
        .build()
}

fun provideApi(): ApiService = provideRetrofit().create(ApiService::class.java)
fun provideNetRepo(): NetworkRepository = NetworkRepository(provideApi())

@Composable
fun AppRoot() {
    val navCtrl = rememberNavController()
    val appCtx = LocalContext.current.applicationContext

    // 创建 Factory
    val factory = MainViewModelFactory(provideNetRepo(), appCtx)

    // 获取 ViewModel
    val viewModel: MainViewModel = viewModel(factory = factory)

    // 将 ViewModel 传递给 AppNavigation
    AppNavigation(
        navCtrl = navCtrl,
        viewModelFactory = factory,
        viewModel = viewModel
    )
}