package com.example.musiccollect.viewmodel

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.musiccollect.data.database.AppDatabase
import com.example.musiccollect.data.network.NetworkRepository
import com.example.musiccollect.data.network.dto.MusicDto
import com.example.musiccollect.data.entity.PlaylistEntity
import com.example.musiccollect.data.entity.SongEntity
import com.example.musiccollect.datastore.UserPrefRepo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(context: Context, private val netRepo: NetworkRepository) : ViewModel() {
    private val db = AppDatabase.getInstance(context)
    private val playlistDao = db.playlistDao()
    private val songDao = db.songDao()
    private val prefRepo = UserPrefRepo(context)

    // ---------- 登录状态 ----------
    private val _isLoggedIn = MutableStateFlow(false)
    val isLoggedIn = _isLoggedIn.asStateFlow()

    private val _userName = MutableStateFlow("")
    val userName = _userName.asStateFlow()

    // ---------- 歌单状态 ----------
    private val _playlistUiState = MutableStateFlow(PlaylistUiState())
    val playlistUiState = _playlistUiState.asStateFlow()

    // 排序选项
    enum class SortOption {
        CREATE_TIME_DESC,
        CREATE_TIME_ASC,
        NAME_ASC,
        NAME_DESC,
        SONG_COUNT_DESC
    }

    private var currentSort = SortOption.CREATE_TIME_DESC

    fun setSortOption(option: SortOption) {
        currentSort = option
        // 重新排序当前数据
        val currentList = (_playlistUiState.value.listState as? UiState.Success)?.data ?: emptyList()
        val sorted = sortPlaylist(currentList, option)
        _playlistUiState.value = _playlistUiState.value.copy(
            listState = if (sorted.isEmpty()) UiState.Empty else UiState.Success(sorted)
        )
    }

    private fun sortPlaylist(list: List<PlaylistEntity>, option: SortOption): List<PlaylistEntity> {
        return when (option) {
            SortOption.CREATE_TIME_DESC -> list.sortedByDescending { it.createTime }
            SortOption.CREATE_TIME_ASC -> list.sortedBy { it.createTime }
            SortOption.NAME_ASC -> list.sortedBy { it.name }
            SortOption.NAME_DESC -> list.sortedByDescending { it.name }
            SortOption.SONG_COUNT_DESC -> {
                // 需要计算歌曲数量，这里暂时用 id 降序占位，实际应查询数据库，我们可以在加载时缓存数量
                // 简化为按 id 降序
                list.sortedByDescending { it.id }
            }
        }
    }

    // ---------- 网络热歌 ----------
    private val _hotMusicUiState = MutableStateFlow(HotMusicUiState())
    val hotMusicUiState = _hotMusicUiState.asStateFlow()

    // ---------- 歌曲详情 ----------
    private val _songUiState = MutableStateFlow(SongUiState())
    val songUiState = _songUiState.asStateFlow()

    // ---------- 当前播放 ----------
    private val _currentSong = MutableStateFlow<SongEntity?>(null)
    val currentSong = _currentSong.asStateFlow()

    // ---------- 收藏状态 ----------
    private val _favoriteSongsState = MutableStateFlow<UiState<List<SongEntity>>>(UiState.Loading)
    val favoriteSongsState = _favoriteSongsState.asStateFlow()

    // ---------- 最近播放状态 ----------
    private val _recentSongsState = MutableStateFlow<UiState<List<SongEntity>>>(UiState.Loading)
    val recentSongsState = _recentSongsState.asStateFlow()

    // ---------- 设置 ----------
    val settingUiState = prefRepo.darkModeFlow
        .map { SettingUiState(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), SettingUiState())

    init {
        checkLoginStatus()
        loadDarkMode()
        loadUserName()
    }

    // ========== 登录相关 ==========
    private fun checkLoginStatus() {
        viewModelScope.launch(Dispatchers.IO) {
            val loggedIn = prefRepo.getLoginStatus()
            withContext(Dispatchers.Main) {
                _isLoggedIn.value = loggedIn
                if (loggedIn) loadAllPlaylist()
            }
        }
    }

    private fun loadUserName() {
        viewModelScope.launch(Dispatchers.IO) {
            prefRepo.getUserNameFlow().collect { name ->
                _userName.value = name
            }
        }
    }

    fun updateUserName(newName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            prefRepo.saveUserName(newName)
        }
    }

    fun login(username: String, password: String, callback: (Boolean, String?) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            if (username.isBlank() || password.isBlank()) {
                withContext(Dispatchers.Main) { callback(false, "用户名和密码不能为空") }
                return@launch
            }
            if (password.length < 3) {
                withContext(Dispatchers.Main) { callback(false, "密码长度不能少于3位") }
                return@launch
            }
            kotlinx.coroutines.delay(1000)
            prefRepo.saveLoginStatus(true)
            prefRepo.saveUserName(username)
            withContext(Dispatchers.Main) {
                _isLoggedIn.value = true
                loadAllPlaylist()
                callback(true, null)
            }
        }
    }

    fun logout(callback: (Boolean, String?) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            prefRepo.saveLoginStatus(false)
            withContext(Dispatchers.Main) {
                _isLoggedIn.value = false
                callback(true, null)
            }
        }
    }

    // ========== 歌单相关 ==========
    fun loadAllPlaylist() {
        viewModelScope.launch(Dispatchers.IO) {
            playlistDao.getAllPlaylist().collect { list ->
                val sorted = sortPlaylist(list, currentSort)
                val state = if (sorted.isEmpty()) UiState.Empty else UiState.Success(sorted)
                _playlistUiState.value = _playlistUiState.value.copy(listState = state)
            }
        }
    }

    fun searchPlaylist(key: String) {
        _playlistUiState.value = _playlistUiState.value.copy(searchText = key)
        viewModelScope.launch(Dispatchers.IO) {
            if (key.isEmpty()) {
                playlistDao.getAllPlaylist().collect { list ->
                    val sorted = sortPlaylist(list, currentSort)
                    val state = if (sorted.isEmpty()) UiState.Empty else UiState.Success(sorted)
                    _playlistUiState.value = _playlistUiState.value.copy(listState = state)
                }
            } else {
                playlistDao.searchPlaylist("%$key%").collect { list ->
                    val sorted = sortPlaylist(list, currentSort)
                    val state = if (sorted.isEmpty()) UiState.Empty else UiState.Success(sorted)
                    _playlistUiState.value = _playlistUiState.value.copy(listState = state)
                }
            }
        }
    }

    fun addPlaylist(name: String, desc: String) {
        viewModelScope.launch(Dispatchers.IO) {
            playlistDao.insert(PlaylistEntity(name = name, desc = desc))
        }
    }

    fun deletePlaylist(item: PlaylistEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            songDao.deleteAllSongInPlaylist(item.id)
            playlistDao.delete(item)
        }
    }

    // ========== 网络热歌 ==========
    fun loadHotMusic(refresh: Boolean = false) {
        if (!refresh) _hotMusicUiState.value = _hotMusicUiState.value.copy(netState = UiState.Loading)
        else _hotMusicUiState.value = _hotMusicUiState.value.copy(isRefreshing = true)
        viewModelScope.launch(Dispatchers.IO) {
            val res = netRepo.fetchHotMusic()
            withContext(Dispatchers.Main) {
                res.onSuccess { list ->
                    val state = if (list.isEmpty()) UiState.Empty else UiState.Success(list)
                    _hotMusicUiState.value = _hotMusicUiState.value.copy(netState = state, isRefreshing = false)
                }.onFailure { err ->
                    _hotMusicUiState.value = _hotMusicUiState.value.copy(
                        netState = UiState.Error(err.message ?: "未知错误"),
                        isRefreshing = false
                    )
                }
            }
        }
    }

    fun addNetSongToLocal(dto: MusicDto, playlistId: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            val song = SongEntity(
                playlistId = playlistId,
                songName = dto.name,
                singer = dto.artist,
                coverUrl = dto.picUrl,
                songUrl = dto.url,
                isFavorite = true
            )
            songDao.insert(song)
        }
    }

    // ========== 歌曲相关 ==========
    fun loadAllSongsForPlaylist(pid: Int) {
        _songUiState.value = _songUiState.value.copy(currentPlaylistId = pid)
        viewModelScope.launch(Dispatchers.IO) {
            songDao.getSongByPlaylist(pid).collect { list ->
                val state = if (list.isEmpty()) UiState.Empty else UiState.Success(list)
                _songUiState.value = _songUiState.value.copy(songList = state)
            }
        }
    }

    fun searchSongsInPlaylist(pid: Int, keyword: String) {
        _songUiState.value = _songUiState.value.copy(currentPlaylistId = pid)
        viewModelScope.launch(Dispatchers.IO) {
            if (keyword.isEmpty()) {
                songDao.getSongByPlaylist(pid).collect { list ->
                    val state = if (list.isEmpty()) UiState.Empty else UiState.Success(list)
                    _songUiState.value = _songUiState.value.copy(songList = state)
                }
            } else {
                songDao.searchSongsInPlaylist(pid, "%$keyword%").collect { list ->
                    val state = if (list.isEmpty()) UiState.Empty else UiState.Success(list)
                    _songUiState.value = _songUiState.value.copy(songList = state)
                }
            }
        }
    }

    fun deleteSong(song: SongEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            songDao.delete(song)
            val currentPid = _songUiState.value.currentPlaylistId
            if (currentPid == song.playlistId) loadAllSongsForPlaylist(currentPid)
            // 收藏列表和最近播放列表需要刷新
            loadFavoriteSongs()
            loadRecentPlaySongs()
        }
    }

    fun loadSongById(songId: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            val song = songDao.getSongById(songId)
            setCurrentPlayingSong(song)
        }
    }

    fun setCurrentPlayingSong(song: SongEntity?) {
        _currentSong.value = song
    }

    // 播放时记录最近播放时间
    fun recordSongPlayed(songId: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            songDao.updateLastPlayTime(songId, System.currentTimeMillis())
            // 更新当前歌曲的 lastPlayTime
            _currentSong.value?.let { current ->
                if (current.songId == songId) {
                    _currentSong.value = current.copy(lastPlayTime = System.currentTimeMillis())
                }
            }
        }
    }

    fun toggleFavorite(song: SongEntity, isLiked: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            val updatedSong = song.copy(isFavorite = isLiked)
            songDao.update(updatedSong)
            // 更新歌单列表
            val currentState = _songUiState.value.songList
            if (currentState is UiState.Success) {
                val updatedList = currentState.data.map {
                    if (it.songId == song.songId) updatedSong else it
                }
                _songUiState.value = _songUiState.value.copy(songList = UiState.Success(updatedList))
            }
            if (_currentSong.value?.songId == song.songId) {
                _currentSong.value = updatedSong
            }
            // 刷新收藏列表和最近播放列表
            loadFavoriteSongs()
            loadRecentPlaySongs()
        }
    }

    // ========== 收藏 ==========
    fun loadFavoriteSongs() {
        viewModelScope.launch(Dispatchers.IO) {
            songDao.getFavoriteSongs().collect { list ->
                _favoriteSongsState.value = if (list.isEmpty()) UiState.Empty else UiState.Success(list)
            }
        }
    }

    // ========== 最近播放 ==========
    fun loadRecentPlaySongs() {
        viewModelScope.launch(Dispatchers.IO) {
            songDao.getRecentPlaySongs().collect { list ->
                _recentSongsState.value = if (list.isEmpty()) UiState.Empty else UiState.Success(list)
            }
        }
    }

    // ========== 歌手 ==========
    data class SingerInfo(val name: String, val avatarUrl: String)
    private val _singersState = MutableStateFlow<UiState<List<SingerInfo>>>(UiState.Loading)
    val singersState = _singersState.asStateFlow()

    private val _singerSongsState = MutableStateFlow<UiState<List<SongEntity>>>(UiState.Loading)
    val singerSongsState = _singerSongsState.asStateFlow()

    fun loadAllSingers() {
        viewModelScope.launch(Dispatchers.IO) {
            songDao.getDistinctSingers().collect { singerNames ->
                val infos = singerNames.map { name ->
                    val firstSong = songDao.getFirstSongBySinger(name)
                    SingerInfo(name, firstSong?.coverUrl ?: "")
                }
                _singersState.value = if (infos.isEmpty()) UiState.Empty else UiState.Success(infos)
            }
        }
    }

    fun loadSongsBySinger(singerName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            songDao.getSongsBySinger(singerName).collect { list ->
                _singerSongsState.value = if (list.isEmpty()) UiState.Empty else UiState.Success(list)
            }
        }
    }

    // ========== 设置 ==========
    fun toggleDarkMode(enable: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            prefRepo.setDarkMode(enable)
        }
    }
    private fun loadDarkMode() {
        viewModelScope.launch(Dispatchers.IO) {
            prefRepo.darkModeFlow.collect { }
        }
    }


    // 在 MainViewModel 类内添加

    // ---------- 头像相关 ----------
    private val _avatarUri = MutableStateFlow("")
    val avatarUri = _avatarUri.asStateFlow()

    // 加载头像
    private fun loadAvatar() {
        viewModelScope.launch(Dispatchers.IO) {
            prefRepo.getAvatarUriFlow().collect { uri ->
                _avatarUri.value = uri
            }
        }
    }

    // 更新头像
    suspend fun updateAvatar(uri: Uri, context: Context) {
        withContext(Dispatchers.IO) {
            val savedPath = prefRepo.saveAvatarToLocal(uri, context)
            if (savedPath != null) {
                prefRepo.saveAvatarUri(savedPath)
                _avatarUri.value = savedPath
            }
        }
    }

    // ---------- 密码相关 ----------
    suspend fun updatePassword(newPassword: String) {
        prefRepo.savePassword(newPassword)
    }

    // 在 init 中调用 loadAvatar()
    init {
        checkLoginStatus()
        loadDarkMode()
        loadUserName()
        loadAvatar()
    }
}