package com.example.musiccollect.data.network.dto
data class MusicResponse(
    val data: List<MusicDto>
)
data class MusicDto(
    val id: Int,
    val name: String,
    val artist: String,
    val picUrl: String,
    val url: String,

)