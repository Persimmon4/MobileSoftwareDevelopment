package com.example.musiccollect.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.example.musiccollect.navigation.Routes
import com.example.musiccollect.ui.components.EmptyLayout
import com.example.musiccollect.ui.components.LocalSongCard
import com.example.musiccollect.viewmodel.MainViewModel
import com.example.musiccollect.viewmodel.UiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FavoritesScreen(
    navCtrl: NavHostController,
    viewModelFactory: ViewModelProvider.Factory
) {
    val vm: MainViewModel = viewModel(factory = viewModelFactory)
    val favState by vm.favoriteSongsState.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) {
        vm.loadFavoriteSongs()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("我的收藏") },
                navigationIcon = {
                    IconButton(onClick = { navCtrl.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "返回")
                    }
                }
            )
        }
    ) { paddingValues ->
        Box(modifier = Modifier.fillMaxSize().padding(paddingValues)) {
            when (favState) {
                is UiState.Loading -> {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator()
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("加载收藏...")
                    }
                }
                is UiState.Empty -> EmptyLayout("暂无收藏歌曲")
                is UiState.Error -> EmptyLayout((favState as UiState.Error).msg)
                is UiState.Success -> {
                    val list = (favState as UiState.Success).data
                    if (list.isEmpty()) {
                        EmptyLayout("暂无收藏歌曲")
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(list) { song ->
                                LocalSongCard(
                                    item = song,
                                    onDelete = {
                                        vm.toggleFavorite(song, false)
                                    },
                                    onPlay = {
                                        vm.setCurrentPlayingSong(song)
                                        navCtrl.navigate(Routes.songPlay(song.songId))
                                    },
                                    onClick = {
                                        vm.setCurrentPlayingSong(song)
                                        navCtrl.navigate(Routes.songPlay(song.songId))
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}