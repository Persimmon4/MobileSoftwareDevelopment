package com.example.musiccollect.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import coil.compose.AsyncImage
import com.example.musiccollect.navigation.Routes
import com.example.musiccollect.ui.components.EmptyLayout
import com.example.musiccollect.ui.components.ErrorLayout
import com.example.musiccollect.ui.components.LoadingLayout
import com.example.musiccollect.viewmodel.MainViewModel
import com.example.musiccollect.viewmodel.UiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SingerScreen(
    navCtrl: NavHostController,
    viewModelFactory: ViewModelProvider.Factory
) {
    val vm: MainViewModel = viewModel(factory = viewModelFactory)
    val singersState by vm.singersState.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) {
        vm.loadAllSingers()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("歌手") },
                navigationIcon = {
                    IconButton(onClick = { navCtrl.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "返回")
                    }
                }
            )
        }
    ) { paddingValues ->
        Box(modifier = Modifier.fillMaxSize().padding(paddingValues)) {
            when (singersState) {
                is UiState.Loading -> LoadingLayout()
                is UiState.Empty -> EmptyLayout("暂无歌手信息")
                is UiState.Error -> ErrorLayout((singersState as UiState.Error).msg) {
                    vm.loadAllSingers()
                }
                is UiState.Success -> {
                    val singers = (singersState as UiState.Success).data
                    if (singers.isEmpty()) {
                        EmptyLayout("暂无歌手")
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(singers) { singer ->
                                SingerItem(
                                    singer = singer,
                                    onClick = {
                                        navCtrl.navigate(Routes.singerDetail(singer.name))
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SingerItem(singer: MainViewModel.SingerInfo, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        elevation = CardDefaults.cardElevation(4.dp),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AsyncImage(
                model = singer.avatarUrl,
                contentDescription = "歌手头像",
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape),
                error = androidx.compose.ui.res.painterResource(id = android.R.drawable.ic_menu_gallery)
            )
            Spacer(modifier = Modifier.padding(16.dp))
            Text(
                text = singer.name,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
        }
    }
}