package com.example.musiccollect.ui.theme
import androidx.compose.ui.graphics.Color

// 星紫主色（QQ音乐紫调）
val StarPurplePrimary = Color(0xFF7B61FF)
val StarPurpleSecondary = Color(0xFF9F88FF)
val StarPurpleLight = Color(0xFFCBBEFF)

val StarPurple = Color(0xFF9B59B6)      // 星紫


// 常用辅助色

// 月白中性底色
val MoonWhiteBg = Color(0xFFF8F9FF)
val MoonWhiteSurface = Color(0xFFFCFDFF)
val MoonWhiteDarkBg = Color(0xFF12131A)
val MoonWhiteDarkSurface = Color(0xFF1A1B28)

// 文字色
val TextDark = Color(0xFF1E1E2E)
val TextGray = Color(0xFF6E6E85)
val TextLight = Color(0xFFE2E2F0)

// 功能色
val RedFavorite = Color(0xFFFF4757)
val GreenPlay = Color(0xFF2ED573)