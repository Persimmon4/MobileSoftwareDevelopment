package com.example.musiccollect.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Index

@Entity(
    tableName = "song",
    indices = [
        Index(value = ["playlistId"]),
        Index(value = ["addTime"]),
        Index(value = ["lastPlayTime"])
    ]
)
data class SongEntity(
    @PrimaryKey(autoGenerate = true) val songId: Int = 0,
    val duration: Long = 0,
    val playlistId: Int,
    val songName: String,
    val singer: String,
    val coverUrl: String,
    val songUrl: String,
    val isFavorite: Boolean = false,
    val addTime: Long = System.currentTimeMillis(),
    val lastPlayTime: Long = 0L   // 新增：最近播放时间戳，0 表示从未播放
)