package com.example.musiccollect.data.database

import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import android.content.Context
import com.example.musiccollect.data.dao.PlaylistDao
import com.example.musiccollect.data.dao.SongDao
import com.example.musiccollect.data.entity.SongEntity
import com.example.musiccollect.data.entity.PlaylistEntity

@Database(
    entities = [PlaylistEntity::class, SongEntity::class],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun playlistDao(): PlaylistDao
    abstract fun songDao(): SongDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "app_local_db"
                )
                    .fallbackToDestructiveMigration()  // 版本升级时重建表
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}