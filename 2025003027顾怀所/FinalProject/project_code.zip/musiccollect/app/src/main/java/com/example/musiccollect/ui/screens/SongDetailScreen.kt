package com.example.musiccollect.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.MusicOff
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.example.musiccollect.data.entity.SongEntity
import com.example.musiccollect.navigation.Routes
import com.example.musiccollect.ui.components.EmptyLayout
import com.example.musiccollect.ui.components.ErrorLayout
import com.example.musiccollect.ui.components.LocalSongCard
import com.example.musiccollect.viewmodel.MainViewModel
import com.example.musiccollect.viewmodel.UiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SongDetailScreen(
    navCtrl: NavHostController,
    pid: Int,
    viewModelFactory: ViewModelProvider.Factory
) {
    val vm: MainViewModel = viewModel(factory = viewModelFactory)
    val ui = vm.songUiState.collectAsStateWithLifecycle()

    var showDelDialog by remember { mutableStateOf(false) }
    var targetSong by remember { mutableStateOf<SongEntity?>(null) }

    // 搜索相关状态
    var searchText by remember { mutableStateOf("") }
    var isSearching by remember { mutableStateOf(false) }

    // 初始化加载歌单歌曲
    LaunchedEffect(pid) {
        vm.loadAllSongsForPlaylist(pid)
    }

    // 当搜索关键词变化时，使用高效的数据库搜索
    LaunchedEffect(searchText, pid) {
        vm.searchSongsInPlaylist(pid, searchText)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    if (isSearching) {
                        OutlinedTextField(
                            value = searchText,
                            onValueChange = { searchText = it },
                            placeholder = { Text("搜索歌曲名或歌手") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp),
                            singleLine = true,
                            shape = RoundedCornerShape(16.dp)
                        )
                    } else {
                        Text("歌单歌曲")
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { navCtrl.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "返回")
                    }
                },
                actions = {
                    IconButton(onClick = {
                        isSearching = !isSearching
                        if (!isSearching) {
                            searchText = ""
                            vm.loadAllSongsForPlaylist(pid)
                        }
                    }) {
                        Icon(Icons.Default.Search, contentDescription = "搜索")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { navCtrl.navigate(Routes.HOT_MUSIC) }
            ) {
                Icon(Icons.Filled.MusicOff, contentDescription = "添加网络热歌")
            }
        }
    ) { paddingValues ->
        Box(modifier = Modifier.fillMaxSize().padding(paddingValues)) {
            when (val state = ui.value.songList) {
                is UiState.Loading -> {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator()
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("加载歌曲中...")
                    }
                }
                is UiState.Empty -> EmptyLayout(
                    if (searchText.isNotEmpty()) "未找到匹配的歌曲" else "歌单内暂无歌曲，点击右下角添加网络热歌"
                )
                is UiState.Error -> ErrorLayout(state.msg) {
                    vm.loadAllSongsForPlaylist(pid)
                }
                is UiState.Success -> {
                    if (state.data.isEmpty()) {
                        EmptyLayout(
                            if (searchText.isNotEmpty()) "未找到匹配的歌曲" else "歌单内暂无歌曲，点击右下角添加网络热歌"
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(state.data) { song ->
                                LocalSongCard(
                                    item = song,
                                    onDelete = {
                                        targetSong = song
                                        showDelDialog = true
                                    },
                                    onPlay = {
                                        navCtrl.navigate(Routes.songPlay(song.songId))
                                    },
                                    onClick = {
                                        navCtrl.navigate(Routes.songPlay(song.songId))
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        if (showDelDialog && targetSong != null) {
            AlertDialog(
                onDismissRequest = { showDelDialog = false },
                title = { Text("删除歌曲") },
                text = { Text("确定移除该首收藏歌曲？") },
                confirmButton = {
                    Button(
                        onClick = {
                            vm.deleteSong(targetSong!!)
                            showDelDialog = false
                        }
                    ) {
                        Text("删除")
                    }
                },
                dismissButton = {
                    Button(onClick = { showDelDialog = false }) {
                        Text("取消")
                    }
                }
            )
        }
    }
}