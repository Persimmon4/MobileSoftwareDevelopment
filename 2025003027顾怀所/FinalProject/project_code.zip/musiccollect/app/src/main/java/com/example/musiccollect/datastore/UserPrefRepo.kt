package com.example.musiccollect.datastore

import android.content.Context
import android.net.Uri
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.File

val Context.dataStore: DataStore<Preferences> by preferencesDataStore("music_pref")

class UserPrefRepo(context: Context) {
    private val ds = context.dataStore

    private val DARK_MODE = booleanPreferencesKey("dark_mode")
    private val LAST_SEARCH = stringPreferencesKey("last_search")
    private val LOGIN_STATUS = booleanPreferencesKey("login_status")
    private val USER_NAME = stringPreferencesKey("user_name")   // 新增

    val darkModeFlow: Flow<Boolean> = ds.data.map { it[DARK_MODE] ?: false }
    suspend fun setDarkMode(isDark: Boolean) {
        ds.edit { it[DARK_MODE] = isDark }
    }

    val lastSearchFlow: Flow<String> = ds.data.map { it[LAST_SEARCH] ?: "" }
    suspend fun saveSearchText(text: String) {
        ds.edit { it[LAST_SEARCH] = text }
    }

    suspend fun saveLoginStatus(isLoggedIn: Boolean) {
        ds.edit { it[LOGIN_STATUS] = isLoggedIn }
    }
    suspend fun getLoginStatus(): Boolean {
        return ds.data.map { it[LOGIN_STATUS] ?: false }.first()
    }
    fun getLoginStatusFlow(): Flow<Boolean> = ds.data.map { it[LOGIN_STATUS] ?: false }

    // 新增用户名方法
    suspend fun saveUserName(name: String) {
        ds.edit { it[USER_NAME] = name }
    }
    suspend fun getUserName(): String {
        return ds.data.map { it[USER_NAME] ?: "" }.first()
    }
    fun getUserNameFlow(): Flow<String> = ds.data.map { it[USER_NAME] ?: "" }


    private val PASSWORD = stringPreferencesKey("password")
    private val AVATAR_URI = stringPreferencesKey("avatar_uri")

    // 密码
    suspend fun savePassword(password: String) {
        ds.edit { it[PASSWORD] = password }
    }
    fun getPasswordFlow(): Flow<String> = ds.data.map { it[PASSWORD] ?: "" }

    // 头像
    suspend fun saveAvatarUri(uri: String) {
        ds.edit { it[AVATAR_URI] = uri }
    }
    fun getAvatarUriFlow(): Flow<String> = ds.data.map { it[AVATAR_URI] ?: "" }

    // 保存头像到本地并返回路径
    suspend fun saveAvatarToLocal(uri: Uri, context: Context): String? {
        return withContext(Dispatchers.IO) {
            try {
                val inputStream = context.contentResolver.openInputStream(uri) ?: return@withContext null
                val cacheDir = context.cacheDir
                val file = File(cacheDir, "avatar_${System.currentTimeMillis()}.jpg")
                file.outputStream().use { output ->
                    inputStream.copyTo(output)
                }
                file.absolutePath
            } catch (e: Exception) {
                e.printStackTrace()
                null
            }
        }
    }
}