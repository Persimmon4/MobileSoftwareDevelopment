package com.example.musiccollect.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Index

@Entity(
    tableName = "playlist",
    indices = [Index(value = ["createTime"])]
)
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val desc: String,
    val createTime: Long = System.currentTimeMillis()
)