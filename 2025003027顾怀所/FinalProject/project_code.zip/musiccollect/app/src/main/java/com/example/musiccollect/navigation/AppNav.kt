// file: com/example/musiccollect/navigation/AppNav.kt
package com.example.musiccollect.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.musiccollect.ui.screens.*
import com.example.musiccollect.viewmodel.MainViewModel

object Routes {
    const val LOGIN = "login"
    const val HOME = "home"
    const val HOT_MUSIC = "hot_music"
    const val SONG_DETAIL = "song_detail/{pid}"
    const val SONG_PLAY = "song_play/{songId}"
    const val EDIT_SONG = "edit_song"
    const val SETTING = "setting"
    const val PROFILE = "profile"
    const val SINGER = "singer"
    const val SINGER_DETAIL = "singer_detail/{singerName}"
    const val FAVORITES = "favorites"          // 新增
    const val RECENT_PLAY = "recent_play"      // 新增

    fun songDetail(pid: Int) = "song_detail/$pid"
    fun songPlay(songId: Int) = "song_play/$songId"
    fun singerDetail(singerName: String) = "singer_detail/$singerName"
}

@Composable
fun AppNavigation(
    navCtrl: NavHostController,
    viewModelFactory: ViewModelProvider.Factory,
    viewModel: MainViewModel
) {
    val isLoggedIn by viewModel.isLoggedIn.collectAsStateWithLifecycle()

    NavHost(
        navController = navCtrl,
        startDestination = if (isLoggedIn) Routes.HOME else Routes.LOGIN
    ) {
        composable(Routes.LOGIN) {
            LoginScreen(navCtrl = navCtrl, viewModelFactory = viewModelFactory)
        }
        composable(Routes.HOME) {
            HomeScreen(navCtrl = navCtrl, viewModelFactory = viewModelFactory)
        }
        composable(Routes.HOT_MUSIC) {
            HotMusicScreen(navCtrl = navCtrl, viewModelFactory = viewModelFactory)
        }
        composable(Routes.SONG_DETAIL) { backStack ->
            val pid = backStack.arguments?.getString("pid")?.toIntOrNull() ?: 0
            SongDetailScreen(navCtrl = navCtrl, pid = pid, viewModelFactory = viewModelFactory)
        }
        composable(Routes.SONG_PLAY) { backStack ->
            val songId = backStack.arguments?.getString("songId")?.toIntOrNull() ?: 0
            SongPlayScreen(navCtrl = navCtrl, songId = songId, viewModelFactory = viewModelFactory)
        }
        composable(Routes.EDIT_SONG) {
            EditSongScreen(navCtrl = navCtrl, viewModelFactory = viewModelFactory)
        }
        composable(Routes.SETTING) {
            SettingsScreen(navCtrl = navCtrl, viewModelFactory = viewModelFactory)
        }
        composable(Routes.PROFILE) {
            ProfileScreen(navCtrl = navCtrl, viewModelFactory = viewModelFactory)
        }
        composable(Routes.SINGER) {
            SingerScreen(navCtrl = navCtrl, viewModelFactory = viewModelFactory)
        }
        composable(Routes.SINGER_DETAIL) { backStack ->
            val singerName = backStack.arguments?.getString("singerName") ?: ""
            SingerDetailScreen(navCtrl = navCtrl, singerName = singerName, viewModelFactory = viewModelFactory)
        }
        // 新增路由
        composable(Routes.FAVORITES) {
            FavoritesScreen(navCtrl = navCtrl, viewModelFactory = viewModelFactory)
        }
        composable(Routes.RECENT_PLAY) {
            RecentPlayScreen(navCtrl = navCtrl, viewModelFactory = viewModelFactory)
        }
    }
}