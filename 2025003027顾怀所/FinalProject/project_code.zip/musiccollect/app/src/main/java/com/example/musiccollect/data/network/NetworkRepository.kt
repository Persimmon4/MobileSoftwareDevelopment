package com.example.musiccollect.data.network

import com.example.musiccollect.data.network.dto.MusicDto
import retrofit2.HttpException
import java.io.IOException

class NetworkRepository(private val api: ApiService) {

    suspend fun fetchHotMusic(): Result<List<MusicDto>> {
        return try {
            val res = api.getHotMusic()
            if (res.isSuccessful) {
                val data = res.body()?.data
                // 如果接口返回的数据为空或太少，也可考虑合并模拟数据，这里直接返回
                if (data.isNullOrEmpty()) {
                    Result.success(getMockMusicList())
                } else {
                    Result.success(data)
                }
            } else {
                // 请求失败时返回丰富的模拟数据
                Result.success(getMockMusicList())
            }
        } catch (e: Exception) {
            // 异常时返回丰富的模拟数据
            Result.success(getMockMusicList())
        }
    }

    // 模拟数据
    private fun getMockMusicList(): List<MusicDto> {
        return listOf(
            MusicDto(1, "夜曲", "周杰伦", "https://picsum.photos/seed/1/200/200", "https://example.com/song1.mp3"),
            MusicDto(2, "晴天", "周杰伦", "https://picsum.photos/seed/2/200/200", "https://example.com/song2.mp3"),
            MusicDto(3, "稻香", "周杰伦", "https://picsum.photos/seed/3/200/200", "https://example.com/song3.mp3"),
            MusicDto(4, "你的样子", "罗大佑", "https://picsum.photos/seed/4/200/200", "https://example.com/song4.mp3"),
            MusicDto(5, "海阔天空", "Beyond", "https://picsum.photos/seed/5/200/200", "https://example.com/song5.mp3"),
            MusicDto(6, "风雨无阻", "周华健", "https://picsum.photos/seed/6/200/200", "https://example.com/song6.mp3"),
            MusicDto(7, "刀剑如梦", "周华健", "https://picsum.photos/seed/7/200/200", "https://example.com/song7.mp3"),
            MusicDto(8, "让我欢喜让我忧", "周华健", "https://picsum.photos/seed/8/200/200", "https://example.com/song8.mp3"),
            MusicDto(9, "风往北吹", "孙楠", "https://picsum.photos/seed/9/200/200", "https://example.com/song9.mp3"),
            MusicDto(10, "我的心太乱", "小刚", "https://picsum.photos/seed/10/200/200", "https://example.com/song10.mp3"),
            MusicDto(11, "黄昏", "周传雄", "https://picsum.photos/seed/11/200/200", "https://example.com/song11.mp3"),
            MusicDto(12, "真心英雄", "李宗盛", "https://picsum.photos/seed/12/200/200", "https://example.com/song12.mp3"),
            MusicDto(13, "痴心绝对", "李圣杰", "https://picsum.photos/seed/13/200/200", "https://example.com/song13.mp3"),
            MusicDto(14, "风再起时", "张国荣", "https://picsum.photos/seed/14/200/200", "https://example.com/song14.mp3"),
            MusicDto(15, "爱要怎么说出口", "赵传", "https://picsum.photos/seed/15/200/200", "https://example.com/song15.mp3")
        )
    }
}