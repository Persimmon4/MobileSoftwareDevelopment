// file: com/example/musiccollect/ui/screens/ProfileScreen.kt
package com.example.musiccollect.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import coil.compose.AsyncImage
import com.example.musiccollect.R
import com.example.musiccollect.navigation.Routes
import com.example.musiccollect.viewmodel.MainViewModel
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    navCtrl: NavHostController,
    viewModelFactory: ViewModelProvider.Factory
) {
    val vm: MainViewModel = viewModel(factory = viewModelFactory)
    val userName by vm.userName.collectAsStateWithLifecycle()
    val avatarUri by vm.avatarUri.collectAsStateWithLifecycle()  // 新增：头像 URI
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    // 修改个人信息弹窗
    var showEditDialog by remember { mutableStateOf(false) }
    var newUserName by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var editError by remember { mutableStateOf<String?>(null) }

    // 退出登录确认弹窗
    var showLogoutDialog by remember { mutableStateOf(false) }

    // 头像选择器
    val avatarPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            // 保存头像到本地并更新 ViewModel
            scope.launch {
                vm.updateAvatar(it, context)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("个人中心") },
                navigationIcon = {
                    IconButton(onClick = { navCtrl.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "返回")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(32.dp))

            // 头像
            Box(
                modifier = Modifier
                    .size(120.dp)
                    .clip(CircleShape)
                    .clickable { avatarPickerLauncher.launch("image/*") }
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                if (avatarUri.isNotEmpty()) {
                    // 显示用户自定义头像
                    AsyncImage(
                        model = File(avatarUri),
                        contentDescription = "用户头像",
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    // 默认显示星形图标
                    Image(
                        painter = painterResource(id = R.drawable.avatar),
                        contentDescription = "默认头像",
                        modifier = Modifier.size(80.dp)
                    )
                }
                Icon(
                    Icons.Default.Edit,
                    contentDescription = "更换头像",
                    modifier = Modifier
                        .size(32.dp)
                        .align(Alignment.BottomEnd)
                        .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.8f), CircleShape),
                    tint = MaterialTheme.colorScheme.primary
                )
            }

            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = userName.ifEmpty { "未命名用户" },
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "ID: 10001",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(32.dp))

            // 功能卡片列表
            Card(
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(4.dp)
            ) {
                Column {
                    // 设置
                    ProfileMenuItem(
                        icon = Icons.Default.Settings,
                        title = "设置",
                        onClick = { navCtrl.navigate(Routes.SETTING) }
                    )
                    Divider()

                    // 修改个人信息
                    ProfileMenuItem(
                        icon = Icons.Default.Edit,
                        title = "修改个人信息",
                        onClick = {
                            newUserName = userName
                            newPassword = ""
                            confirmPassword = ""
                            editError = null
                            showEditDialog = true
                        }
                    )
                    Divider()

                    // 切换账号
                    ProfileMenuItem(
                        icon = Icons.Default.SwapHoriz,
                        title = "切换账号",
                        onClick = {
                            vm.logout { _, _ ->
                                navCtrl.navigate(Routes.LOGIN) {
                                    popUpTo(0) { inclusive = true }
                                }
                            }
                        }
                    )
                    Divider()

                    // 退出登录
                    ProfileMenuItem(
                        icon = Icons.Default.Logout,
                        title = "退出登录",
                        onClick = { showLogoutDialog = true },
                        iconTint = MaterialTheme.colorScheme.error,
                        textColor = MaterialTheme.colorScheme.error
                    )
                }
            }
        }
    }

    // 修改个人信息对话框
    if (showEditDialog) {
        AlertDialog(
            onDismissRequest = { showEditDialog = false },
            title = { Text("修改个人信息") },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(
                        value = newUserName,
                        onValueChange = { newUserName = it; editError = null },
                        label = { Text("用户名") },
                        singleLine = true,
                        isError = editError != null
                    )
                    OutlinedTextField(
                        value = newPassword,
                        onValueChange = { newPassword = it; editError = null },
                        label = { Text("新密码（留空则不修改）") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation()
                    )
                    OutlinedTextField(
                        value = confirmPassword,
                        onValueChange = { confirmPassword = it; editError = null },
                        label = { Text("确认密码") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        isError = editError != null
                    )
                    if (editError != null) {
                        Text(
                            text = editError!!,
                            color = MaterialTheme.colorScheme.error,
                            fontSize = 14.sp
                        )
                    }
                    Text(
                        text = "点击头像可更换图片",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 12.sp
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        // 验证
                        if (newUserName.isBlank()) {
                            editError = "用户名不能为空"
                            return@TextButton
                        }
                        if (newPassword.isNotEmpty() && newPassword != confirmPassword) {
                            editError = "两次密码输入不一致"
                            return@TextButton
                        }
                        if (newPassword.isNotEmpty() && newPassword.length < 3) {
                            editError = "密码长度不能少于3位"
                            return@TextButton
                        }
                        // 更新
                        scope.launch {
                            vm.updateUserName(newUserName)
                            if (newPassword.isNotEmpty()) {
                                vm.updatePassword(newPassword)
                            }
                        }
                        showEditDialog = false
                    }
                ) {
                    Text("保存")
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditDialog = false }) {
                    Text("取消")
                }
            }
        )
    }

    // 退出登录确认对话框
    if (showLogoutDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutDialog = false },
            title = { Text("退出登录") },
            text = { Text("确定要退出登录吗？") },
            confirmButton = {
                TextButton(
                    onClick = {
                        vm.logout { _, _ ->
                            navCtrl.navigate(Routes.LOGIN) {
                                popUpTo(0) { inclusive = true }
                            }
                        }
                        showLogoutDialog = false
                    }
                ) {
                    Text("退出", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutDialog = false }) {
                    Text("取消")
                }
            }
        )
    }
}

@Composable
private fun ProfileMenuItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    onClick: () -> Unit,
    iconTint: Color = MaterialTheme.colorScheme.onSurface,
    textColor: Color = MaterialTheme.colorScheme.onSurface
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = iconTint,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.width(16.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.bodyLarge,
            color = textColor
        )
    }
}