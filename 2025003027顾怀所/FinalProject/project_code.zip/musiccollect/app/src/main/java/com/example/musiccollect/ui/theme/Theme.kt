package com.example.musiccollect.ui.theme
import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LightColorScheme = lightColorScheme(
    primary = StarPurplePrimary,
    secondary = StarPurpleSecondary,
    tertiary = StarPurpleLight,
    background = MoonWhiteBg,
    surface = MoonWhiteSurface,
    onPrimary = Color.White,
    onBackground = TextDark,
    onSurface = TextDark
)

private val DarkColorScheme = darkColorScheme(
    primary = StarPurpleLight,
    secondary = StarPurpleSecondary,
    tertiary = StarPurplePrimary,
    background = MoonWhiteDarkBg,
    surface = MoonWhiteDarkSurface,
    onPrimary = TextDark,
    onBackground = TextLight,
    onSurface = TextLight
)

@Composable
fun MusiccollectTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val view = LocalView.current

    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            // 改为透明状态栏，由页面顶部布局承载主题色，替代废弃的statusBarColor直接赋值
            @Suppress("DEPRECATION")
            window.statusBarColor = colorScheme.primary.toArgb()
            val insetsController = WindowCompat.getInsetsController(window, view)
            insetsController.isAppearanceLightStatusBars = !darkTheme
            // 适配Android 15+ 边到边布局，允许内容延伸到状态栏区域
            WindowCompat.setDecorFitsSystemWindows(window, false)
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}