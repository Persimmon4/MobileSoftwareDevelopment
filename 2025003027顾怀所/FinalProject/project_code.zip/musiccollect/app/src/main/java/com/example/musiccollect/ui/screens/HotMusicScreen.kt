package com.example.musiccollect.ui.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.example.musiccollect.data.entity.PlaylistEntity
import com.example.musiccollect.data.entity.SongEntity
import com.example.musiccollect.data.network.dto.MusicDto
import com.example.musiccollect.navigation.Routes
import com.example.musiccollect.ui.components.EmptyLayout
import com.example.musiccollect.ui.components.ErrorLayout
import com.example.musiccollect.ui.components.NetMusicCard
import com.example.musiccollect.viewmodel.MainViewModel
import com.example.musiccollect.viewmodel.UiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HotMusicScreen(
    navCtrl: NavHostController,
    viewModelFactory: ViewModelProvider.Factory
) {
    val vm: MainViewModel = viewModel(factory = viewModelFactory)
    val ui = vm.hotMusicUiState.collectAsStateWithLifecycle()
    val playlists = vm.playlistUiState.collectAsStateWithLifecycle()

    var showSelectPlaylistDialog by remember { mutableStateOf(false) }
    var targetMusicDto by remember { mutableStateOf<MusicDto?>(null) }
    val listState = rememberLazyListState()

    var searchText by remember { mutableStateOf("") }
    var isSearching by remember { mutableStateOf(false) }

    val filteredList = remember(ui.value.netState, searchText) {
        when (val state = ui.value.netState) {
            is UiState.Success -> state.data.filter { dto ->
                dto.name.contains(searchText, ignoreCase = true) ||
                        dto.artist.contains(searchText, ignoreCase = true)
            }
            else -> emptyList()
        }
    }

    LaunchedEffect(Unit) {
        vm.loadHotMusic()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    if (isSearching) {
                        OutlinedTextField(
                            value = searchText,
                            onValueChange = { searchText = it },
                            placeholder = { Text("搜索歌曲或歌手") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp),
                            singleLine = true,
                            shape = RoundedCornerShape(16.dp)
                        )
                    } else {
                        Text("全网热歌")
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { navCtrl.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "返回")
                    }
                },
                actions = {
                    IconButton(onClick = {
                        isSearching = !isSearching
                        if (!isSearching) searchText = ""
                    }) {
                        Icon(Icons.Default.Search, contentDescription = "搜索")
                    }
                }
            )
        }
    ) { paddingValues ->
        Box(modifier = Modifier.fillMaxSize().padding(paddingValues)) {
            when (val netState = ui.value.netState) {
                is UiState.Loading -> {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center
                    ) {
                        CircularProgressIndicator()
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("加载热歌中...")
                    }
                }
                is UiState.Empty -> EmptyLayout("暂无网络歌曲数据")
                is UiState.Error -> ErrorLayout(netState.msg) {
                    vm.loadHotMusic(true)
                }
                is UiState.Success -> {
                    if (filteredList.isEmpty()) {
                        EmptyLayout(if (searchText.isNotEmpty()) "未找到匹配歌曲" else "暂无歌曲")
                    } else {
                        LazyColumn(state = listState) {
                            items(filteredList) { dto ->
                                NetMusicCard(
                                    item = dto,
                                    onAdd = {
                                        targetMusicDto = dto
                                        showSelectPlaylistDialog = true
                                    },
                                    onClick = {
                                        val tempSong = SongEntity(
                                            songId = -1,
                                            playlistId = 0,
                                            songName = dto.name,
                                            singer = dto.artist,
                                            coverUrl = dto.picUrl,
                                            songUrl = dto.url,
                                            isFavorite = false
                                        )
                                        vm.setCurrentPlayingSong(tempSong)
                                        navCtrl.navigate(Routes.songPlay(-1))
                                    }
                                )
                            }
                            item {
                                if (ui.value.isRefreshing) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(16.dp),
                                        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.Center
                                    ) {
                                        CircularProgressIndicator(
                                            modifier = Modifier.size(24.dp),
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("刷新中...")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (showSelectPlaylistDialog && targetMusicDto != null) {
            AlertDialog(
                onDismissRequest = { showSelectPlaylistDialog = false },
                title = { Text("选择收藏歌单") },
                text = {
                    when (val plState = playlists.value.listState) {
                        is UiState.Success -> {
                            Column {
                                if (plState.data.isEmpty()) {
                                    Text("请先创建歌单")
                                } else {
                                    plState.data.forEach { playlist: PlaylistEntity ->
                                        Button(
                                            onClick = {
                                                vm.addNetSongToLocal(targetMusicDto!!, playlist.id)
                                                showSelectPlaylistDialog = false
                                            },
                                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                                        ) {
                                            Text(playlist.name)
                                        }
                                    }
                                }
                            }
                        }
                        is UiState.Loading -> Text("加载歌单中...")
                        else -> Text("请先创建歌单")
                    }
                },
                confirmButton = {},
                dismissButton = {
                    Button(onClick = { showSelectPlaylistDialog = false }) {
                        Text("取消")
                    }
                }
            )
        }
    }
}