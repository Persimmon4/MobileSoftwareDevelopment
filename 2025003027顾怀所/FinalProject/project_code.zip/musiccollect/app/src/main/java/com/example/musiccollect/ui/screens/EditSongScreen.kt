package com.example.musiccollect.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.example.musiccollect.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditSongScreen(
    navCtrl: NavHostController,
    viewModelFactory: ViewModelProvider.Factory
) {
    val vm: MainViewModel = viewModel(factory = viewModelFactory)

    var name by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var errTip by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("新建歌单") },
                navigationIcon = {
                    IconButton(onClick = { navCtrl.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "返回")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(paddingValues)
                .padding(16.dp)
        ) {
            OutlinedTextField(
                value = name,
                onValueChange = {
                    name = it
                    if (errTip.isNotEmpty()) errTip = ""
                },
                label = { Text("歌单名称（必填）") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                isError = errTip.isNotEmpty()
            )

            OutlinedTextField(
                value = desc,
                onValueChange = { desc = it },
                label = { Text("歌单描述") },
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                maxLines = 3
            )

            if (errTip.isNotEmpty()) {
                Text(
                    text = errTip,
                    color = Color.Red,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            Button(
                onClick = {
                    if (name.isBlank()) {
                        errTip = "歌单名称不能为空"
                        return@Button
                    }
                    vm.addPlaylist(name, desc)
                    navCtrl.popBackStack()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp)
            ) {
                Text("创建歌单")
            }
        }
    }
}