package com.example.musiccollect.data.network
import com.example.musiccollect.data.network.dto.MusicResponse
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

interface ApiService {
    // 免费公开音乐Mock接口
    @GET("music/hot")
    suspend fun getHotMusic(@Query("limit") limit: Int = 20): Response<MusicResponse>
}