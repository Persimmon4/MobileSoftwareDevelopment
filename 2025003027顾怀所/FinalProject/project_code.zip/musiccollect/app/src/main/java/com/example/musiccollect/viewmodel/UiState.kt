package com.example.musiccollect.viewmodel
import com.example.musiccollect.data.entity.PlaylistEntity
import com.example.musiccollect.data.entity.SongEntity
import com.example.musiccollect.data.network.dto.MusicDto

sealed interface UiState<out T> {
    object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val msg: String) : UiState<Nothing>
    object Empty : UiState<Nothing>
}

// 首页歌单状态
data class PlaylistUiState(
    val listState: UiState<List<PlaylistEntity>> = UiState.Loading,
    val searchText: String = ""
)

// 网络热歌页面状态
data class HotMusicUiState(
    val netState: UiState<List<MusicDto>> = UiState.Loading,
    val isRefreshing: Boolean = false
)

// 歌曲详情页状态
data class SongUiState(
    val songList: UiState<List<SongEntity>> = UiState.Loading,
    val currentPlaylistId: Int = 0
)

// 设置页状态
data class SettingUiState(
    val darkMode: Boolean = false
)

// 新增数据类
data class SingerInfo(val name: String, val avatarUrl: String)