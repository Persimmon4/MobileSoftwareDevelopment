package com.example.musiccollect.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.example.musiccollect.data.entity.SongEntity
import com.example.musiccollect.navigation.Routes
import com.example.musiccollect.ui.components.EmptyLayout
import com.example.musiccollect.ui.components.LocalSongCard
import com.example.musiccollect.viewmodel.MainViewModel
import com.example.musiccollect.viewmodel.UiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SingerDetailScreen(
    navCtrl: NavHostController,
    singerName: String,
    viewModelFactory: ViewModelProvider.Factory
) {
    val vm: MainViewModel = viewModel(factory = viewModelFactory)
    val songState = vm.singerSongsState.collectAsStateWithLifecycle()

    LaunchedEffect(singerName) {
        vm.loadSongsBySinger(singerName)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(singerName) },
                navigationIcon = {
                    IconButton(onClick = { navCtrl.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "返回")
                    }
                }
            )
        }
    ) { paddingValues ->
        Box(modifier = Modifier.fillMaxSize().padding(paddingValues)) {
            when (val state = songState.value) {
                is UiState.Loading -> {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator()
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("加载歌曲中...")
                    }
                }
                is UiState.Empty -> EmptyLayout("该歌手暂无歌曲")
                is UiState.Error -> EmptyLayout(state.msg)
                is UiState.Success -> {
                    val songs = state.data
                    if (songs.isEmpty()) {
                        EmptyLayout("该歌手暂无歌曲")
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(
                                horizontal = 12.dp,
                                vertical = 8.dp
                            ),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(songs) { song ->
                                LocalSongCard(
                                    item = song,
                                    onDelete = {
                                    },
                                    onPlay = {
                                        vm.setCurrentPlayingSong(song)
                                        navCtrl.navigate(Routes.songPlay(song.songId))
                                    },
                                    onClick = {
                                        vm.setCurrentPlayingSong(song)
                                        navCtrl.navigate(Routes.songPlay(song.songId))
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}