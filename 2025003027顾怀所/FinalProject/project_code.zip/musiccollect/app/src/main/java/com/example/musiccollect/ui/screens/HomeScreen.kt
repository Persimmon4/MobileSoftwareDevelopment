package com.example.musiccollect.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.example.musiccollect.data.entity.PlaylistEntity
import com.example.musiccollect.navigation.Routes
import com.example.musiccollect.ui.components.EmptyLayout
import com.example.musiccollect.ui.components.ErrorLayout
import com.example.musiccollect.viewmodel.MainViewModel
import com.example.musiccollect.viewmodel.UiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    navCtrl: NavHostController,
    viewModelFactory: ViewModelProvider.Factory
) {
    val vm: MainViewModel = viewModel(factory = viewModelFactory)
    val playlistState = vm.playlistUiState.collectAsStateWithLifecycle()

    var searchText by remember { mutableStateOf("") }
    var isSearching by remember { mutableStateOf(false) }

    var showDeleteDialog by remember { mutableStateOf(false) }
    var targetPlaylist by remember { mutableStateOf<PlaylistEntity?>(null) }

    // 排序相关
    var sortOption by remember { mutableStateOf(MainViewModel.SortOption.CREATE_TIME_DESC) }
    var showSortMenu by remember { mutableStateOf(false) }

    LaunchedEffect(searchText) {
        vm.searchPlaylist(searchText)
    }

    LaunchedEffect(sortOption) {
        vm.setSortOption(sortOption)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    if (isSearching) {
                        OutlinedTextField(
                            value = searchText,
                            onValueChange = { searchText = it },
                            placeholder = { Text("搜索歌单名称") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp),
                            singleLine = true,
                            shape = RoundedCornerShape(16.dp)
                        )
                    } else {
                        Text("我的歌单")
                    }
                },
                actions = {

                    // 搜索切换按钮
                    IconButton(onClick = {
                        isSearching = !isSearching
                        if (!isSearching) {
                            searchText = ""
                            vm.searchPlaylist("")
                        }
                    }) {
                        Icon(Icons.Default.Search, contentDescription = "搜索")
                    }

                    // 排序按钮
                    IconButton(onClick = { showSortMenu = true }) {
                        Icon(Icons.Default.Sort, contentDescription = "排序")
                    }
                }
            )
        },
        // 底部四个入口
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                // 新建歌单
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Add, contentDescription = "新建歌单") },
                    label = { Text("新建") },
                    selected = false,
                    onClick = { navCtrl.navigate(Routes.EDIT_SONG) }
                )
                // 我的收藏
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Favorite, contentDescription = "我的收藏") },
                    label = { Text("收藏") },
                    selected = false,
                    onClick = { navCtrl.navigate(Routes.FAVORITES) }
                )

                // 歌手
                NavigationBarItem(
                    icon = { Icon(Icons.Default.MusicNote, contentDescription = "歌手") },
                    label = { Text("歌手") },
                    selected = false,
                    onClick = { navCtrl.navigate(Routes.SINGER) }
                )
                // 个人中心
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Person, contentDescription = "个人中心") },
                    label = { Text("我的") },
                    selected = false,
                    onClick = { navCtrl.navigate(Routes.PROFILE) }
                )
            }
        }
    ) { paddingValues ->
        Box(modifier = Modifier.fillMaxSize().padding(paddingValues)) {
            when (val state = playlistState.value.listState) {
                is UiState.Loading -> {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator()
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("加载歌单中...")
                    }
                }
                is UiState.Empty -> EmptyLayout(
                    if (searchText.isNotEmpty()) "未找到匹配的歌单" else "暂无歌单，点击右上角创建"
                )
                is UiState.Error -> ErrorLayout(state.msg) { vm.loadAllPlaylist() }
                is UiState.Success -> {
                    if (state.data.isEmpty()) {
                        EmptyLayout(
                            if (searchText.isNotEmpty()) "未找到匹配的歌单" else "暂无歌单，点击右上角创建"
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(state.data) { playlist ->
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            navCtrl.navigate(Routes.songDetail(playlist.id))
                                        },
                                    shape = RoundedCornerShape(16.dp),
                                    elevation = CardDefaults.cardElevation(4.dp)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(16.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            Icons.Default.LibraryMusic,
                                            contentDescription = null,
                                            modifier = Modifier.size(48.dp),
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                        Spacer(modifier = Modifier.width(16.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = playlist.name,
                                                style = MaterialTheme.typography.titleMedium
                                            )
                                            Text(
                                                text = playlist.desc.ifEmpty { "无描述" },
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        IconButton(
                                            onClick = {
                                                targetPlaylist = playlist
                                                showDeleteDialog = true
                                            }
                                        ) {
                                            Icon(
                                                Icons.Default.Delete,
                                                contentDescription = "删除歌单",
                                                tint = MaterialTheme.colorScheme.error
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // 排序下拉菜单
    DropdownMenu(
        expanded = showSortMenu,
        onDismissRequest = { showSortMenu = false }
    ) {
        DropdownMenuItem(
            text = { Text("按创建时间（最新）") },
            onClick = {
                sortOption = MainViewModel.SortOption.CREATE_TIME_DESC
                showSortMenu = false
            }
        )
        DropdownMenuItem(
            text = { Text("按创建时间（最旧）") },
            onClick = {
                sortOption = MainViewModel.SortOption.CREATE_TIME_ASC
                showSortMenu = false
            }
        )
        DropdownMenuItem(
            text = { Text("按名称 A-Z") },
            onClick = {
                sortOption = MainViewModel.SortOption.NAME_ASC
                showSortMenu = false
            }
        )
        DropdownMenuItem(
            text = { Text("按名称 Z-A") },
            onClick = {
                sortOption = MainViewModel.SortOption.NAME_DESC
                showSortMenu = false
            }
        )
        DropdownMenuItem(
            text = { Text("按歌曲数量（多→少）") },
            onClick = {
                sortOption = MainViewModel.SortOption.SONG_COUNT_DESC
                showSortMenu = false
            }
        )
    }

    // 删除确认对话框
    if (showDeleteDialog && targetPlaylist != null) {
        AlertDialog(
            onDismissRequest = {
                showDeleteDialog = false
                targetPlaylist = null
            },
            title = { Text("删除歌单") },
            text = { Text("确定要删除「${targetPlaylist?.name}」吗？\n该歌单下的所有歌曲也会被删除！") },
            confirmButton = {
                TextButton(
                    onClick = {
                        targetPlaylist?.let { vm.deletePlaylist(it) }
                        showDeleteDialog = false
                        targetPlaylist = null
                    }
                ) {
                    Text("删除", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showDeleteDialog = false
                        targetPlaylist = null
                    }
                ) {
                    Text("取消")
                }
            }
        )
    }
}