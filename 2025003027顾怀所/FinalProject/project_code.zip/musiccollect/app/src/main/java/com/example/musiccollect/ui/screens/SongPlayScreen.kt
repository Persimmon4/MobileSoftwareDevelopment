// file: com/example/musiccollect/ui/screens/SongPlayScreen.kt
package com.example.musiccollect.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import coil.compose.AsyncImage
import com.example.musiccollect.R
import com.example.musiccollect.data.entity.SongEntity
import com.example.musiccollect.ui.components.EmptyLayout
import com.example.musiccollect.ui.components.ErrorLayout
import com.example.musiccollect.ui.components.LoadingLayout
import com.example.musiccollect.ui.theme.RedFavorite
import com.example.musiccollect.ui.theme.TextGray
import com.example.musiccollect.viewmodel.MainViewModel
import com.example.musiccollect.viewmodel.UiState
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// 简单 LRC 行数据
data class LyricLine(val time: Long, val text: String)

// 模拟歌词
val mockLyrics = listOf(
    LyricLine(15000, "第一句歌词示例"),
    LyricLine(30000, "第二句歌词示例"),
    LyricLine(45000, "第三句歌词示例"),
    LyricLine(60000, "第四句歌词示例"),
    LyricLine(75000, "第五句歌词示例"),
    LyricLine(90000, "第六句歌词示例"),
    LyricLine(105000, "第七句歌词示例"),
    LyricLine(120000, "第八句歌词示例")
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SongPlayScreen(
    navCtrl: NavHostController,
    songId: Int,
    viewModelFactory: ViewModelProvider.Factory
) {
    val vm: MainViewModel = viewModel(factory = viewModelFactory)
    val currentSong by vm.currentSong.collectAsStateWithLifecycle()
    val songUiState = vm.songUiState.collectAsStateWithLifecycle()

    var isWaitingForNetSong by remember { mutableStateOf(false) }
    var loadTimeout by remember { mutableStateOf(false) }

    LaunchedEffect(songId) {
        if (songId == -1) {
            if (currentSong == null) {
                isWaitingForNetSong = true
                delay(3000)
                if (currentSong == null) {
                    loadTimeout = true
                }
                isWaitingForNetSong = false
            }
        } else {
            if (currentSong == null || currentSong?.songId != songId) {
                vm.loadSongById(songId)
            }
        }
    }

    val displaySong = when {
        songId == -1 -> currentSong
        else -> {
            if (currentSong != null && currentSong?.songId == songId) {
                currentSong
            } else {
                val listState = songUiState.value.songList
                if (listState is UiState.Success) {
                    listState.data.find { it.songId == songId }
                } else null
            }
        }
    }

    // 播放状态
    var isPlaying by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    // 用于歌词滚动
    val lyricListState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    // 记录播放时间
    LaunchedEffect(isPlaying) {
        if (isPlaying && displaySong != null && displaySong.songId > 0) {
            vm.recordSongPlayed(displaySong.songId)
        }
    }

    // 模拟进度更新
    LaunchedEffect(isPlaying) {
        while (isPlaying) {
            delay(100)
            progress = (progress + 0.003f).coerceAtMost(1f)

            val currentTime = (progress * 180000).toLong() // ms
            val index = mockLyrics.indexOfLast { it.time <= currentTime }
            if (index >= 0) {
                lyricListState.animateScrollToItem(index)
            }
            if (progress >= 1f) {
                isPlaying = false
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = displaySong?.songName ?: "歌曲详情",
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { navCtrl.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "返回")
                    }
                },
                actions = {
                    if (displaySong != null) {
                        IconButton(
                            onClick = {
                                vm.toggleFavorite(
                                    displaySong,
                                    !displaySong.isFavorite
                                )
                            }
                        ) {
                            Icon(
                                imageVector = if (displaySong.isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                                contentDescription = if (displaySong.isFavorite) "取消收藏" else "收藏",
                                tint = if (displaySong.isFavorite) RedFavorite else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when {
                displaySong != null -> {
                    PlayerContentWithLyrics(
                        song = displaySong,
                        isPlaying = isPlaying,
                        onPlayToggle = { isPlaying = !isPlaying },
                        progress = progress,
                        onProgressChange = { progress = it },
                        lyrics = mockLyrics,
                        lyricListState = lyricListState
                    )
                }
                songId == -1 && isWaitingForNetSong -> LoadingLayout()
                songId == -1 && loadTimeout -> ErrorLayout("歌曲数据加载超时，请返回重试") { navCtrl.popBackStack() }
                songId == -1 -> ErrorLayout("歌曲数据丢失，请返回重试") { navCtrl.popBackStack() }
                else -> {
                    val listState = songUiState.value.songList
                    when (listState) {
                        is UiState.Loading -> LoadingLayout()
                        is UiState.Error -> ErrorLayout(listState.msg) {
                            vm.loadSongById(songId)
                        }
                        is UiState.Success -> {
                            if (listState.data.find { it.songId == songId } == null) {
                                ErrorLayout("未找到该歌曲，可能已被删除") { navCtrl.popBackStack() }
                            } else {
                                LoadingLayout()
                            }
                        }
                        is UiState.Empty -> ErrorLayout("歌单为空，无法播放") { navCtrl.popBackStack() }
                    }
                }
            }
        }
    }
}

@Composable
private fun PlayerContentWithLyrics(
    song: SongEntity,
    isPlaying: Boolean,
    onPlayToggle: () -> Unit,
    progress: Float,
    onProgressChange: (Float) -> Unit,
    lyrics: List<LyricLine>,
    lyricListState: androidx.compose.foundation.lazy.LazyListState
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Card(
                modifier = Modifier
                    .size(280.dp)
                    .clip(RoundedCornerShape(24.dp)),
                elevation = CardDefaults.cardElevation(8.dp)
            ) {
                AsyncImage(
                    model = song.coverUrl,
                    contentDescription = "专辑封面",
                    modifier = Modifier.fillMaxSize(),
                    error = painterResource(id = android.R.drawable.ic_menu_gallery)
                )
            }
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = song.songName,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
                textAlign = TextAlign.Center
            )
            Text(
                text = song.singer,
                fontSize = 16.sp,
                color = TextGray,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(8.dp))
        }

        // 进度条
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = formatTime(progress * 180f),
                    fontSize = 12.sp,
                    color = TextGray
                )
                Slider(
                    value = progress,
                    onValueChange = onProgressChange,
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 8.dp),
                    colors = SliderDefaults.colors(
                        thumbColor = MaterialTheme.colorScheme.primary,
                        activeTrackColor = MaterialTheme.colorScheme.primary
                    )
                )
                Text(
                    text = formatTime(180f),
                    fontSize = 12.sp,
                    color = TextGray
                )
            }
        }

        // 控制按钮
        item {
            Row(
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                IconButton(
                    onClick = { /* 上一首 */ },
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = "上一首", modifier = Modifier.size(32.dp))
                }
                Spacer(modifier = Modifier.width(16.dp))
                Surface(
                    modifier = Modifier.size(72.dp),
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primary,
                    onClick = onPlayToggle
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            contentDescription = if (isPlaying) "暂停" else "播放",
                            tint = Color.White,
                            modifier = Modifier.size(40.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.width(16.dp))
                IconButton(
                    onClick = { /* 下一首 */ },
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = "下一首", modifier = Modifier.size(32.dp))
                }
            }
        }

        // 歌词区域
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "歌词",
                fontSize = 18.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(8.dp))
        }

        // 歌词列表
        itemsIndexed(lyrics) { index, line ->
            val isCurrent = lyricListState.layoutInfo.visibleItemsInfo.any { it.index == index }
            Text(
                text = line.text,
                fontSize = if (isCurrent) 18.sp else 14.sp,
                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                color = if (isCurrent) MaterialTheme.colorScheme.primary else TextGray,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            )
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

private fun formatTime(totalSeconds: Float): String {
    val seconds = totalSeconds.toInt()
    val min = seconds / 60
    val sec = seconds % 60
    return String.format("%02d:%02d", min, sec)
}