package com.example.musiccollect.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.musiccollect.data.entity.SongEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface SongDao {
    // ---------- 原有方法 ----------
    @Query("SELECT * FROM song WHERE playlistId = :pid ORDER BY addTime DESC")
    fun getSongByPlaylist(pid: Int): Flow<List<SongEntity>>

    @Query("SELECT * FROM song WHERE playlistId = :pid AND (songName LIKE :keyword OR singer LIKE :keyword) ORDER BY addTime DESC")
    fun searchSongsInPlaylist(pid: Int, keyword: String): Flow<List<SongEntity>>

    @Query("SELECT * FROM song WHERE songName LIKE :keyword OR singer LIKE :keyword")
    fun searchSong(keyword: String): Flow<List<SongEntity>>

    @Query("SELECT * FROM song WHERE songId = :songId")
    suspend fun getSongById(songId: Int): SongEntity?

    @Insert
    suspend fun insert(song: SongEntity)

    @Update
    suspend fun update(song: SongEntity)

    @Delete
    suspend fun delete(song: SongEntity)

    @Query("DELETE FROM song WHERE playlistId = :pid")
    suspend fun deleteAllSongInPlaylist(pid: Int)

    @Query("SELECT DISTINCT singer FROM song")
    fun getDistinctSingers(): Flow<List<String>>

    @Query("SELECT * FROM song WHERE singer = :singerName ORDER BY addTime DESC LIMIT 1")
    suspend fun getFirstSongBySinger(singerName: String): SongEntity?

    @Query("SELECT * FROM song WHERE singer = :singerName ORDER BY addTime DESC")
    fun getSongsBySinger(singerName: String): Flow<List<SongEntity>>

    // ---------- 新增收藏相关 ----------
    @Query("SELECT * FROM song WHERE isFavorite = 1 ORDER BY addTime DESC")
    fun getFavoriteSongs(): Flow<List<SongEntity>>

    // ---------- 新增最近播放 ----------
    @Query("SELECT * FROM song WHERE lastPlayTime > 0 ORDER BY lastPlayTime DESC LIMIT 50")
    fun getRecentPlaySongs(): Flow<List<SongEntity>>

    // ---------- 更新播放时间 ----------
    @Query("UPDATE song SET lastPlayTime = :time WHERE songId = :songId")
    suspend fun updateLastPlayTime(songId: Int, time: Long)
}