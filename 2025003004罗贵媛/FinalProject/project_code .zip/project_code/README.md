# BookShelf - 图书管理应用

移动端软件开发期末大作业

## 应用简介

BookShelf 是一款基于 Kotlin + Jetpack Compose 构建的 Android 图书管理应用。用户可以搜索在线图书信息，将感兴趣的书籍添加到个人书架，管理阅读状态、评分和笔记。

## 运行环境

- Android Studio Hedgehog (2023.1.1) 或更高版本
- Gradle 8.5
- JDK 17
- 最低 Android API 26 (Android 8.0)
- 目标 Android API 34 (Android 14)

## 运行步骤

1. 使用 Android Studio 打开本项目
2. 等待 Gradle 同步完成
3. 连接模拟器或真机
4. 点击 Run 运行

## 技术栈

- **UI**: Jetpack Compose + Material 3
- **数据库**: Room (2 张表: books, categories)
- **网络**: Retrofit + OkHttp (Open Library API)
- **状态管理**: ViewModel + StateFlow + UiState
- **持久化偏好**: DataStore Preferences
- **导航**: Navigation Compose
- **异步**: Kotlin Coroutines
- **图片加载**: Coil

## 项目结构

```
app/src/main/java/com/example/bookshelf/
├── MainActivity.kt
├── BookshelfApp.kt
├── data/
│   ├── network/          # 网络层 (Retrofit)
│   ├── entity/           # Room Entity
│   ├── dao/              # Room DAO
│   ├── database/         # Room Database
│   └── repository/       # Repository
├── datastore/           # DataStore 偏好存储
├── model/               # 数据模型
├── navigation/          # Compose Navigation
├── ui/
│   ├── screens/         # 页面 (Home/Search/Detail/Edit/Settings)
│   ├── components/      # 可复用组件
│   └── theme/           # Material 3 主题
└── viewmodel/           # ViewModel + UiState
```
