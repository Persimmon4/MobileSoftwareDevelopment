package com.example.bookshelf.data.repository

import com.example.bookshelf.data.dao.BookDao
import com.example.bookshelf.data.dao.CategoryDao
import com.example.bookshelf.data.entity.BookEntity
import com.example.bookshelf.data.entity.CategoryEntity
import com.example.bookshelf.data.network.NetworkDataSource
import com.example.bookshelf.data.network.dto.OpenLibraryDoc
import com.example.bookshelf.model.Book
import io.mockk.*
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.test.*
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Rule
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class BookRepositoryTest {

    @get:Rule
    val mainDispatcherRule = MainDispatcherRule()

    private lateinit var bookDao: BookDao
    private lateinit var categoryDao: CategoryDao
    private lateinit var networkDataSource: NetworkDataSource
    private lateinit var repository: BookRepository

    @Before
    fun setUp() {
        bookDao = mockk(relaxed = true)
        categoryDao = mockk(relaxed = true)
        networkDataSource = mockk(relaxed = true)
        repository = BookRepository(bookDao, categoryDao, networkDataSource)
    }

    @After
    fun tearDown() {
        unmockkAll()
    }

    // ===== Local Data Tests =====

    @Test
    fun `getAllBooks maps entities to domain model`() = runTest {
        val entities = listOf(
            BookEntity(id = 1, title = "Book 1", author = "Author 1", categoryId = 1),
            BookEntity(id = 2, title = "Book 2", author = "Author 2", categoryId = 1)
        )
        every { bookDao.getAllBooks() } returns flowOf(entities)

        val books = repository.getAllBooks().first()
        assertEquals(2, books.size)
        assertEquals("Book 1", books[0].title)
        assertEquals("Book 2", books[1].title)
        assertTrue(books.all { it is Book })
    }

    @Test
    fun `getAllBooks returns empty list when no books`() = runTest {
        every { bookDao.getAllBooks() } returns flowOf(emptyList())

        val books = repository.getAllBooks().first()
        assertTrue(books.isEmpty())
    }

    @Test
    fun `searchLocalBooks delegates to bookDao searchBooks`() = runTest {
        val entities = listOf(
            BookEntity(id = 1, title = "Kotlin", author = "Author", categoryId = 1)
        )
        every { bookDao.searchBooks("Kotlin") } returns flowOf(entities)

        val books = repository.searchLocalBooks("Kotlin").first()
        assertEquals(1, books.size)
        assertEquals("Kotlin", books[0].title)
    }

    @Test
    fun `filterAndSortBooks delegates to bookDao`() = runTest {
        val entities = listOf(
            BookEntity(id = 1, title = "A", author = "B", categoryId = 1, readingStatus = "READING")
        )
        every { bookDao.filterAndSortBooks("READING", 1, "title") } returns flowOf(entities)

        val books = repository.filterAndSortBooks("READING", 1, "title").first()
        assertEquals(1, books.size)
        assertEquals("READING", books[0].readingStatus)
    }

    @Test
    fun `getBookById returns domain model when found`() = runTest {
        val entity = BookEntity(id = 1, title = "Test", author = "Author", categoryId = 1)
        coEvery { bookDao.getBookById(1) } returns entity

        val book = repository.getBookById(1)
        assertNotNull(book)
        assertEquals("Test", book!!.title)
        assertEquals("Author", book.author)
    }

    @Test
    fun `getBookById returns null when not found`() = runTest {
        coEvery { bookDao.getBookById(999) } returns null

        val book = repository.getBookById(999)
        assertNull(book)
    }

    @Test
    fun `insertBook delegates to bookDao and returns id`() = runTest {
        val entity = BookEntity(title = "New", author = "Author", categoryId = 1)
        coEvery { bookDao.insertBook(entity) } returns 42L

        val id = repository.insertBook(entity)
        assertEquals(42L, id)
        coVerify(exactly = 1) { bookDao.insertBook(entity) }
    }

    @Test
    fun `updateBook delegates to bookDao`() = runTest {
        val entity = BookEntity(id = 1, title = "Updated", author = "Author", categoryId = 1)
        coEvery { bookDao.updateBook(entity) } just Runs

        repository.updateBook(entity)
        coVerify(exactly = 1) { bookDao.updateBook(entity) }
    }

    @Test
    fun `deleteBookById delegates to bookDao`() = runTest {
        coEvery { bookDao.deleteBookById(1) } just Runs

        repository.deleteBookById(1)
        coVerify(exactly = 1) { bookDao.deleteBookById(1) }
    }

    @Test
    fun `getBookCountByStatus delegates to bookDao`() = runTest {
        coEvery { bookDao.getBookCountByStatus("READING") } returns 5

        val count = repository.getBookCountByStatus("READING")
        assertEquals(5, count)
    }

    // ===== Category Tests =====

    @Test
    fun `getAllCategories delegates to categoryDao`() = runTest {
        val categories = listOf(
            CategoryEntity(id = 1, name = "Fiction"),
            CategoryEntity(id = 2, name = "Science")
        )
        every { categoryDao.getAllCategories() } returns flowOf(categories)

        val result = repository.getAllCategories().first()
        assertEquals(2, result.size)
        assertEquals("Fiction", result[0].name)
    }

    @Test
    fun `insertCategory delegates to categoryDao`() = runTest {
        val category = CategoryEntity(name = "History")
        coEvery { categoryDao.insertCategory(category) } returns 3L

        val id = repository.insertCategory(category)
        assertEquals(3L, id)
    }

    @Test
    fun `getCategoryByName finds existing category`() = runTest {
        val category = CategoryEntity(id = 1, name = "Fiction")
        coEvery { categoryDao.getCategoryByName("Fiction") } returns category

        val result = repository.getCategoryByName("Fiction")
        assertNotNull(result)
        assertEquals("Fiction", result!!.name)
    }

    @Test
    fun `getCategoryByName returns null for unknown category`() = runTest {
        coEvery { categoryDao.getCategoryByName("Unknown") } returns null

        val result = repository.getCategoryByName("Unknown")
        assertNull(result)
    }

    @Test
    fun `getBookCountInCategory delegates to categoryDao`() = runTest {
        coEvery { categoryDao.getBookCountInCategory(1) } returns 10

        val count = repository.getBookCountInCategory(1)
        assertEquals(10, count)
    }

    // ===== Network Tests =====

    @Test
    fun `searchOnlineBooks returns success with results`() = runTest {
        val docs = listOf(
            OpenLibraryDoc(title = "Book 1", authorName = listOf("A"), coverI = 123L,
                firstPublishYear = 2020, isbn = listOf("ISBN1"), numberOfPagesMedian = 200,
                subjects = listOf("Sci-Fi"))
        )
        coEvery { networkDataSource.searchBooks("test") } returns Result.success(docs)

        val result = repository.searchOnlineBooks("test")
        assertTrue(result.isSuccess)
        assertEquals(1, result.getOrNull()?.size)
        assertEquals("Book 1", result.getOrNull()?.get(0)?.title)
    }

    @Test
    fun `searchOnlineBooks returns failure on network error`() = runTest {
        val exception = RuntimeException("Network error")
        coEvery { networkDataSource.searchBooks("test") } returns Result.failure(exception)

        val result = repository.searchOnlineBooks("test")
        assertTrue(result.isFailure)
        assertEquals("Network error", result.exceptionOrNull()?.message)
    }

    // ===== JSON Export Tests =====

    @Test
    fun `exportBooksToJson produces valid JSON array`() = runTest {
        val books = listOf(
            Book(id = 1, title = "Book One", author = "Author One", categoryId = 1,
                readingStatus = "READING", rating = 4.0f, publishYear = 2023,
                isbn = "111", pageCount = 300, coverUrl = "http://c.jpg",
                notes = "Nice", description = "Desc", createdAt = 1000L, updatedAt = 2000L),
            Book(id = 2, title = "Book Two", author = "Author Two", categoryId = 2,
                readingStatus = "FINISHED", rating = null, publishYear = null,
                isbn = null, pageCount = null, coverUrl = null,
                notes = null, description = null, createdAt = 3000L, updatedAt = 4000L)
        )
        every { bookDao.getAllBooks() } returns flowOf(
            books.map { BookEntity(
                id = it.id, title = it.title, author = it.author,
                coverUrl = it.coverUrl, description = it.description,
                publishYear = it.publishYear, isbn = it.isbn,
                categoryId = it.categoryId, readingStatus = it.readingStatus,
                rating = it.rating, notes = it.notes, pageCount = it.pageCount,
                createdAt = it.createdAt, updatedAt = it.updatedAt
            )}
        )

        val json = repository.exportBooksToJson()
        assertTrue(json.contains("Book One"))
        assertTrue(json.contains("Book Two"))
        assertTrue(json.startsWith("["))
        assertTrue(json.endsWith("]"))
    }

    @Test
    fun `exportBooksToJson handles empty list`() = runTest {
        every { bookDao.getAllBooks() } returns flowOf(emptyList())

        val json = repository.exportBooksToJson()
        assertEquals("[]", json.trim())
    }

    // ===== JSON Import Tests =====

    @Test
    fun `importBooksFromJson parses valid JSON and inserts books`() = runTest {
        val json = """
        [
            {
                "id": 1,
                "title": "Imported Book",
                "author": "Imported Author",
                "coverUrl": "http://cover.jpg",
                "description": "Test desc",
                "publishYear": 2023,
                "isbn": "123456",
                "categoryId": 2,
                "readingStatus": "READING",
                "rating": 4.5,
                "notes": "Nice",
                "pageCount": 250,
                "createdAt": 1000,
                "updatedAt": 2000
            },
            {
                "id": 2,
                "title": "Second Book",
                "author": "Second Author",
                "categoryId": 1,
                "readingStatus": "WANT_TO_READ"
            }
        ]
        """.trimIndent()

        coEvery { bookDao.insertBook(any()) } returnsMany listOf(1L, 2L)

        val count = repository.importBooksFromJson(json)
        assertEquals(2, count)
        coVerify(exactly = 2) { bookDao.insertBook(any()) }
    }

    @Test
    fun `importBooksFromJson returns zero for empty array`() = runTest {
        val count = repository.importBooksFromJson("[]")
        assertEquals(0, count)
        coVerify(exactly = 0) { bookDao.insertBook(any()) }
    }
}
