package com.example.bookshelf.viewmodel

import com.example.bookshelf.model.Book
import org.junit.Assert.*
import org.junit.Test

class UiStateTest {

    // ===== HomeUiState =====

    @Test
    fun `HomeUiState isLoading defaults to true`() {
        val state = HomeUiState()
        assertTrue(state.isLoading)
    }

    @Test
    fun `HomeUiState isEmpty is true when not loading, no error, and no books`() {
        val state = HomeUiState(isLoading = false, error = null, books = emptyList())
        assertTrue(state.isEmpty)
    }

    @Test
    fun `HomeUiState isEmpty is false when loading`() {
        val state = HomeUiState(isLoading = true, books = emptyList())
        assertFalse(state.isEmpty)
    }

    @Test
    fun `HomeUiState isEmpty is false when has books`() {
        val state = HomeUiState(isLoading = false, books = listOf(Book(
            id = 1, title = "T", author = "A", categoryId = 1
        )))
        assertFalse(state.isEmpty)
    }

    @Test
    fun `HomeUiState isEmpty is false when has error`() {
        val state = HomeUiState(isLoading = false, error = "Error", books = emptyList())
        assertFalse(state.isEmpty)
    }

    @Test
    fun `HomeUiState isSearchActive is true when query not empty`() {
        val state = HomeUiState(searchQuery = "Kotlin")
        assertTrue(state.isSearchActive)
    }

    @Test
    fun `HomeUiState isSearchActive is false when query is empty`() {
        val state = HomeUiState(searchQuery = "")
        assertFalse(state.isSearchActive)
    }

    // ===== SearchUiState (sealed interface) =====

    @Test
    fun `SearchUiState Idle is singleton`() {
        val state1 = SearchUiState.Idle
        val state2 = SearchUiState.Idle
        assertSame(state1, state2)
    }

    @Test
    fun `SearchUiState Loading carries query`() {
        val state = SearchUiState.Loading("Android")
        assertEquals("Android", state.query)
    }

    @Test
    fun `SearchUiState Success carries results and query`() {
        val items = listOf(
            OnlineBookItem("Book1", "Author1", 123L, 2023, "ISBN1", 200, listOf("Tech"), "url")
        )
        val state = SearchUiState.Success(items, "query")
        assertEquals(1, state.results.size)
        assertEquals("query", state.query)
        assertEquals("Book1", state.results[0].title)
    }

    @Test
    fun `SearchUiState Error carries message and query`() {
        val state = SearchUiState.Error("Network error", "test query")
        assertEquals("Network error", state.message)
        assertEquals("test query", state.query)
    }

    @Test
    fun `SearchUiState is exhaustive sealed interface`() {
        // Pattern match all variants to ensure exhaustiveness
        fun handle(state: SearchUiState): String = when (state) {
            is SearchUiState.Idle -> "idle"
            is SearchUiState.Loading -> "loading"
            is SearchUiState.Success -> "success"
            is SearchUiState.Error -> "error"
        }

        assertEquals("idle", handle(SearchUiState.Idle))
        assertEquals("loading", handle(SearchUiState.Loading("q")))
        assertEquals("success", handle(SearchUiState.Success(emptyList(), "q")))
        assertEquals("error", handle(SearchUiState.Error("err", "q")))
    }

    // ===== DetailUiState =====

    @Test
    fun `DetailUiState isLoading defaults to true`() {
        val state = DetailUiState()
        assertTrue(state.isLoading)
    }

    @Test
    fun `DetailUiState book is null by default`() {
        val state = DetailUiState()
        assertNull(state.book)
        assertNull(state.error)
    }

    // ===== EditUiState =====

    @Test
    fun `EditUiState has correct defaults`() {
        val state = EditUiState()
        assertEquals("", state.title)
        assertEquals("", state.author)
        assertEquals(1, state.categoryId)
        assertEquals("WANT_TO_READ", state.readingStatus)
        assertEquals(0f, state.rating)
        assertFalse(state.isEditMode)
        assertFalse(state.isSaving)
        assertFalse(state.saveSuccess)
        assertNull(state.titleError)
        assertNull(state.authorError)
        assertNull(state.error)
    }

    @Test
    fun `EditUiState copy preserves values`() {
        val state = EditUiState(title = "Book")
        val updated = state.copy(author = "Author")
        assertEquals("Book", updated.title)
        assertEquals("Author", updated.author)
    }

    // ===== SettingsUiState =====

    @Test
    fun `SettingsUiState has correct defaults`() {
        val state = SettingsUiState()
        assertEquals("SYSTEM", state.themeMode)
        assertEquals("date", state.sortOrder)
        assertEquals(0, state.totalBooks)
        assertEquals(0, state.readingCount)
        assertEquals(0, state.finishedCount)
        assertEquals(0, state.wantToReadCount)
    }

    // ===== OnlineBookItem =====

    @Test
    fun `OnlineBookItem fields are correct`() {
        val item = OnlineBookItem(
            title = "Kotlin in Action",
            author = "Dmitry Jemerov",
            coverI = 123L,
            publishYear = 2017,
            isbn = "9781617293290",
            pageCount = 360,
            subjects = listOf("Programming", "Kotlin"),
            coverUrl = "https://covers.openlibrary.org/b/id/123-M.jpg"
        )
        assertEquals("Kotlin in Action", item.title)
        assertEquals("Dmitry Jemerov", item.author)
        assertEquals(123L, item.coverI)
        assertEquals(2017, item.publishYear)
        assertEquals("9781617293290", item.isbn)
        assertEquals(360, item.pageCount)
        assertEquals(2, item.subjects?.size)
    }

    // ===== CategoryItem =====

    @Test
    fun `CategoryItem fields are correct`() {
        val item = CategoryItem(id = 1, name = "Fiction", bookCount = 15)
        assertEquals(1, item.id)
        assertEquals("Fiction", item.name)
        assertEquals(15, item.bookCount)
    }
}
