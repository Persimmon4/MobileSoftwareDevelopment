package com.example.bookshelf.viewmodel

import com.example.bookshelf.data.entity.BookEntity
import com.example.bookshelf.data.entity.CategoryEntity
import com.example.bookshelf.data.repository.BookRepository
import com.example.bookshelf.model.Book
import io.mockk.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.test.*
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Rule
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class EditViewModelTest {

    @get:Rule
    val mainDispatcherRule = MainDispatcherRule()

    private lateinit var repository: BookRepository
    private lateinit var viewModel: EditViewModel

    @Before
    fun setUp() {
        repository = mockk(relaxed = true)
        every { repository.getAllCategories() } returns flowOf(emptyList())
    }

    @After
    fun tearDown() {
        unmockkAll()
    }

    // ===== Add Mode Tests =====

    @Test
    fun `initial state in add mode has empty fields`() = runTest {
        viewModel = EditViewModel(repository, bookId = null)
        val state = viewModel.uiState.value

        assertFalse(state.isEditMode)
        assertEquals("", state.title)
        assertEquals("", state.author)
        assertEquals("WANT_TO_READ", state.readingStatus)
        assertFalse(state.isSaving)
        assertFalse(state.saveSuccess)
    }

    @Test
    fun `initial state in edit mode loads existing book`() = runTest {
        val existingBook = Book(
            id = 1, title = "Test Title", author = "Test Author",
            categoryId = 1, readingStatus = "READING",
            rating = 4.0f, publishYear = 2023, isbn = "1234567890",
            pageCount = 300, coverUrl = "http://cover.jpg",
            notes = "Great book", description = "Desc",
            createdAt = 1000L
        )
        val categoryFlow = flowOf(listOf(CategoryEntity(id = 1, name = "Fiction")))

        coEvery { repository.getBookById(1) } returns existingBook
        every { repository.getAllCategories() } returns categoryFlow

        viewModel = EditViewModel(repository, bookId = 1)
        advanceUntilIdle()

        val state = viewModel.uiState.value
        assertTrue(state.isEditMode)
        assertEquals("Test Title", state.title)
        assertEquals("Test Author", state.author)
        assertEquals("2023", state.publishYear)
        assertEquals("1234567890", state.isbn)
        assertEquals("300", state.pageCount)
        assertEquals("http://cover.jpg", state.coverUrl)
        assertEquals("Great book", state.notes)
        assertEquals("Desc", state.description)
        assertEquals("READING", state.readingStatus)
        assertEquals(4.0f, state.rating)
        assertEquals(1000L, state.createdAt)
    }

    // ===== Validation Tests =====

    @Test
    fun `save fails when title is blank`() = runTest {
        viewModel = EditViewModel(repository, bookId = null)

        viewModel.onTitleChange(" ")
        viewModel.onAuthorChange("Author")
        viewModel.save {}

        val state = viewModel.uiState.value
        assertEquals("书名不能为空", state.titleError)
    }

    @Test
    fun `save fails when author is blank`() = runTest {
        viewModel = EditViewModel(repository, bookId = null)

        viewModel.onTitleChange("Title")
        viewModel.onAuthorChange("")
        viewModel.save {}

        val state = viewModel.uiState.value
        assertEquals("作者不能为空", state.authorError)
    }

    @Test
    fun `save fails when publish year is invalid`() = runTest {
        viewModel = EditViewModel(repository, bookId = null)

        viewModel.onTitleChange("Title")
        viewModel.onAuthorChange("Author")
        viewModel.onPublishYearChange("3000")
        viewModel.save {}

        val state = viewModel.uiState.value
        assertEquals("出版年份格式不正确", state.error)
    }

    @Test
    fun `save fails when publish year is negative`() = runTest {
        viewModel = EditViewModel(repository, bookId = null)

        viewModel.onTitleChange("Title")
        viewModel.onAuthorChange("Author")
        viewModel.onPublishYearChange("-5")
        viewModel.save {}

        val state = viewModel.uiState.value
        assertEquals("出版年份格式不正确", state.error)
    }

    @Test
    fun `save fails when page count is invalid`() = runTest {
        viewModel = EditViewModel(repository, bookId = null)

        viewModel.onTitleChange("Title")
        viewModel.onAuthorChange("Author")
        viewModel.onPageCountChange("abc")
        viewModel.save {}

        val state = viewModel.uiState.value
        assertEquals("页数格式不正确", state.error)
    }

    @Test
    fun `save fails when page count is zero`() = runTest {
        viewModel = EditViewModel(repository, bookId = null)

        viewModel.onTitleChange("Title")
        viewModel.onAuthorChange("Author")
        viewModel.onPageCountChange("0")
        viewModel.save {}

        val state = viewModel.uiState.value
        assertEquals("页数格式不正确", state.error)
    }

    // ===== Save Success Tests =====

    @Test
    fun `save in add mode inserts book`() = runTest {
        viewModel = EditViewModel(repository, bookId = null)

        coEvery { repository.insertBook(any()) } returns 1L

        viewModel.onTitleChange("New Book")
        viewModel.onAuthorChange("Author Name")
        viewModel.onPublishYearChange("2024")
        viewModel.onPageCountChange("350")
        viewModel.onCategoryChange(2)
        viewModel.onReadingStatusChange("READING")
        viewModel.onRatingChange(3.5f)
        viewModel.onNotesChange("Nice")
        viewModel.onDescriptionChange("Desc")

        viewModel.save {
            // onSuccess callback
        }
        advanceUntilIdle()

        val state = viewModel.uiState.value
        assertTrue(state.saveSuccess)
        assertFalse(state.isSaving)
        coVerify(exactly = 1) { repository.insertBook(any()) }
        coVerify(exactly = 0) { repository.updateBook(any()) }
    }

    @Test
    fun `save in edit mode updates book and preserves createdAt`() = runTest {
        val existingBook = Book(
            id = 5, title = "Old Title", author = "Old Author",
            categoryId = 1, readingStatus = "WANT_TO_READ",
            createdAt = 99999L
        )
        every { repository.getAllCategories() } returns flowOf(emptyList())
        coEvery { repository.getBookById(5) } returns existingBook
        coEvery { repository.updateBook(any()) } just Runs

        viewModel = EditViewModel(repository, bookId = 5)
        advanceUntilIdle()

        viewModel.onTitleChange("Updated Title")
        viewModel.onAuthorChange("Updated Author")

        viewModel.save {}
        advanceUntilIdle()

        val state = viewModel.uiState.value
        assertTrue(state.saveSuccess)
        coVerify(exactly = 1) { repository.updateBook(any()) }
        coVerify(exactly = 0) { repository.insertBook(any()) }
    }

    @Test
    fun `save handles repository error gracefully`() = runTest {
        viewModel = EditViewModel(repository, bookId = null)

        coEvery { repository.insertBook(any()) } throws RuntimeException("DB error")

        viewModel.onTitleChange("Book")
        viewModel.onAuthorChange("Author")
        viewModel.save {}
        advanceUntilIdle()

        val state = viewModel.uiState.value
        assertFalse(state.saveSuccess)
        assertTrue(state.error?.contains("保存失败") == true)
    }

    // ===== Field Change Tests =====

    @Test
    fun `onTitleChange updates title and clears error`() {
        viewModel = EditViewModel(repository, bookId = null)
        // First set an error
        viewModel.onTitleChange(" ")
        viewModel.onAuthorChange("Author")
        viewModel.save {}
        assertEquals("书名不能为空", viewModel.uiState.value.titleError)

        // Now change title — error should clear
        viewModel.onTitleChange("Fixed Title")
        val state = viewModel.uiState.value
        assertEquals("Fixed Title", state.title)
        assertNull(state.titleError)
    }

    @Test
    fun `onAuthorChange updates author and clears error`() {
        viewModel = EditViewModel(repository, bookId = null)
        viewModel.onTitleChange("Title")
        viewModel.onAuthorChange("")
        viewModel.save {}
        assertEquals("作者不能为空", viewModel.uiState.value.authorError)

        viewModel.onAuthorChange("Fixed Author")
        val state = viewModel.uiState.value
        assertEquals("Fixed Author", state.author)
        assertNull(state.authorError)
    }

    @Test
    fun `clearError clears error state`() {
        viewModel = EditViewModel(repository, bookId = null)

        viewModel.onTitleChange("Title")
        viewModel.onAuthorChange("Author")
        viewModel.onPublishYearChange("5000")
        viewModel.save {}

        assertNotNull(viewModel.uiState.value.error)

        viewModel.clearError()
        assertNull(viewModel.uiState.value.error)
    }

    @Test
    fun `field changes update corresponding state properties`() {
        viewModel = EditViewModel(repository, bookId = null)

        viewModel.onPublishYearChange("2025")
        viewModel.onIsbnChange("978-3-16")
        viewModel.onPageCountChange("400")
        viewModel.onCoverUrlChange("http://img.jpg")
        viewModel.onNotesChange("test note")
        viewModel.onDescriptionChange("test desc")
        viewModel.onReadingStatusChange("FINISHED")
        viewModel.onRatingChange(5.0f)
        viewModel.onCategoryChange(3)

        val state = viewModel.uiState.value
        assertEquals("2025", state.publishYear)
        assertEquals("978-3-16", state.isbn)
        assertEquals("400", state.pageCount)
        assertEquals("http://img.jpg", state.coverUrl)
        assertEquals("test note", state.notes)
        assertEquals("test desc", state.description)
        assertEquals("FINISHED", state.readingStatus)
        assertEquals(5.0f, state.rating)
        assertEquals(3, state.categoryId)
    }
}
