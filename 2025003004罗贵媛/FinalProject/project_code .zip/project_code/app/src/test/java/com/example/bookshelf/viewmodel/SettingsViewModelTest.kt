package com.example.bookshelf.viewmodel

import com.example.bookshelf.data.repository.BookRepository
import com.example.bookshelf.datastore.UserPreferencesRepository
import io.mockk.*
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.test.*
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Rule
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class SettingsViewModelTest {

    @get:Rule
    val mainDispatcherRule = MainDispatcherRule()

    private lateinit var repository: BookRepository
    private lateinit var userPreferences: UserPreferencesRepository

    @Before
    fun setUp() {
        repository = mockk(relaxed = true)
        userPreferences = mockk(relaxed = true)

        // Setup preferences Flows
        every { userPreferences.themeMode } returns flowOf("SYSTEM")
        every { userPreferences.sortOrder } returns flowOf("date")
    }

    @After
    fun tearDown() {
        unmockkAll()
    }

    // ===== Preferences Loading =====

    @Test
    fun `loads theme mode from preferences`() = runTest {
        every { userPreferences.themeMode } returns flowOf("DARK")

        val viewModel = SettingsViewModel(repository, userPreferences)
        advanceUntilIdle()

        assertEquals("DARK", viewModel.uiState.value.themeMode)
    }

    @Test
    fun `loads sort order from preferences`() = runTest {
        every { userPreferences.sortOrder } returns flowOf("title")

        val viewModel = SettingsViewModel(repository, userPreferences)
        advanceUntilIdle()

        assertEquals("title", viewModel.uiState.value.sortOrder)
    }

    // ===== Stats Loading =====

    @Test
    fun `loads reading statistics correctly`() = runTest {
        coEvery { repository.getBookCountByStatus("READING") } returns 3
        coEvery { repository.getBookCountByStatus("FINISHED") } returns 10
        coEvery { repository.getBookCountByStatus("WANT_TO_READ") } returns 7

        val viewModel = SettingsViewModel(repository, userPreferences)
        advanceUntilIdle()

        val state = viewModel.uiState.value
        assertEquals(3, state.readingCount)
        assertEquals(10, state.finishedCount)
        assertEquals(7, state.wantToReadCount)
        assertEquals(20, state.totalBooks)
    }

    @Test
    fun `stats default to zero when no books`() = runTest {
        coEvery { repository.getBookCountByStatus(any()) } returns 0

        val viewModel = SettingsViewModel(repository, userPreferences)
        advanceUntilIdle()

        val state = viewModel.uiState.value
        assertEquals(0, state.readingCount)
        assertEquals(0, state.finishedCount)
        assertEquals(0, state.wantToReadCount)
        assertEquals(0, state.totalBooks)
    }

    // ===== Theme Mode Change =====

    @Test
    fun `setThemeMode updates state and persists`() = runTest {
        coEvery { userPreferences.setThemeMode(any()) } just Runs

        val viewModel = SettingsViewModel(repository, userPreferences)
        advanceUntilIdle()

        viewModel.setThemeMode("LIGHT")
        advanceUntilIdle()

        assertEquals("LIGHT", viewModel.uiState.value.themeMode)
        coVerify(exactly = 1) { userPreferences.setThemeMode("LIGHT") }
    }

    @Test
    fun `setThemeMode supports SYSTEM mode`() = runTest {
        coEvery { userPreferences.setThemeMode(any()) } just Runs

        val viewModel = SettingsViewModel(repository, userPreferences)
        advanceUntilIdle()

        viewModel.setThemeMode("SYSTEM")
        advanceUntilIdle()

        assertEquals("SYSTEM", viewModel.uiState.value.themeMode)
        coVerify(exactly = 1) { userPreferences.setThemeMode("SYSTEM") }
    }

    // ===== Sort Order Change =====

    @Test
    fun `setSortOrder updates state and persists`() = runTest {
        coEvery { userPreferences.setSortOrder(any()) } just Runs

        val viewModel = SettingsViewModel(repository, userPreferences)
        advanceUntilIdle()

        viewModel.setSortOrder("rating")
        advanceUntilIdle()

        assertEquals("rating", viewModel.uiState.value.sortOrder)
        coVerify(exactly = 1) { userPreferences.setSortOrder("rating") }
    }

    @Test
    fun `setSortOrder supports multiple sort options`() = runTest {
        coEvery { userPreferences.setSortOrder(any()) } just Runs

        val viewModel = SettingsViewModel(repository, userPreferences)
        advanceUntilIdle()

        viewModel.setSortOrder("title")
        advanceUntilIdle()
        assertEquals("title", viewModel.uiState.value.sortOrder)

        viewModel.setSortOrder("date")
        advanceUntilIdle()
        assertEquals("date", viewModel.uiState.value.sortOrder)
    }

    // ===== Initial State =====

    @Test
    fun `initial state has default values`() {
        val viewModel = SettingsViewModel(repository, userPreferences)
        val state = viewModel.uiState.value

        assertEquals("SYSTEM", state.themeMode)
    }
}
