package com.example.bookshelf.util

import com.example.bookshelf.data.network.NetworkDataSource
import org.junit.Assert.*
import org.junit.Test

class NetworkUtilsTest {

    @Test
    fun `getCoverUrl returns null when coverI is null`() {
        val url = NetworkDataSource.getCoverUrl(null)
        assertNull(url)
    }

    @Test
    fun `getCoverUrl formats URL correctly`() {
        val url = NetworkDataSource.getCoverUrl(12345678L)
        assertEquals(
            "https://covers.openlibrary.org/b/id/12345678-M.jpg",
            url
        )
    }

    @Test
    fun `getCoverUrl formats URL with different IDs`() {
        val url1 = NetworkDataSource.getCoverUrl(1L)
        val url2 = NetworkDataSource.getCoverUrl(99999999L)

        assertEquals("https://covers.openlibrary.org/b/id/1-M.jpg", url1)
        assertEquals("https://covers.openlibrary.org/b/id/99999999-M.jpg", url2)
    }
}
