package com.example.bookshelf.viewmodel

import com.example.bookshelf.data.entity.BookEntity
import com.example.bookshelf.data.repository.BookRepository
import com.example.bookshelf.model.Book
import io.mockk.*
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.*
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Rule
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class DetailViewModelTest {

    @get:Rule
    val mainDispatcherRule = MainDispatcherRule()

    private lateinit var repository: BookRepository
    private val testBookId = 1

    private val sampleBook = Book(
        id = 1, title = "Sample Book", author = "Sample Author",
        categoryId = 1, readingStatus = "WANT_TO_READ",
        rating = 3.0f, publishYear = 2022, isbn = "111-222",
        pageCount = 200, coverUrl = "http://cover.jpg",
        notes = "Some notes", description = "Description",
        createdAt = 1000L, updatedAt = 2000L
    )

    @Before
    fun setUp() {
        repository = mockk(relaxed = true)
    }

    @After
    fun tearDown() {
        unmockkAll()
    }

    // ===== Load Book Tests =====

    @Test
    fun `loads book successfully`() = runTest {
        coEvery { repository.getBookById(testBookId) } returns sampleBook

        val viewModel = DetailViewModel(repository, testBookId)
        advanceUntilIdle()

        val state = viewModel.uiState.value
        assertFalse(state.isLoading)
        assertNull(state.error)
        assertNotNull(state.book)
        assertEquals("Sample Book", state.book?.title)
        assertEquals("Sample Author", state.book?.author)
        assertEquals(3.0f, state.book?.rating)
    }

    @Test
    fun `shows error when book not found`() = runTest {
        coEvery { repository.getBookById(testBookId) } returns null

        val viewModel = DetailViewModel(repository, testBookId)
        advanceUntilIdle()

        val state = viewModel.uiState.value
        assertFalse(state.isLoading)
        assertEquals("未找到该书籍", state.error)
        assertNull(state.book)
    }

    @Test
    fun `shows error when repository throws exception`() = runTest {
        coEvery { repository.getBookById(testBookId) } throws RuntimeException("DB crash")

        val viewModel = DetailViewModel(repository, testBookId)
        advanceUntilIdle()

        val state = viewModel.uiState.value
        assertFalse(state.isLoading)
        assertTrue(state.error?.contains("加载失败") == true)
        assertNull(state.book)
    }

    @Test
    fun `initial state shows loading`() {
        coEvery { repository.getBookById(testBookId) } returns sampleBook

        val viewModel = DetailViewModel(repository, testBookId)
        // Immediately after init, before coroutine completes
        val state = viewModel.uiState.value
        assertTrue(state.isLoading)
    }

    // ===== Update Reading Status Tests =====

    @Test
    fun `updateReadingStatus updates book and persists to repository`() = runTest {
        coEvery { repository.getBookById(testBookId) } returns sampleBook
        coEvery { repository.updateBook(any()) } just Runs

        val viewModel = DetailViewModel(repository, testBookId)
        advanceUntilIdle()

        viewModel.updateReadingStatus("READING")
        advanceUntilIdle()

        val state = viewModel.uiState.value
        assertEquals("READING", state.book?.readingStatus)
        coVerify(exactly = 1) { repository.updateBook(any()) }
    }

    @Test
    fun `updateReadingStatus does nothing when book is null`() = runTest {
        coEvery { repository.getBookById(testBookId) } returns null

        val viewModel = DetailViewModel(repository, testBookId)
        advanceUntilIdle()

        viewModel.updateReadingStatus("FINISHED")
        advanceUntilIdle()

        assertNull(viewModel.uiState.value.book)
        coVerify(exactly = 0) { repository.updateBook(any()) }
    }

    // ===== Update Rating Tests =====

    @Test
    fun `updateRating updates book rating and persists`() = runTest {
        coEvery { repository.getBookById(testBookId) } returns sampleBook
        coEvery { repository.updateBook(any()) } just Runs

        val viewModel = DetailViewModel(repository, testBookId)
        advanceUntilIdle()

        viewModel.updateRating(5.0f)
        advanceUntilIdle()

        val state = viewModel.uiState.value
        assertEquals(5.0f, state.book?.rating)
        coVerify(exactly = 1) { repository.updateBook(any()) }
    }

    @Test
    fun `updateRating does nothing when book is null`() = runTest {
        coEvery { repository.getBookById(testBookId) } returns null

        val viewModel = DetailViewModel(repository, testBookId)
        advanceUntilIdle()

        viewModel.updateRating(4.5f)
        advanceUntilIdle()

        assertNull(viewModel.uiState.value.book)
        coVerify(exactly = 0) { repository.updateBook(any()) }
    }

    // ===== Delete Book Tests =====

    @Test
    fun `deleteBook calls repository and invokes callback`() = runTest {
        coEvery { repository.getBookById(testBookId) } returns sampleBook
        coEvery { repository.deleteBookById(testBookId) } just Runs

        val viewModel = DetailViewModel(repository, testBookId)
        advanceUntilIdle()

        var callbackInvoked = false
        viewModel.deleteBook { callbackInvoked = true }
        advanceUntilIdle()

        assertTrue(callbackInvoked)
        coVerify(exactly = 1) { repository.deleteBookById(testBookId) }
    }

    @Test
    fun `deleteBook handles error gracefully`() = runTest {
        coEvery { repository.getBookById(testBookId) } returns sampleBook
        coEvery { repository.deleteBookById(testBookId) } throws RuntimeException("Delete failed")

        val viewModel = DetailViewModel(repository, testBookId)
        advanceUntilIdle()

        viewModel.deleteBook {}
        advanceUntilIdle()

        val state = viewModel.uiState.value
        assertTrue(state.error?.contains("删除失败") == true)
    }

    @Test
    fun `deleteBook does nothing when book is null`() = runTest {
        coEvery { repository.getBookById(testBookId) } returns null

        val viewModel = DetailViewModel(repository, testBookId)
        advanceUntilIdle()

        viewModel.deleteBook {}
        advanceUntilIdle()

        coVerify(exactly = 0) { repository.deleteBookById(any()) }
    }
}
