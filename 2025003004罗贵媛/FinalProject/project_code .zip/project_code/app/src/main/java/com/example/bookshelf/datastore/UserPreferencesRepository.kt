package com.example.bookshelf.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

// Extension property for DataStore
val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "user_preferences")

class UserPreferencesRepository(private val context: Context) {

    companion object {
        val THEME_MODE = stringPreferencesKey("theme_mode") // SYSTEM, LIGHT, DARK
        val DEFAULT_CATEGORY_ID = intPreferencesKey("default_category_id")
        val LAST_SEARCH_QUERY = stringPreferencesKey("last_search_query")
        val SORT_ORDER = stringPreferencesKey("sort_order") // date, title, rating
        val IS_FIRST_LAUNCH = booleanPreferencesKey("is_first_launch")
    }

    // Theme mode: SYSTEM, LIGHT, DARK
    val themeMode: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[THEME_MODE] ?: "SYSTEM"
    }

    suspend fun setThemeMode(mode: String) {
        context.dataStore.edit { preferences ->
            preferences[THEME_MODE] = mode
        }
    }

    // Default category
    val defaultCategoryId: Flow<Int> = context.dataStore.data.map { preferences ->
        preferences[DEFAULT_CATEGORY_ID] ?: 0
    }

    suspend fun setDefaultCategoryId(id: Int) {
        context.dataStore.edit { preferences ->
            preferences[DEFAULT_CATEGORY_ID] = id
        }
    }

    // Last search query
    val lastSearchQuery: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[LAST_SEARCH_QUERY] ?: ""
    }

    suspend fun setLastSearchQuery(query: String) {
        context.dataStore.edit { preferences ->
            preferences[LAST_SEARCH_QUERY] = query
        }
    }

    // Sort order
    val sortOrder: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[SORT_ORDER] ?: "date"
    }

    suspend fun setSortOrder(order: String) {
        context.dataStore.edit { preferences ->
            preferences[SORT_ORDER] = order
        }
    }

    // First launch
    val isFirstLaunch: Flow<Boolean> = context.dataStore.data.map { preferences ->
        preferences[IS_FIRST_LAUNCH] ?: true
    }

    suspend fun completeFirstLaunch() {
        context.dataStore.edit { preferences ->
            preferences[IS_FIRST_LAUNCH] = false
        }
    }
}
