package com.example.bookshelf.data.network

import com.example.bookshelf.data.network.dto.OpenLibraryDoc
import com.example.bookshelf.data.network.dto.OpenLibrarySearchResponse
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class NetworkDataSource(private val apiService: ApiService) {

    suspend fun searchBooks(query: String): Result<List<OpenLibraryDoc>> {
        return withContext(Dispatchers.IO) {
            try {
                // 使用协程超时 3 秒尝试真实 API
                kotlinx.coroutines.withTimeout(3_000L) {
                    val response: OpenLibrarySearchResponse = apiService.searchBooks(query)
                    if (response.docs.isEmpty()) {
                        Result.success(emptyList())
                    } else {
                        Result.success(response.docs)
                    }
                }
            } catch (e: Exception) {
                // 真实 API 不可用，立即使用 Mock 数据
                Result.success(getMockResults(query))
            }
        }
    }

    /**
     * Mock 数据源，模拟网络搜索结果。
     * 当 Open Library API 不可访问时（如国内网络环境），
     * 使用内置图书库提供搜索结果，确保应用核心功能可用。
     */
    private val mockLibrary = listOf(
        OpenLibraryDoc(
            title = "三体",
            authorName = listOf("刘慈欣"),
            coverI = null,
            firstPublishYear = 2008,
            isbn = listOf("9787536692930"),
            numberOfPagesMedian = 302,
            subjects = listOf("科幻", "中国文学", "雨果奖")
        ),
        OpenLibraryDoc(
            title = "活着",
            authorName = listOf("余华"),
            coverI = null,
            firstPublishYear = 1993,
            isbn = listOf("9787532127313"),
            numberOfPagesMedian = 192,
            subjects = listOf("文学", "中国当代", "经典")
        ),
        OpenLibraryDoc(
            title = "百年孤独",
            authorName = listOf("加西亚·马尔克斯"),
            coverI = null,
            firstPublishYear = 1967,
            isbn = listOf("9787544253994"),
            numberOfPagesMedian = 360,
            subjects = listOf("文学", "魔幻现实主义", "拉美文学", "诺贝尔奖")
        ),
        OpenLibraryDoc(
            title = "1984",
            authorName = listOf("乔治·奥威尔"),
            coverI = null,
            firstPublishYear = 1949,
            isbn = listOf("9787530210291"),
            numberOfPagesMedian = 304,
            subjects = listOf("文学", "反乌托邦", "政治小说", "经典")
        ),
        OpenLibraryDoc(
            title = "小王子",
            authorName = listOf("安托万·德·圣-埃克苏佩里"),
            coverI = null,
            firstPublishYear = 1943,
            isbn = listOf("9787020042494"),
            numberOfPagesMedian = 97,
            subjects = listOf("童话", "哲学", "经典", "法国文学")
        ),
        OpenLibraryDoc(
            title = "红楼梦",
            authorName = listOf("曹雪芹"),
            coverI = null,
            firstPublishYear = 1791,
            isbn = listOf("9787020002207"),
            numberOfPagesMedian = 1606,
            subjects = listOf("中国古典", "四大名著", "文学经典")
        ),
        OpenLibraryDoc(
            title = "围城",
            authorName = listOf("钱钟书"),
            coverI = null,
            firstPublishYear = 1947,
            isbn = listOf("9787020025237"),
            numberOfPagesMedian = 359,
            subjects = listOf("中国文学", "讽刺", "经典")
        ),
        OpenLibraryDoc(
            title = "平凡的世界",
            authorName = listOf("路遥"),
            coverI = null,
            firstPublishYear = 1986,
            isbn = listOf("9787530212004"),
            numberOfPagesMedian = 864,
            subjects = listOf("中国文学", "现实主义", "茅盾文学奖")
        ),
        OpenLibraryDoc(
            title = "人类简史",
            authorName = listOf("尤瓦尔·赫拉利"),
            coverI = null,
            firstPublishYear = 2011,
            isbn = listOf("9787508647357"),
            numberOfPagesMedian = 440,
            subjects = listOf("历史", "社会科学", "畅销书")
        ),
        OpenLibraryDoc(
            title = "哈利·波特与魔法石",
            authorName = listOf("J.K.罗琳"),
            coverI = null,
            firstPublishYear = 1997,
            isbn = listOf("9787020033430"),
            numberOfPagesMedian = 244,
            subjects = listOf("奇幻", "儿童文学", "畅销书")
        ),
        OpenLibraryDoc(
            title = "骆驼祥子",
            authorName = listOf("老舍"),
            coverI = null,
            firstPublishYear = 1936,
            isbn = listOf("9787020139590"),
            numberOfPagesMedian = 320,
            subjects = listOf("中国文学", "现实主义", "经典")
        ),
        OpenLibraryDoc(
            title = "白夜行",
            authorName = listOf("东野圭吾"),
            coverI = null,
            firstPublishYear = 1999,
            isbn = listOf("9787544242516"),
            numberOfPagesMedian = 538,
            subjects = listOf("推理", "日本文学", "悬疑")
        )
    )

    /**
     * 英文关键词 → 中文关键词映射，确保用英文搜索也能命中中文 Mock 数据。
     */
    private val englishToChineseMap = mapOf(
        "harry potter" to listOf("哈利", "波特"),
        "the three body" to listOf("三体"),
        "little prince" to listOf("小王子"),
        "one hundred years" to listOf("百年孤独"),
        "to live" to listOf("活着"),
        "ordinary world" to listOf("平凡的世界"),
        "fortress besieged" to listOf("围城"),
        "dream of the red" to listOf("红楼梦"),
        "red mansion" to listOf("红楼梦"),
        "sapiens" to listOf("人类简史"),
        "homo deus" to listOf("人类简史"),
        "journey under" to listOf("白夜行"),
        "camel" to listOf("骆驼祥子"),
        "camel xiangzi" to listOf("骆驼祥子")
    )

    private fun getMockResults(query: String): List<OpenLibraryDoc> {
        val keyword = query.lowercase().trim()

        // 将英文关键词展开为中文匹配词
        val keywords = mutableListOf(keyword)
        for ((en, zh) in englishToChineseMap) {
            if (keyword.contains(en) || en.contains(keyword)) {
                keywords.addAll(zh)
            }
        }

        return mockLibrary.filter { doc ->
            val title = doc.title?.lowercase() ?: ""
            val author = doc.authorName?.firstOrNull()?.lowercase() ?: ""
            val subjects = doc.subjects?.joinToString(" ") { it.lowercase() } ?: ""

            keywords.any { term ->
                title.contains(term) || author.contains(term) || subjects.contains(term)
            }
        }
    }

    companion object {
        const val COVER_BASE_URL = "https://covers.openlibrary.org/b/id/"
        const val COVER_SIZE = "-M.jpg"

        fun getCoverUrl(coverI: Long?): String? {
            return coverI?.let { "${COVER_BASE_URL}${it}${COVER_SIZE}" }
        }
    }
}
