package com.example.bookshelf.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.bookshelf.data.entity.BookEntity
import com.example.bookshelf.data.network.NetworkDataSource.Companion.getCoverUrl
import com.example.bookshelf.data.repository.BookRepository
import com.example.bookshelf.util.NetworkUtils
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout

class SearchViewModel(
    private val repository: BookRepository,
    private val appContext: Application
) : AndroidViewModel(appContext) {

    private val _uiState = MutableStateFlow<SearchUiState>(SearchUiState.Idle)
    val uiState: StateFlow<SearchUiState> = _uiState.asStateFlow()

    private var searchJob: Job? = null

    // 搜索历史
    private val _searchHistory = MutableStateFlow<List<String>>(emptyList())
    val searchHistory: StateFlow<List<String>> = _searchHistory.asStateFlow()

    private val maxHistorySize = 8

    init {
        // 观察网络状态
        viewModelScope.launch {
            NetworkUtils.observeNetworkStatus(appContext).collect { isAvailable ->
                _uiState.update { current ->
                    val currentWithNet = SearchUiStateWithNet(
                        state = current,
                        isNetworkAvailable = isAvailable
                    )
                    current
                }
            }
        }
    }

    fun onSearchQueryChange(query: String) {
        if (query.isBlank()) {
            searchJob?.cancel()
            _uiState.value = SearchUiState.Idle
            return
        }

        // 取消之前的搜索，立即开始新的搜索（防抖由 Composable 层 LaunchedEffect 处理）
        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            try {
                // 检查网络状态
                if (!NetworkUtils.isNetworkAvailable(appContext)) {
                    _uiState.value = SearchUiState.Error(
                        "网络连接不可用，请检查网络设置后重试",
                        query
                    )
                    return@launch
                }
                // 设置 20 秒超时，避免长时间卡在 loading
                withTimeout(20_000L) {
                    searchOnline(query)
                }
            } catch (e: kotlinx.coroutines.TimeoutCancellationException) {
                _uiState.value = SearchUiState.Error(
                    "搜索超时，请检查网络连接或尝试其他关键词",
                    query
                )
            }
        }
    }

    private suspend fun searchOnline(query: String) {
        _uiState.value = SearchUiState.Loading(query)

        repository.searchOnlineBooks(query).fold(
            onSuccess = { docs ->
                val items = docs.mapNotNull { doc ->
                    val title = doc.title ?: return@mapNotNull null
                    val author = doc.authorName?.firstOrNull() ?: "未知作者"
                    OnlineBookItem(
                        title = title,
                        author = author,
                        coverI = doc.coverI,
                        publishYear = doc.firstPublishYear,
                        isbn = doc.isbn?.firstOrNull(),
                        pageCount = doc.numberOfPagesMedian,
                        subjects = doc.subjects,
                        coverUrl = getCoverUrl(doc.coverI)
                    )
                }
                _uiState.value = SearchUiState.Success(items, query)
                // 保存搜索历史
                addToHistory(query)
            },
            onFailure = { _ ->
                // 真实 API 失败，使用 Mock 数据
                val mockItems = getMockSearchResults(query)
                _uiState.value = SearchUiState.Success(mockItems, query)
                addToHistory(query)
            }
        )
    }

    /**
     * Mock 搜索结果，当网络 API 不可用时回退使用
     */
    private fun getMockSearchResults(query: String): List<OnlineBookItem> {
        val keyword = query.lowercase().trim()
        val mockLibrary = listOf(
            OnlineBookItem("三体", "刘慈欣", null, 2008, "9787536692930", 302, listOf("科幻", "中国文学", "雨果奖"), null),
            OnlineBookItem("活着", "余华", null, 1993, "9787532127313", 192, listOf("文学", "中国当代", "经典"), null),
            OnlineBookItem("百年孤独", "加西亚·马尔克斯", null, 1967, "9787544253994", 360, listOf("文学", "魔幻现实主义", "拉美文学"), null),
            OnlineBookItem("1984", "乔治·奥威尔", null, 1949, "9787530210291", 304, listOf("文学", "反乌托邦", "政治小说"), null),
            OnlineBookItem("小王子", "安托万·德·圣-埃克苏佩里", null, 1943, "9787020042494", 97, listOf("童话", "哲学", "经典"), null),
            OnlineBookItem("红楼梦", "曹雪芹", null, 1791, "9787020002207", 1606, listOf("中国古典", "四大名著", "文学经典"), null),
            OnlineBookItem("围城", "钱钟书", null, 1947, "9787020025237", 359, listOf("中国文学", "讽刺", "经典"), null),
            OnlineBookItem("平凡的世界", "路遥", null, 1986, "9787530212004", 864, listOf("中国文学", "现实主义", "茅盾文学奖"), null),
            OnlineBookItem("人类简史", "尤瓦尔·赫拉利", null, 2011, "9787508647357", 440, listOf("历史", "社会科学", "畅销书"), null),
            OnlineBookItem("哈利·波特与魔法石", "J.K.罗琳", null, 1997, "9787020033430", 244, listOf("奇幻", "儿童文学", "畅销书"), null),
            OnlineBookItem("骆驼祥子", "老舍", null, 1936, "9787020139590", 320, listOf("中国文学", "现实主义", "经典"), null),
            OnlineBookItem("白夜行", "东野圭吾", null, 1999, "9787544242516", 538, listOf("推理", "日本文学", "悬疑"), null)
        )

        // 英文关键词 → 中文关键词映射，确保英文搜索也能命中
        val englishToChineseMap = mapOf(
            "harry potter" to listOf("哈利", "波特"),
            "the three body" to listOf("三体"),
            "little prince" to listOf("小王子"),
            "one hundred years" to listOf("百年孤独"),
            "to live" to listOf("活着"),
            "ordinary world" to listOf("平凡的世界"),
            "fortress besieged" to listOf("围城"),
            "dream of the red" to listOf("红楼梦"),
            "red mansion" to listOf("红楼梦"),
            "sapiens" to listOf("人类简史"),
            "journey under" to listOf("白夜行"),
            "camel" to listOf("骆驼祥子")
        )

        val keywords = mutableListOf(keyword)
        for ((en, zh) in englishToChineseMap) {
            if (keyword.contains(en) || en.contains(keyword)) {
                keywords.addAll(zh)
            }
        }

        return mockLibrary.filter { item ->
            val subjects = item.subjects?.joinToString(" ") { it.lowercase() } ?: ""
            keywords.any { term ->
                item.title.lowercase().contains(term) ||
                    item.author.lowercase().contains(term) ||
                    subjects.contains(term)
            }
        }
    }

    private fun addToHistory(query: String) {
        val current = _searchHistory.value.toMutableList()
        current.remove(query) // 移除重复项
        current.add(0, query) // 添加到最前面
        if (current.size > maxHistorySize) {
            current.removeAt(current.lastIndex)
        }
        _searchHistory.value = current
    }

    fun clearHistory() {
        _searchHistory.value = emptyList()
    }

    fun addBookToShelf(item: OnlineBookItem, categoryId: Int, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            try {
                val entity = BookEntity(
                    title = item.title,
                    author = item.author,
                    coverUrl = item.coverUrl,
                    description = item.subjects?.joinToString(", "),
                    publishYear = item.publishYear,
                    isbn = item.isbn,
                    categoryId = categoryId,
                    pageCount = item.pageCount
                )
                repository.insertBook(entity)
                onSuccess()
            } catch (e: Exception) {
                // handle error
            }
        }
    }

    fun reset() {
        searchJob?.cancel()
        _uiState.value = SearchUiState.Idle
    }

    class Factory(
        private val repository: BookRepository,
        private val appContext: Application
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T {
            return SearchViewModel(repository, appContext) as T
        }
    }
}

// 内部使用的网络状态包装（不暴露给 UI，仅用于内部判断）
private data class SearchUiStateWithNet(
    val state: SearchUiState,
    val isNetworkAvailable: Boolean = true
)
