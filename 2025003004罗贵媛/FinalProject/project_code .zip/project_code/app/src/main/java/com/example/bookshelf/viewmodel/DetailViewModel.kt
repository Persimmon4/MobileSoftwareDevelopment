package com.example.bookshelf.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.bookshelf.data.entity.BookEntity
import com.example.bookshelf.data.repository.BookRepository
import com.example.bookshelf.model.Book
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class DetailViewModel(
    private val repository: BookRepository,
    private val bookId: Int
) : ViewModel() {

    private val _uiState = MutableStateFlow(DetailUiState())
    val uiState: StateFlow<DetailUiState> = _uiState.asStateFlow()

    init {
        loadBook()
    }

    private fun loadBook() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            try {
                val book = repository.getBookById(bookId)
                if (book != null) {
                    _uiState.update { it.copy(book = book, isLoading = false) }
                } else {
                    _uiState.update { it.copy(error = "未找到该书籍", isLoading = false) }
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(error = "加载失败: ${e.message}", isLoading = false) }
            }
        }
    }

    fun updateReadingStatus(status: String) {
        viewModelScope.launch {
            val current = _uiState.value.book ?: return@launch
            val updated = BookEntity(
                id = current.id,
                title = current.title,
                author = current.author,
                coverUrl = current.coverUrl,
                description = current.description,
                publishYear = current.publishYear,
                isbn = current.isbn,
                categoryId = current.categoryId,
                readingStatus = status,
                rating = current.rating,
                notes = current.notes,
                pageCount = current.pageCount,
                createdAt = current.createdAt,
                updatedAt = System.currentTimeMillis()
            )
            repository.updateBook(updated)
            _uiState.update { it.copy(book = updated.toModel()) }
        }
    }

    fun updateRating(rating: Float) {
        viewModelScope.launch {
            val current = _uiState.value.book ?: return@launch
            val updated = BookEntity(
                id = current.id,
                title = current.title,
                author = current.author,
                coverUrl = current.coverUrl,
                description = current.description,
                publishYear = current.publishYear,
                isbn = current.isbn,
                categoryId = current.categoryId,
                readingStatus = current.readingStatus,
                rating = rating,
                notes = current.notes,
                pageCount = current.pageCount,
                createdAt = current.createdAt,
                updatedAt = System.currentTimeMillis()
            )
            repository.updateBook(updated)
            _uiState.update { it.copy(book = updated.toModel()) }
        }
    }

    fun deleteBook(onSuccess: () -> Unit) {
        viewModelScope.launch {
            try {
                val current = _uiState.value.book ?: return@launch
                repository.deleteBookById(current.id)
                onSuccess()
            } catch (e: Exception) {
                _uiState.update { it.copy(error = "删除失败: ${e.message}") }
            }
        }
    }

    private fun BookEntity.toModel() = Book(
        id = id, title = title, author = author, coverUrl = coverUrl,
        description = description, publishYear = publishYear, isbn = isbn,
        categoryId = categoryId, readingStatus = readingStatus, rating = rating,
        notes = notes, pageCount = pageCount, createdAt = createdAt, updatedAt = updatedAt
    )

    class Factory(
        private val repository: BookRepository,
        private val bookId: Int
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return DetailViewModel(repository, bookId) as T
        }
    }
}
