package com.example.bookshelf.data.network.dto

import com.google.gson.annotations.SerializedName

// Open Library Search API response
data class OpenLibrarySearchResponse(
    @SerializedName("numFound")
    val numFound: Int,
    @SerializedName("docs")
    val docs: List<OpenLibraryDoc>
)

data class OpenLibraryDoc(
    @SerializedName("title")
    val title: String?,
    @SerializedName("author_name")
    val authorName: List<String>?,
    @SerializedName("cover_i")
    val coverI: Long?,
    @SerializedName("first_publish_year")
    val firstPublishYear: Int?,
    @SerializedName("isbn")
    val isbn: List<String>?,
    @SerializedName("number_of_pages_median")
    val numberOfPagesMedian: Int?,
    @SerializedName("subject")
    val subjects: List<String>?
)
