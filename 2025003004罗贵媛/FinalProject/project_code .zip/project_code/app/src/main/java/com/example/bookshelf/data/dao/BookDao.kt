package com.example.bookshelf.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.bookshelf.data.entity.BookEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface BookDao {

    @Query("SELECT * FROM books ORDER BY updated_at DESC")
    fun getAllBooks(): Flow<List<BookEntity>>

    @Query("SELECT * FROM books WHERE id = :id")
    suspend fun getBookById(id: Int): BookEntity?

    @Query("SELECT * FROM books WHERE reading_status = :status ORDER BY updated_at DESC")
    fun getBooksByStatus(status: String): Flow<List<BookEntity>>

    @Query("SELECT * FROM books WHERE category_id = :categoryId ORDER BY updated_at DESC")
    fun getBooksByCategory(categoryId: Int): Flow<List<BookEntity>>

    @Query("""
        SELECT * FROM books 
        WHERE title LIKE '%' || :query || '%' 
        OR author LIKE '%' || :query || '%'
        ORDER BY updated_at DESC
    """)
    fun searchBooks(query: String): Flow<List<BookEntity>>

    @Query("""
        SELECT * FROM books 
        WHERE (:status IS NULL OR reading_status = :status) 
        AND (:categoryId IS NULL OR category_id = :categoryId)
        ORDER BY 
            CASE WHEN :sortBy = 'title' THEN title END ASC,
            CASE WHEN :sortBy = 'rating' THEN rating END DESC,
            CASE WHEN :sortBy = 'date' THEN updated_at END DESC
    """)
    fun filterAndSortBooks(
        status: String? = null,
        categoryId: Int? = null,
        sortBy: String = "date"
    ): Flow<List<BookEntity>>

    @Query("SELECT COUNT(*) FROM books WHERE reading_status = :status")
    suspend fun getBookCountByStatus(status: String): Int

    @Query("SELECT DISTINCT reading_status FROM books")
    suspend fun getAllStatuses(): List<String>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBook(book: BookEntity): Long

    @Update
    suspend fun updateBook(book: BookEntity)

    @Delete
    suspend fun deleteBook(book: BookEntity)

    @Query("DELETE FROM books WHERE id = :id")
    suspend fun deleteBookById(id: Int)

    @Query("SELECT COUNT(*) FROM books")
    suspend fun getBookCount(): Int

    @Query("SELECT * FROM books WHERE title = :title ORDER BY updated_at DESC LIMIT 1")
    suspend fun getBookByTitle(title: String): BookEntity?
}
