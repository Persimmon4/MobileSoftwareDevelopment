package com.example.bookshelf.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.bookshelf.data.entity.BookEntity
import com.example.bookshelf.data.repository.BookRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class EditViewModel(
    private val repository: BookRepository,
    private val bookId: Int? = null // null = add mode, non-null = edit mode
) : ViewModel() {

    private val _uiState = MutableStateFlow(EditUiState())
    val uiState: StateFlow<EditUiState> = _uiState.asStateFlow()

    init {
        loadCategories()
        if (bookId != null) {
            loadBook(bookId)
        }
    }

    private fun loadCategories() {
        viewModelScope.launch {
            repository.getAllCategories().collect { categories ->
                val items = categories.map { CategoryItem(it.id, it.name) }
                _uiState.update { it.copy(categories = items) }
            }
        }
    }

    private fun loadBook(id: Int) {
        viewModelScope.launch {
            val book = repository.getBookById(id)
            if (book != null) {
                _uiState.update {
                    it.copy(
                        isEditMode = true,
                        title = book.title,
                        author = book.author,
                        coverUrl = book.coverUrl ?: "",
                        description = book.description ?: "",
                        publishYear = book.publishYear?.toString() ?: "",
                        isbn = book.isbn ?: "",
                        categoryId = book.categoryId,
                        readingStatus = book.readingStatus,
                        rating = book.rating ?: 0f,
                        notes = book.notes ?: "",
                        pageCount = book.pageCount?.toString() ?: "",
                        createdAt = book.createdAt
                    )
                }
            }
        }
    }

    fun onTitleChange(title: String) {
        _uiState.update { it.copy(title = title, titleError = null) }
    }

    fun onAuthorChange(author: String) {
        _uiState.update { it.copy(author = author, authorError = null) }
    }

    fun onDescriptionChange(desc: String) {
        _uiState.update { it.copy(description = desc) }
    }

    fun onPublishYearChange(year: String) {
        _uiState.update { it.copy(publishYear = year) }
    }

    fun onIsbnChange(isbn: String) {
        _uiState.update { it.copy(isbn = isbn) }
    }

    fun onCategoryChange(categoryId: Int) {
        _uiState.update { it.copy(categoryId = categoryId) }
    }

    fun onReadingStatusChange(status: String) {
        _uiState.update { it.copy(readingStatus = status) }
    }

    fun onRatingChange(rating: Float) {
        _uiState.update { it.copy(rating = rating) }
    }

    fun onNotesChange(notes: String) {
        _uiState.update { it.copy(notes = notes) }
    }

    fun onPageCountChange(count: String) {
        _uiState.update { it.copy(pageCount = count) }
    }

    fun onCoverUrlChange(url: String) {
        _uiState.update { it.copy(coverUrl = url) }
    }

    fun save(onSuccess: () -> Unit) {
        // Validate
        var hasError = false
        val state = _uiState.value

        if (state.title.isBlank()) {
            _uiState.update { it.copy(titleError = "书名不能为空") }
            hasError = true
        }
        if (state.author.isBlank()) {
            _uiState.update { it.copy(authorError = "作者不能为空") }
            hasError = true
        }
        // Validate publishYear
        val yearInt = state.publishYear.toIntOrNull()
        if (state.publishYear.isNotBlank() && (yearInt == null || yearInt < 0 || yearInt > 2100)) {
            _uiState.update { it.copy(error = "出版年份格式不正确") }
            hasError = true
        }
        // Validate pageCount
        val pageCountInt = state.pageCount.toIntOrNull()
        if (state.pageCount.isNotBlank() && (pageCountInt == null || pageCountInt <= 0)) {
            _uiState.update { it.copy(error = "页数格式不正确") }
            hasError = true
        }

        if (hasError) return

        _uiState.update { it.copy(isSaving = true, error = null) }

        viewModelScope.launch {
            try {
                val entity = if (state.isEditMode && bookId != null) {
                    BookEntity(
                        id = bookId,
                        title = state.title.trim(),
                        author = state.author.trim(),
                        coverUrl = state.coverUrl.ifBlank { null },
                        description = state.description.ifBlank { null },
                        publishYear = state.publishYear.toIntOrNull(),
                        isbn = state.isbn.ifBlank { null },
                        categoryId = state.categoryId,
                        readingStatus = state.readingStatus,
                        rating = if (state.rating > 0) state.rating else null,
                        notes = state.notes.ifBlank { null },
                        pageCount = state.pageCount.toIntOrNull(),
                        createdAt = state.createdAt,
                        updatedAt = System.currentTimeMillis()
                    )
                } else {
                    BookEntity(
                        title = state.title.trim(),
                        author = state.author.trim(),
                        coverUrl = state.coverUrl.ifBlank { null },
                        description = state.description.ifBlank { null },
                        publishYear = state.publishYear.toIntOrNull(),
                        isbn = state.isbn.ifBlank { null },
                        categoryId = state.categoryId,
                        readingStatus = state.readingStatus,
                        rating = if (state.rating > 0) state.rating else null,
                        notes = state.notes.ifBlank { null },
                        pageCount = state.pageCount.toIntOrNull()
                    )
                }

                if (state.isEditMode) {
                    repository.updateBook(entity)
                } else {
                    repository.insertBook(entity)
                }

                _uiState.update { it.copy(isSaving = false, saveSuccess = true) }
                onSuccess()
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(isSaving = false, error = "保存失败: ${e.message}")
                }
            }
        }
    }

    fun clearError() {
        _uiState.update { it.copy(error = null) }
    }

    class Factory(
        private val repository: BookRepository,
        private val bookId: Int? = null
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return EditViewModel(repository, bookId) as T
        }
    }
}
