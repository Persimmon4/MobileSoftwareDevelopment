package com.example.bookshelf.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.bookshelf.data.repository.BookRepository
import com.example.bookshelf.datastore.UserPreferencesRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class SettingsViewModel(
    private val repository: BookRepository,
    private val userPreferences: UserPreferencesRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(SettingsUiState())
    val uiState: StateFlow<SettingsUiState> = _uiState.asStateFlow()

    init {
        loadPreferences()
        loadStats()
    }

    private fun loadPreferences() {
        viewModelScope.launch {
            userPreferences.themeMode.collect { mode ->
                _uiState.update { it.copy(themeMode = mode) }
            }
        }
        viewModelScope.launch {
            userPreferences.sortOrder.collect { order ->
                _uiState.update { it.copy(sortOrder = order) }
            }
        }
    }

    private fun loadStats() {
        viewModelScope.launch {
            val reading = repository.getBookCountByStatus("READING")
            val finished = repository.getBookCountByStatus("FINISHED")
            val wantToRead = repository.getBookCountByStatus("WANT_TO_READ")
            _uiState.update {
                it.copy(
                    readingCount = reading,
                    finishedCount = finished,
                    wantToReadCount = wantToRead,
                    totalBooks = reading + finished + wantToRead
                )
            }
        }
    }

    fun setThemeMode(mode: String) {
        viewModelScope.launch {
            userPreferences.setThemeMode(mode)
            _uiState.update { it.copy(themeMode = mode) }
        }
    }

    fun setSortOrder(order: String) {
        viewModelScope.launch {
            userPreferences.setSortOrder(order)
            _uiState.update { it.copy(sortOrder = order) }
        }
    }

    class Factory(
        private val repository: BookRepository,
        private val userPreferences: UserPreferencesRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return SettingsViewModel(repository, userPreferences) as T
        }
    }
}
