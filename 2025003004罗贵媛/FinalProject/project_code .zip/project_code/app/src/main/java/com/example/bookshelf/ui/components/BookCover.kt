package com.example.bookshelf.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest

data class CoverColors(
    val top: Color,
    val bottom: Color,
    val accent: Color
)

private val coverColorMap = mapOf(
    "hongloumeng" to CoverColors(
        top = Color(0xFFB22222),
        bottom = Color(0xFF4A0000),
        accent = Color(0xFFFFD700)
    ),
    "sanguoyanyi" to CoverColors(
        top = Color(0xFF2C5F7C),
        bottom = Color(0xFF0D1B2A),
        accent = Color(0xFFD4AF37)
    ),
    "xiyouji" to CoverColors(
        top = Color(0xFFE8A317),
        bottom = Color(0xFF7B3F00),
        accent = Color(0xFFFFE4B5)
    ),
    "shuihuzhuan" to CoverColors(
        top = Color(0xFF2E7D32),
        bottom = Color(0xFF0A2808),
        accent = Color(0xFFBDBDBD)
    ),
    "nahan" to CoverColors(
        top = Color(0xFF5D5D5D),
        bottom = Color(0xFF121212),
        accent = Color(0xFFE53935)
    ),
    "weicheng" to CoverColors(
        top = Color(0xFF8B6914),
        bottom = Color(0xFF3E2723),
        accent = Color(0xFFFFD54F)
    ),
    "luotuoxiangzi" to CoverColors(
        top = Color(0xFFC49A6C),
        bottom = Color(0xFF4E342E),
        accent = Color(0xFFFFCC80)
    ),
    "huozhe" to CoverColors(
        top = Color(0xFF00695C),
        bottom = Color(0xFF0A1F1A),
        accent = Color(0xFFB2DFDB)
    ),
    "santi" to CoverColors(
        top = Color(0xFF311B92),
        bottom = Color(0xFF050014),
        accent = Color(0xFF7C4DFF)
    ),
    "pingfandeshijie" to CoverColors(
        top = Color(0xFF546E7A),
        bottom = Color(0xFF102027),
        accent = Color(0xFFFFAB40)
    )
)

@Composable
fun BookCoverImage(
    coverKey: String?,
    title: String,
    author: String = "",
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 8.dp,
    titleSize: Int = 14,
    showAuthor: Boolean = false
) {
    val context = LocalContext.current
    val drawableId = if (coverKey != null) {
        context.resources.getIdentifier(coverKey, "drawable", context.packageName)
    } else 0

    // 本地图片颜色（用于书脊等场景）
    val colors = if (coverKey != null) {
        coverColorMap[coverKey] ?: coverColorMap.values.first()
    } else {
        val idx = kotlin.math.abs(title.hashCode()) % coverColorMap.size
        coverColorMap.values.elementAt(idx)
    }

    Box(
        modifier = modifier.clip(RoundedCornerShape(cornerRadius)),
        contentAlignment = Alignment.Center
    ) {
        // 如果有本地图片资源，优先使用真实封面图片
        if (drawableId != 0) {
            AsyncImage(
                model = ImageRequest.Builder(context)
                    .data(drawableId)
                    .build(),
                contentDescription = "$title 封面",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else {
            // 没有本地图片时，使用渐变色渲染
            GradientCover(
                colors = colors,
                title = title,
                author = author,
                titleSize = titleSize,
                showAuthor = showAuthor
            )
        }
    }
}

@Composable
private fun GradientCover(
    colors: CoverColors,
    title: String,
    author: String,
    titleSize: Int,
    showAuthor: Boolean
) {
    // 主渐变背景
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.linearGradient(
                    colors = listOf(colors.top, colors.bottom),
                    start = androidx.compose.ui.geometry.Offset(0f, 0f),
                    end = androidx.compose.ui.geometry.Offset(0f, Float.POSITIVE_INFINITY)
                )
            )
    )

    // 装饰性竖线
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 8.dp)
            .background(
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        colors.accent.copy(alpha = 0.08f),
                        Color.Transparent,
                        colors.accent.copy(alpha = 0.05f)
                    )
                )
            )
    )

    // 文字内容
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = title,
            color = Color.White.copy(alpha = 0.95f),
            fontSize = titleSize.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            lineHeight = (titleSize + 2).sp
        )

        if (showAuthor && author.isNotEmpty()) {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = author,
                color = colors.accent.copy(alpha = 0.85f),
                fontSize = (titleSize - 4).sp,
                fontWeight = FontWeight.Light,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
