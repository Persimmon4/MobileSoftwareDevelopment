package com.example.bookshelf

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache
import com.example.bookshelf.data.database.AppDatabase
import com.example.bookshelf.data.entity.BookEntity
import com.example.bookshelf.data.entity.CategoryEntity
import com.example.bookshelf.data.network.NetworkDataSource
import com.example.bookshelf.data.network.RetrofitClient
import com.example.bookshelf.data.repository.BookRepository
import com.example.bookshelf.datastore.UserPreferencesRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

class BookshelfApp : Application(), ImageLoaderFactory {

    lateinit var repository: BookRepository
        private set

    lateinit var userPreferences: UserPreferencesRepository
        private set

    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // 自定义 OkHttp 客户端，添加 User-Agent 和 Referer 用于加载豆瓣封面
    private val imageOkHttpClient = OkHttpClient.Builder()
        .addInterceptor { chain ->
            val request = chain.request().newBuilder()
                .addHeader(
                    "User-Agent",
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
                )
                .addHeader("Referer", "https://book.douban.com/")
                .build()
            chain.proceed(request)
        }
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    // 实现 ImageLoaderFactory，使 Coil 全局使用自定义 OkHttp 客户端
    override fun newImageLoader(): ImageLoader {
        return ImageLoader.Builder(this)
            .okHttpClient { imageOkHttpClient }
            .memoryCache { MemoryCache.Builder(this).maxSizePercent(0.25).build() }
            .diskCache { DiskCache.Builder().directory(cacheDir.resolve("coil_cache")).maxSizePercent(0.05).build() }
            .crossfade(true)
            .build()
    }

    override fun onCreate() {
        super.onCreate()

        // Initialize Database
        val database = AppDatabase.getDatabase(this)

        // Seed default categories
        seedCategories(database)

        // Seed default books (同步执行，确保封面数据在UI渲染前就位)
        seedBooks(database)

        // Initialize Network
        val networkDataSource = NetworkDataSource(RetrofitClient.apiService)

        // Initialize Repository
        repository = BookRepository(
            bookDao = database.bookDao(),
            categoryDao = database.categoryDao(),
            networkDataSource = networkDataSource
        )

        // Initialize DataStore
        userPreferences = UserPreferencesRepository(this)
    }

    private fun seedCategories(database: AppDatabase) {
        applicationScope.launch {
            val dao = database.categoryDao()
            if (dao.getCategoryCount() == 0) {
                val defaultCategories = listOf(
                    CategoryEntity(name = "未分类", description = "默认分类", sortOrder = 0),
                    CategoryEntity(name = "文学小说", sortOrder = 1),
                    CategoryEntity(name = "科学技术", sortOrder = 2),
                    CategoryEntity(name = "历史哲学", sortOrder = 3),
                    CategoryEntity(name = "经济管理", sortOrder = 4),
                    CategoryEntity(name = "生活百科", sortOrder = 5)
                )
                defaultCategories.forEach { dao.insertCategory(it) }
            }
        }
    }

    private fun seedBooks(database: AppDatabase) {
        applicationScope.launch {
            val bookDao = database.bookDao()
            val categoryCount = database.categoryDao().getCategoryCount()
            if (categoryCount > 0 && bookDao.getBookCount() == 0) {
                // 确保分类先播种完成
                kotlinx.coroutines.delay(300)

                val defaultBooks = listOf(
                    BookEntity(
                        title = "红楼梦",
                        author = "曹雪芹",
                        coverUrl = "cover_hongloumeng",
                        description = "中国古代四大名著之首，以贾宝玉和林黛玉的爱情悲剧为主线，描写了贾、王、史、薛四大家族的兴衰史。全书人物众多、结构宏大，深刻反映了封建社会的种种矛盾与人性的复杂，被誉为中国古典小说的巅峰之作。",
                        publishYear = 1791,
                        isbn = "978-7-02-000220-7",
                        categoryId = 2,
                        readingStatus = "FINISHED",
                        rating = 5.0f,
                        pageCount = 1606,
                        notes = "满纸荒唐言，一把辛酸泪"
                    ),
                    BookEntity(
                        title = "三国演义",
                        author = "罗贯中",
                        coverUrl = "cover_sanguoyanyi",
                        description = "中国古典四大名著之一，描写了东汉末年到西晋初年之间近百年的历史风云，以魏、蜀、吴三国的兴亡为线索，塑造了诸葛亮、曹操、关羽、刘备等众多栩栩如生的人物形象，展现了群雄逐鹿、斗智斗勇的宏大历史画卷。",
                        publishYear = 1522,
                        isbn = "978-7-02-000217-7",
                        categoryId = 4,
                        readingStatus = "FINISHED",
                        rating = 5.0f,
                        pageCount = 1280,
                        notes = "滚滚长江东逝水，浪花淘尽英雄"
                    ),
                    BookEntity(
                        title = "西游记",
                        author = "吴承恩",
                        coverUrl = "cover_xiyouji",
                        description = "中国古典四大名著之一，讲述唐僧师徒四人——孙悟空、猪八戒、沙僧和白龙马，历经九九八十一难前往西天取经的故事。全书充满奇幻色彩，将神魔世界与现实社会巧妙结合，是一部伟大的浪漫主义神魔小说。",
                        publishYear = 1592,
                        isbn = "978-7-02-000218-4",
                        categoryId = 2,
                        readingStatus = "WANT_TO_READ",
                        rating = 0f,
                        pageCount = 1182,
                        notes = ""
                    ),
                    BookEntity(
                        title = "水浒传",
                        author = "施耐庵",
                        coverUrl = "cover_shuihuzhuan",
                        description = "中国古典四大名著之一，描写了北宋末年以宋江为首的一百零八位好汉在梁山泊聚义，替天行道、反抗压迫的壮阔故事。小说刻画了林冲、武松、鲁智深等深入人心的英雄形象，是中国侠义文学的经典代表。",
                        publishYear = 1589,
                        isbn = "978-7-02-000219-1",
                        categoryId = 2,
                        readingStatus = "WANT_TO_READ",
                        rating = 0f,
                        pageCount = 1314,
                        notes = ""
                    ),
                    BookEntity(
                        title = "呐喊",
                        author = "鲁迅",
                        coverUrl = "cover_nahan",
                        description = "鲁迅的第一部短篇小说集，收录了《狂人日记》《孔乙己》《药》《阿Q正传》等十四篇不朽名作。以犀利的笔锋揭示了旧中国社会的黑暗与国民性的弱点，喊出了新文化运动中最响亮的启蒙之声，是中国现代文学的奠基之作。",
                        publishYear = 1923,
                        isbn = "978-7-02-008450-8",
                        categoryId = 2,
                        readingStatus = "READING",
                        rating = 5.0f,
                        pageCount = 185,
                        notes = "横眉冷对千夫指，俯首甘为孺子牛"
                    ),
                    BookEntity(
                        title = "围城",
                        author = "钱钟书",
                        coverUrl = "cover_weicheng",
                        description = "钱钟书唯一的长篇小说，以留学生方鸿渐回国后的经历为主线，用幽默犀利的笔调描绘了抗战初期知识分子的群像。书名寓意婚姻如围城——城外的人想冲进去，城里的人想逃出来，被誉为新儒林外史。",
                        publishYear = 1947,
                        isbn = "978-7-02-010146-7",
                        categoryId = 2,
                        readingStatus = "FINISHED",
                        rating = 4.0f,
                        pageCount = 359,
                        notes = "城外的人想冲进去，城里的人想逃出来"
                    ),
                    BookEntity(
                        title = "骆驼祥子",
                        author = "老舍",
                        coverUrl = "cover_luotuoxiangzi",
                        description = "以北平一个人力车夫祥子的行踪为线索，讲述了他三起三落的人生遭遇。祥子勤劳朴实，最大的愿望就是拥有一辆自己的洋车，但在旧社会的残酷压迫下一次次被击垮，最终走向毁灭。作品深刻揭示了旧社会的黑暗和底层人民的悲惨命运。",
                        publishYear = 1936,
                        isbn = "978-7-02-009211-6",
                        categoryId = 2,
                        readingStatus = "READING",
                        rating = 4.0f,
                        pageCount = 248,
                        notes = "个人奋斗在旧社会注定是悲剧"
                    ),
                    BookEntity(
                        title = "活着",
                        author = "余华",
                        coverUrl = "cover_huozhe",
                        description = "讲述了一个人历经世间沧桑和磨难的一生。地主少爷福贵嗜赌成性，败光家产后历经内战、土改、大跃进、文革等社会变革，亲人相继离世，最后只剩一头老牛相伴。小说以平淡的笔触写出了生命的坚韧与活着的意义。",
                        publishYear = 1993,
                        isbn = "978-7-5302-0963-0",
                        categoryId = 2,
                        readingStatus = "FINISHED",
                        rating = 5.0f,
                        pageCount = 191,
                        notes = "人是为活着本身而活着的"
                    ),
                    BookEntity(
                        title = "三体",
                        author = "刘慈欣",
                        coverUrl = "cover_santi",
                        description = "中国科幻文学的里程碑之作，讲述了地球人类文明和三体文明的信息交流、生死搏杀及两个文明在宇宙中的兴衰历程。从文革时期的秘密基地到四光年外的三体世界，刘慈欣以宏大的想象力和严谨的科学推演构建了一个震撼的宇宙图景。",
                        publishYear = 2008,
                        isbn = "978-7-5366-9293-0",
                        categoryId = 3,
                        readingStatus = "FINISHED",
                        rating = 5.0f,
                        pageCount = 302,
                        notes = "给岁月以文明，而不是给文明以岁月"
                    ),
                    BookEntity(
                        title = "平凡的世界",
                        author = "路遥",
                        coverUrl = "cover_pingfandeshijie",
                        description = "以中国70年代中期到80年代中期十年间为背景，以孙少安和孙少平两兄弟为中心，刻画了当时社会各阶层众多普通人的形象。劳动与爱情、挫折与追求、痛苦与欢乐交织在一起，展现了普通人在大时代历史进程中所走过的艰难曲折的道路。",
                        publishYear = 1986,
                        isbn = "978-7-5302-0955-5",
                        categoryId = 2,
                        readingStatus = "READING",
                        rating = 5.0f,
                        pageCount = 1256,
                        notes = "生活不能等待别人来安排，要自己去争取"
                    )
                )

                defaultBooks.forEach { bookDao.insertBook(it) }
            } else if (bookDao.getBookCount() > 0) {
                // 已有数据：自动补全缺失的封面
                updateMissingCovers(bookDao)
            }
        }
    }

    private suspend fun updateMissingCovers(bookDao: com.example.bookshelf.data.dao.BookDao) {
        val coverMap = mapOf(
            "红楼梦" to "cover_hongloumeng",
            "三国演义" to "cover_sanguoyanyi",
            "西游记" to "cover_xiyouji",
            "水浒传" to "cover_shuihuzhuan",
            "呐喊" to "cover_nahan",
            "围城" to "cover_weicheng",
            "骆驼祥子" to "cover_luotuoxiangzi",
            "活着" to "cover_huozhe",
            "三体" to "cover_santi",
            "平凡的世界" to "cover_pingfandeshijie"
        )

        coverMap.forEach { (title, coverUrl) ->
            val existing = bookDao.getBookByTitle(title)
            // 只要不是以 "cover_" 开头的本地资源名，就更新为新资源名
            if (existing != null && existing.coverUrl?.startsWith("cover_") != true) {
                bookDao.updateBook(existing.copy(coverUrl = coverUrl))
            }
        }
    }

    override fun onTerminate() {
        super.onTerminate()
        applicationScope.cancel()
    }
}
