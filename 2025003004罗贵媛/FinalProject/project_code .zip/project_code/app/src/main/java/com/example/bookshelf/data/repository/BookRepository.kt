package com.example.bookshelf.data.repository

import com.example.bookshelf.data.dao.BookDao
import com.example.bookshelf.data.dao.CategoryDao
import com.example.bookshelf.data.entity.BookEntity
import com.example.bookshelf.data.entity.CategoryEntity
import com.example.bookshelf.data.network.NetworkDataSource
import com.example.bookshelf.data.network.dto.OpenLibraryDoc
import com.example.bookshelf.model.Book
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

class BookRepository(
    private val bookDao: BookDao,
    private val categoryDao: CategoryDao,
    private val networkDataSource: NetworkDataSource
) {

    // ===== Local Data =====

    fun getAllBooks(): Flow<List<Book>> {
        return bookDao.getAllBooks().map { entities ->
            entities.map { it.toBook() }
        }
    }

    fun getBooksByStatus(status: String): Flow<List<Book>> {
        return bookDao.getBooksByStatus(status).map { entities ->
            entities.map { it.toBook() }
        }
    }

    fun getBooksByCategory(categoryId: Int): Flow<List<Book>> {
        return bookDao.getBooksByCategory(categoryId).map { entities ->
            entities.map { it.toBook() }
        }
    }

    fun searchLocalBooks(query: String): Flow<List<Book>> {
        return bookDao.searchBooks(query).map { entities ->
            entities.map { it.toBook() }
        }
    }

    fun filterAndSortBooks(
        status: String? = null,
        categoryId: Int? = null,
        sortBy: String = "date"
    ): Flow<List<Book>> {
        return bookDao.filterAndSortBooks(status, categoryId, sortBy).map { entities ->
            entities.map { it.toBook() }
        }
    }

    suspend fun getBookById(id: Int): Book? {
        return bookDao.getBookById(id)?.toBook()
    }

    suspend fun insertBook(book: BookEntity): Long {
        return bookDao.insertBook(book)
    }

    suspend fun updateBook(book: BookEntity) {
        bookDao.updateBook(book)
    }

    suspend fun deleteBook(book: BookEntity) {
        bookDao.deleteBook(book)
    }

    suspend fun deleteBookById(id: Int) {
        bookDao.deleteBookById(id)
    }

    suspend fun getBookCountByStatus(status: String): Int {
        return bookDao.getBookCountByStatus(status)
    }

    // ===== Categories =====

    fun getAllCategories(): Flow<List<CategoryEntity>> {
        return categoryDao.getAllCategories()
    }

    suspend fun getCategoryById(id: Int): CategoryEntity? {
        return categoryDao.getCategoryById(id)
    }

    suspend fun getCategoryByName(name: String): CategoryEntity? {
        return categoryDao.getCategoryByName(name)
    }

    suspend fun insertCategory(category: CategoryEntity): Long {
        return categoryDao.insertCategory(category)
    }

    suspend fun getBookCountInCategory(categoryId: Int): Int {
        return categoryDao.getBookCountInCategory(categoryId)
    }

    suspend fun deleteCategory(category: CategoryEntity) {
        categoryDao.deleteCategory(category)
    }

    // ===== Network Data =====

    suspend fun searchOnlineBooks(query: String): Result<List<OpenLibraryDoc>> {
        return networkDataSource.searchBooks(query)
    }

    // ===== Data Export =====

    suspend fun exportBooksToJson(): String {
        val books = getAllBooks().first()
        val jsonArray = JSONArray()
        books.forEach { book ->
            val jsonObj = JSONObject().apply {
                put("id", book.id)
                put("title", book.title)
                put("author", book.author)
                put("coverUrl", book.coverUrl ?: JSONObject.NULL)
                put("description", book.description ?: JSONObject.NULL)
                put("publishYear", book.publishYear ?: JSONObject.NULL)
                put("isbn", book.isbn ?: JSONObject.NULL)
                put("categoryId", book.categoryId)
                put("readingStatus", book.readingStatus)
                put("rating", book.rating ?: JSONObject.NULL)
                put("notes", book.notes ?: JSONObject.NULL)
                put("pageCount", book.pageCount ?: JSONObject.NULL)
                put("createdAt", book.createdAt)
                put("updatedAt", book.updatedAt)
            }
            jsonArray.put(jsonObj)
        }
        return jsonArray.toString(2)
    }

    suspend fun importBooksFromJson(jsonString: String): Int {
        val jsonArray = JSONArray(jsonString)
        var count = 0
        for (i in 0 until jsonArray.length()) {
            val obj = jsonArray.getJSONObject(i)
            val entity = BookEntity(
                title = obj.getString("title"),
                author = obj.getString("author"),
                coverUrl = obj.optString("coverUrl", null),
                description = obj.optString("description", null),
                publishYear = if (obj.isNull("publishYear")) null else obj.getInt("publishYear"),
                isbn = obj.optString("isbn", null),
                categoryId = obj.optInt("categoryId", 1),
                readingStatus = obj.optString("readingStatus", "WANT_TO_READ"),
                rating = if (obj.isNull("rating")) null else obj.getDouble("rating").toFloat(),
                notes = obj.optString("notes", null),
                pageCount = if (obj.isNull("pageCount")) null else obj.getInt("pageCount")
            )
            bookDao.insertBook(entity)
            count++
        }
        return count
    }

    // ===== Conversion =====

    private fun BookEntity.toBook(): Book {
        return Book(
            id = id,
            title = title,
            author = author,
            coverUrl = coverUrl,
            description = description,
            publishYear = publishYear,
            isbn = isbn,
            categoryId = categoryId,
            readingStatus = readingStatus,
            rating = rating,
            notes = notes,
            pageCount = pageCount,
            createdAt = createdAt,
            updatedAt = updatedAt
        )
    }
}
