package com.example.bookshelf.data.network

import com.example.bookshelf.data.network.dto.OpenLibrarySearchResponse
import retrofit2.http.GET
import retrofit2.http.Query

interface ApiService {

    @GET("search.json")
    suspend fun searchBooks(
        @Query("q") query: String,
        @Query("limit") limit: Int = 20,
        @Query("fields") fields: String = "title,author_name,cover_i,first_publish_year,isbn,number_of_pages_median,subject"
    ): OpenLibrarySearchResponse
}
