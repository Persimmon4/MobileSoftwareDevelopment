package com.example.bookshelf.model

data class Book(
    val id: Int = 0,
    val title: String,
    val author: String,
    val coverUrl: String? = null,
    val description: String? = null,
    val publishYear: Int? = null,
    val isbn: String? = null,
    val categoryId: Int,
    val readingStatus: String = "WANT_TO_READ",
    val rating: Float? = null,
    val notes: String? = null,
    val pageCount: Int? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
