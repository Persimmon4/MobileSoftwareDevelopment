package com.example.bookshelf.data.network

import okhttp3.Dns
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.net.Inet4Address
import java.net.InetAddress
import java.net.ProxySelector
import java.util.concurrent.TimeUnit

object RetrofitClient {

    private const val BASE_URL = "https://openlibrary.org/"

    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.HEADERS
    }

    // 调用自定义DNS解析器，优先返回IPv4地址
    private val ipv4FirstDns = object : Dns {
        override fun lookup(hostname: String): List<java.net.InetAddress> {
            val addresses = try {
                InetAddress.getAllByName(hostname).toList()
            } catch (e: Exception) {
                Dns.SYSTEM.lookup(hostname)
            }
            return addresses.sortedBy { if (it is Inet4Address) 0 else 1 }
        }
    }

    private val okHttpClient = OkHttpClient.Builder()
        .dns(ipv4FirstDns)
        .proxySelector(ProxySelector.getDefault())
        .addInterceptor(loggingInterceptor)
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    val apiService: ApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService::class.java)
    }
}
