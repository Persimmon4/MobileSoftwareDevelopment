package com.example.bookshelf.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.bookshelf.data.repository.BookRepository
import com.example.bookshelf.datastore.UserPreferencesRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class HomeViewModel(
    private val repository: BookRepository,
    private val userPreferences: UserPreferencesRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    private val _selectedStatus = MutableStateFlow<String?>(null)
    private val _selectedCategoryId = MutableStateFlow<Int?>(null)
    private val _sortBy = MutableStateFlow("date")
    private val _refreshTrigger = MutableStateFlow(0L)

    init {
        loadCategories()
        loadBooks()
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    private fun loadBooks() {
        viewModelScope.launch {
            combine(
                _searchQuery, _selectedStatus, _selectedCategoryId, _sortBy, _refreshTrigger
            ) { query, status, categoryId, sortBy, _ ->
                QuadParams(query, status, categoryId, sortBy)
            }.flatMapLatest { params ->
                if (params.query.isNotEmpty()) {
                    repository.searchLocalBooks(params.query)
                } else {
                    repository.filterAndSortBooks(params.status, params.categoryId, params.sortBy)
                }
            }.combine(userPreferences.sortOrder) { books, sortOrder ->
                _sortBy.value = sortOrder
                books
            }.collect { books ->
                _uiState.update {
                    it.copy(
                        books = books,
                        isLoading = false,
                        error = null
                    )
                }
            }
        }
    }

    fun refresh() {
        _refreshTrigger.value = System.currentTimeMillis()
    }

    private data class QuadParams(
        val query: String,
        val status: String?,
        val categoryId: Int?,
        val sortBy: String
    )

    private fun loadCategories() {
        viewModelScope.launch {
            repository.getAllCategories().collect { categories ->
                val categoryItems = categories.map { cat ->
                    val count = repository.getBookCountInCategory(cat.id)
                    CategoryItem(id = cat.id, name = cat.name, bookCount = count)
                }
                _uiState.update {
                    it.copy(categories = listOf(CategoryItem(0, "全部", 0)) + categoryItems)
                }
            }
        }
    }

    fun onSearchQueryChange(query: String) {
        _searchQuery.value = query
        _uiState.update { it.copy(searchQuery = query) }
        viewModelScope.launch {
            userPreferences.setLastSearchQuery(query)
        }
    }

    fun onStatusFilterChange(status: String?) {
        _selectedStatus.value = status
        _uiState.update { it.copy(selectedStatus = status) }
    }

    fun onCategoryFilterChange(categoryId: Int?) {
        _selectedCategoryId.value = categoryId
        _uiState.update { it.copy(selectedCategoryId = categoryId) }
    }

    fun onSortChange(sortBy: String) {
        _sortBy.value = sortBy
        _uiState.update { it.copy(sortBy = sortBy) }
        viewModelScope.launch {
            userPreferences.setSortOrder(sortBy)
        }
    }

    fun deleteBook(bookId: Int) {
        viewModelScope.launch {
            try {
                repository.deleteBookById(bookId)
            } catch (e: Exception) {
                _uiState.update { it.copy(error = "删除失败: ${e.message}") }
            }
        }
    }

    fun clearError() {
        _uiState.update { it.copy(error = null) }
    }

    class Factory(
        private val repository: BookRepository,
        private val userPreferences: UserPreferencesRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return HomeViewModel(repository, userPreferences) as T
        }
    }
}
