package com.example.bookshelf.viewmodel

import com.example.bookshelf.model.Book

// ===== Home Screen =====
data class HomeUiState(
    val books: List<Book> = emptyList(),
    val isLoading: Boolean = true,
    val error: String? = null,
    val searchQuery: String = "",
    val selectedStatus: String? = null,
    val selectedCategoryId: Int? = null,
    val sortBy: String = "date",
    val categories: List<CategoryItem> = emptyList()
) {
    val isEmpty: Boolean get() = !isLoading && error == null && books.isEmpty()
    val isSearchActive: Boolean get() = searchQuery.isNotEmpty()
}

data class CategoryItem(
    val id: Int,
    val name: String,
    val bookCount: Int = 0
)

// ===== Search Screen (Online) =====
sealed interface SearchUiState {
    data object Idle : SearchUiState
    data class Loading(val query: String) : SearchUiState
    data class Success(val results: List<OnlineBookItem>, val query: String) : SearchUiState
    data class Error(val message: String, val query: String) : SearchUiState
}

data class OnlineBookItem(
    val title: String,
    val author: String,
    val coverI: Long?,
    val publishYear: Int?,
    val isbn: String?,
    val pageCount: Int?,
    val subjects: List<String>?,
    val coverUrl: String?
)

// ===== Detail Screen =====
data class DetailUiState(
    val book: Book? = null,
    val isLoading: Boolean = true,
    val error: String? = null
)

// ===== Edit Screen =====
data class EditUiState(
    val title: String = "",
    val author: String = "",
    val coverUrl: String = "",
    val description: String = "",
    val publishYear: String = "",
    val isbn: String = "",
    val categoryId: Int = 1,
    val readingStatus: String = "WANT_TO_READ",
    val rating: Float = 0f,
    val notes: String = "",
    val pageCount: String = "",
    val categories: List<CategoryItem> = emptyList(),
    val isEditMode: Boolean = false,
    val isSaving: Boolean = false,
    val saveSuccess: Boolean = false,
    val error: String? = null,
    // Validation
    val titleError: String? = null,
    val authorError: String? = null,
    // 编辑模式下保留原始创建时间
    val createdAt: Long = System.currentTimeMillis()
)

// ===== Settings Screen =====
data class SettingsUiState(
    val themeMode: String = "SYSTEM",
    val sortOrder: String = "date",
    val categoryCount: Int = 0,
    val totalBooks: Int = 0,
    val readingCount: Int = 0,
    val finishedCount: Int = 0,
    val wantToReadCount: Int = 0
)
