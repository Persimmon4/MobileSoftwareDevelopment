package com.example.bookshelf.navigation

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.example.bookshelf.data.repository.BookRepository
import com.example.bookshelf.datastore.UserPreferencesRepository
import com.example.bookshelf.ui.screens.DetailScreen
import com.example.bookshelf.ui.screens.EditScreen
import com.example.bookshelf.ui.screens.HomeScreen
import com.example.bookshelf.ui.screens.SearchScreen
import com.example.bookshelf.ui.screens.SettingsScreen
import com.example.bookshelf.viewmodel.DetailViewModel
import com.example.bookshelf.viewmodel.EditViewModel
import com.example.bookshelf.viewmodel.HomeViewModel
import com.example.bookshelf.viewmodel.SearchViewModel
import com.example.bookshelf.viewmodel.SettingsViewModel

object Routes {
    const val HOME = "home"
    const val SEARCH = "search"
    const val DETAIL = "detail/{bookId}"
    const val EDIT = "edit/{bookId}"
    const val ADD = "add"
    const val SETTINGS = "settings"

    fun detail(bookId: Int) = "detail/$bookId"
    fun edit(bookId: Int) = "edit/$bookId"
}

@Composable
fun AppNavigation(
    navController: NavHostController,
    repository: BookRepository,
    userPreferences: UserPreferencesRepository
) {
    NavHost(
        navController = navController,
        startDestination = Routes.HOME,
        enterTransition = {
            fadeIn(animationSpec = tween(300)) +
                    slideIntoContainer(AnimatedContentTransitionScope.SlideDirection.Left, tween(300))
        },
        exitTransition = {
            fadeOut(animationSpec = tween(300)) +
                    slideOutOfContainer(AnimatedContentTransitionScope.SlideDirection.Left, tween(300))
        },
        popEnterTransition = {
            fadeIn(animationSpec = tween(300)) +
                    slideIntoContainer(AnimatedContentTransitionScope.SlideDirection.Right, tween(300))
        },
        popExitTransition = {
            fadeOut(animationSpec = tween(300)) +
                    slideOutOfContainer(AnimatedContentTransitionScope.SlideDirection.Right, tween(300))
        }
    ) {
        // Home Screen
        composable(Routes.HOME) {
            val viewModel: HomeViewModel = viewModel(
                factory = HomeViewModel.Factory(repository, userPreferences)
            )
            HomeScreen(
                viewModel = viewModel,
                onBookClick = { bookId ->
                    navController.navigate(Routes.detail(bookId))
                },
                onNavigateToSearch = {
                    navController.navigate(Routes.SEARCH)
                },
                onNavigateToSettings = {
                    navController.navigate(Routes.SETTINGS)
                }
            )
        }

        // Search Screen
        composable(Routes.SEARCH) {
            val context = LocalContext.current
            val viewModel: SearchViewModel = viewModel(
                factory = SearchViewModel.Factory(
                    repository,
                    context.applicationContext as android.app.Application
                )
            )
            SearchScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() },
                onBookAdded = { navController.popBackStack() }
            )
        }

        // Detail Screen
        composable(
            route = Routes.DETAIL,
            arguments = listOf(
                navArgument("bookId") { type = NavType.IntType }
            )
        ) { backStackEntry ->
            val bookId = backStackEntry.arguments?.getInt("bookId") ?: return@composable
            val viewModel: DetailViewModel = viewModel(
                factory = DetailViewModel.Factory(repository, bookId)
            )
            DetailScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToEdit = { id ->
                    navController.navigate(Routes.edit(id))
                }
            )
        }

        // Edit Screen
        composable(
            route = Routes.EDIT,
            arguments = listOf(
                navArgument("bookId") { type = NavType.IntType }
            )
        ) { backStackEntry ->
            val bookId = backStackEntry.arguments?.getInt("bookId") ?: return@composable
            val viewModel: EditViewModel = viewModel(
                factory = EditViewModel.Factory(repository, bookId)
            )
            EditScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // Add Screen
        composable(Routes.ADD) {
            val viewModel: EditViewModel = viewModel(
                factory = EditViewModel.Factory(repository, null)
            )
            EditScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // Settings Screen
        composable(Routes.SETTINGS) {
            val viewModel: SettingsViewModel = viewModel(
                factory = SettingsViewModel.Factory(repository, userPreferences)
            )
            SettingsScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }
}
