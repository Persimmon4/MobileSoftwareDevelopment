# Add project specific ProGuard rules here.
-keepattributes Signature
-keepattributes *Annotation*
-keep class com.example.bookshelf.data.network.dto.** { *; }
