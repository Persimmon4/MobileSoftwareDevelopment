package com.example.todolist.navigation

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object Detail : Screen("detail/{todoId}")
    object Settings : Screen("settings")
    object AddTodo : Screen("add")
    object EditTodo : Screen("edit/{todoId}")

    fun withArgs(vararg args: String): String {
        return buildString {
            append(route)
            args.forEach { arg ->
                append("/$arg")
            }
        }
    }
}