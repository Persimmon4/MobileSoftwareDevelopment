package com.example.todolist

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.todolist.data.database.TodoDatabase
import com.example.todolist.data.network.NetworkModule
import com.example.todolist.data.repository.CategoryRepository
import com.example.todolist.data.repository.TodoRepository
import com.example.todolist.datastore.UserPreferencesRepository
import com.example.todolist.datastore.ThemeMode
import com.example.todolist.navigation.Screen
import com.example.todolist.ui.screens.AddTodoScreen
import com.example.todolist.ui.screens.DetailScreen
import com.example.todolist.ui.screens.EditTodoScreen
import com.example.todolist.ui.screens.HomeScreen
import com.example.todolist.ui.screens.SettingsScreen
import com.example.todolist.ui.theme.TodoListTheme
import com.example.todolist.viewmodel.CategoryViewModel
import com.example.todolist.viewmodel.CategoryViewModelFactory
import com.example.todolist.viewmodel.TodoViewModel
import com.example.todolist.viewmodel.TodoViewModelFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val database = TodoDatabase.getInstance(this)
        val todoRepository = TodoRepository(database.todoDao(), NetworkModule.networkDataSource)
        val categoryRepository = CategoryRepository(database.categoryDao(), NetworkModule.networkDataSource)
        val userPreferencesRepository = UserPreferencesRepository(this)

        setContent {
            val themeMode by userPreferencesRepository.themeMode.collectAsState(initial = ThemeMode.SYSTEM)
            val darkTheme = when (themeMode) {
                ThemeMode.LIGHT -> false
                ThemeMode.DARK -> true
                ThemeMode.SYSTEM -> androidx.compose.foundation.isSystemInDarkTheme()
            }

            TodoListTheme(darkTheme = darkTheme) {
                val navController = rememberNavController()

                val todoViewModel: TodoViewModel = viewModel(
                    factory = TodoViewModelFactory(todoRepository)
                )

                val categoryViewModel: CategoryViewModel = viewModel(
                    factory = CategoryViewModelFactory(categoryRepository)
                )

                NavHost(navController = navController, startDestination = Screen.Home.route) {
                    composable(Screen.Home.route) {
                        HomeScreen(navController, todoViewModel, categoryViewModel)
                    }
                    composable(Screen.Detail.route) { backStackEntry ->
                        val todoId = backStackEntry.arguments?.getString("todoId")?.toLongOrNull()
                        todoId?.let {
                            DetailScreen(navController, todoViewModel, it)
                        }
                    }
                    composable(Screen.AddTodo.route) {
                        AddTodoScreen(navController, todoViewModel, categoryViewModel)
                    }
                    composable(Screen.EditTodo.route) { backStackEntry ->
                        val todoId = backStackEntry.arguments?.getString("todoId")?.toLongOrNull()
                        todoId?.let {
                            EditTodoScreen(navController, todoViewModel, categoryViewModel, it)
                        }
                    }
                    composable(Screen.Settings.route) {
                        SettingsScreen(navController, userPreferencesRepository)
                    }
                }
            }
        }
    }
}