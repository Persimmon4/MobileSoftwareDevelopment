package com.example.todolist.data.network

import com.example.todolist.data.network.dto.CategoryDto
import com.example.todolist.data.network.dto.TodoDto
import kotlinx.coroutines.delay

class NetworkDataSource(private val apiService: ApiService) {

    suspend fun fetchTodos(): Result<List<TodoDto>> {
        return try {
            delay(1000)
            val mockTodos = listOf(
                TodoDto(1, "学习 Jetpack Compose", "完成 Compose 基础学习", false, 2, System.currentTimeMillis() - 86400000, null),
                TodoDto(2, "复习 Room 数据库", "回顾 Entity、DAO 和 Repository", false, 1, System.currentTimeMillis() - 43200000, null),
                TodoDto(3, "完成期末作业", "实现一个完整的待办清单应用", false, 2, System.currentTimeMillis(), null),
                TodoDto(4, "阅读 Kotlin 协程文档", "深入理解协程原理", true, 1, System.currentTimeMillis() - 172800000, null),
                TodoDto(5, "练习 Git 命令", "学习分支管理和合并", true, 0, System.currentTimeMillis() - 259200000, null)
            )
            Result.success(mockTodos)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun fetchCategories(): Result<List<CategoryDto>> {
        return try {
            delay(500)
            val mockCategories = listOf(
                CategoryDto(1, "学习", "book", "#4CAF50"),
                CategoryDto(2, "工作", "briefcase", "#2196F3"),
                CategoryDto(3, "生活", "home", "#FF9800"),
                CategoryDto(4, "健康", "heart", "#F44336"),
                CategoryDto(5, "娱乐", "gamepad", "#9C27B0")
            )
            Result.success(mockCategories)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}