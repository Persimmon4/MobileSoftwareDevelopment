package com.example.todolist.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.todolist.data.dao.CategoryDao
import com.example.todolist.data.dao.TodoDao
import com.example.todolist.data.entity.CategoryEntity
import com.example.todolist.data.entity.TodoEntity

@Database(entities = [TodoEntity::class, CategoryEntity::class], version = 2, exportSchema = false)
abstract class TodoDatabase : RoomDatabase() {

    abstract fun todoDao(): TodoDao
    abstract fun categoryDao(): CategoryDao

    companion object {
        @Volatile
        private var INSTANCE: TodoDatabase? = null

        fun getInstance(context: Context): TodoDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    TodoDatabase::class.java,
                    "todo_database"
                ).addMigrations(MIGRATION_1_2).build().also { INSTANCE = it }
            }
        }

        private val MIGRATION_1_2 = androidx.room.migration.Migration(1, 2) { database ->
            database.execSQL("CREATE TABLE IF NOT EXISTS categories (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name TEXT NOT NULL, icon TEXT NOT NULL, color TEXT NOT NULL, isDefault INTEGER NOT NULL DEFAULT 0)")
            database.execSQL("ALTER TABLE todos ADD COLUMN categoryId INTEGER NOT NULL DEFAULT 1")
            database.execSQL("INSERT OR IGNORE INTO categories (id, name, icon, color, isDefault) VALUES (1, '学习', 'book', '#4CAF50', 1)")
            database.execSQL("INSERT OR IGNORE INTO categories (id, name, icon, color) VALUES (2, '工作', 'briefcase', '#2196F3')")
            database.execSQL("INSERT OR IGNORE INTO categories (id, name, icon, color) VALUES (3, '生活', 'home', '#FF9800')")
            database.execSQL("INSERT OR IGNORE INTO categories (id, name, icon, color) VALUES (4, '健康', 'heart', '#F44336')")
            database.execSQL("INSERT OR IGNORE INTO categories (id, name, icon, color) VALUES (5, '娱乐', 'gamepad', '#9C27B0')")
        }
    }
}
