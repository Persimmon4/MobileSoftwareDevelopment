package com.example.todolist.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.todolist.ui.theme.PriorityHigh
import com.example.todolist.ui.theme.PriorityLow
import com.example.todolist.ui.theme.PriorityMedium
import com.example.todolist.viewmodel.CategoryViewModel
import com.example.todolist.viewmodel.TodoViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditTodoScreen(navController: NavController, todoViewModel: TodoViewModel, categoryViewModel: CategoryViewModel, todoId: Long) {
    val todo by todoViewModel.getTodoById(todoId).collectAsState(initial = null)
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var priority by remember { mutableIntStateOf(0) }
    var selectedCategoryId by remember { mutableLongStateOf(1L) }
    val categories by categoryViewModel.uiState.collectAsState()

    LaunchedEffect(todo) {
        todo?.let {
            title = it.title
            description = it.description
            priority = it.priority
            selectedCategoryId = it.categoryId
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("编辑任务") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "返回")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { paddingValues ->
        if (todo != null) {
            val todoItem = todo!!
            Column(
                modifier = Modifier
                    .padding(paddingValues)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("任务标题") },
                        placeholder = { Text("请输入任务标题") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        isError = title.isBlank()
                    )

                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("备注（可选）") },
                        placeholder = { Text("请输入任务备注") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 4
                    )

                    Column {
                        Text("优先级", style = MaterialTheme.typography.labelLarge)
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(
                                Triple(0, "低", PriorityLow),
                                Triple(1, "中", PriorityMedium),
                                Triple(2, "高", PriorityHigh)
                            ).forEach { (value, label, color) ->
                                FilterChip(
                                    selected = priority == value,
                                    onClick = { priority = value },
                                    label = { Text(label) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = color.copy(alpha = 0.2f),
                                        selectedLabelColor = color
                                    )
                                )
                            }
                        }
                    }

                    Column {
                        Text("分类", style = MaterialTheme.typography.labelLarge)
                        Spacer(modifier = Modifier.height(8.dp))
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(categories.categories) { category ->
                                FilterChip(
                                    selected = selectedCategoryId == category.id,
                                    onClick = { selectedCategoryId = category.id },
                                    label = { Text(category.name) }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            if (title.isNotBlank()) {
                                todoViewModel.updateTodo(
                                    todo = todoItem,
                                    title = title.trim(),
                                    description = description.trim(),
                                    priority = priority,
                                    categoryId = selectedCategoryId
                                )
                                navController.popBackStack()
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = title.isNotBlank()
                    ) {
                        Text("保存修改")
                    }
                }
            }
        } else {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("任务不存在", style = MaterialTheme.typography.headlineMedium)
            }
        }
    }
}