package com.example.todolist.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.todolist.data.entity.TodoEntity
import com.example.todolist.data.repository.FilterMode
import com.example.todolist.data.repository.TodoRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class TodoUiState(
    val todos: List<TodoEntity> = emptyList(),
    val filterMode: FilterMode = FilterMode.ALL,
    val selectedCategoryId: Long? = null,
    val searchQuery: String = "",
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val showAddDialog: Boolean = false
)

class TodoViewModel(private val repository: TodoRepository) : ViewModel() {

    private val _filterMode = MutableStateFlow(FilterMode.ALL)
    private val _selectedCategoryId = MutableStateFlow<Long?>(null)
    private val _searchQuery = MutableStateFlow("")
    private val _isLoading = MutableStateFlow(false)
    private val _errorMessage = MutableStateFlow<String?>(null)
    private val _uiState = MutableStateFlow(TodoUiState())

    val uiState: StateFlow<TodoUiState> = combine(
        _filterMode,
        _selectedCategoryId,
        _searchQuery,
        _isLoading,
        _errorMessage
    ) { filterMode, categoryId, searchQuery, isLoading, errorMessage ->
        TodoUiState(
            filterMode = filterMode,
            selectedCategoryId = categoryId,
            searchQuery = searchQuery,
            isLoading = isLoading,
            errorMessage = errorMessage
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = TodoUiState()
    )

    val todos: Flow<List<TodoEntity>> = combine(
        _filterMode,
        _selectedCategoryId,
        _searchQuery
    ) { filterMode, categoryId, searchQuery ->
        Triple(filterMode, categoryId, searchQuery)
    }.flatMapLatest { (filterMode, categoryId, searchQuery) ->
        if (searchQuery.isNotBlank()) {
            repository.searchTodos(searchQuery)
        } else {
            repository.getTodos(filterMode, categoryId)
        }
    }

    init {
        syncFromNetwork()
    }

    fun setFilterMode(mode: FilterMode) {
        _filterMode.value = mode
    }

    fun setSelectedCategoryId(categoryId: Long?) {
        _selectedCategoryId.value = categoryId
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun addTodo(title: String, description: String, priority: Int, categoryId: Long = 1) {
        viewModelScope.launch {
            repository.addTodo(title, description, priority, categoryId)
        }
    }

    fun updateTodo(todo: TodoEntity, title: String, description: String, priority: Int, categoryId: Long) {
        viewModelScope.launch {
            repository.updateTodo(todo, title, description, priority, categoryId)
        }
    }

    fun toggleComplete(todo: TodoEntity) {
        viewModelScope.launch {
            repository.toggleComplete(todo)
        }
    }

    fun deleteTodo(todo: TodoEntity) {
        viewModelScope.launch {
            repository.deleteTodo(todo)
        }
    }

    fun clearCompleted() {
        viewModelScope.launch {
            repository.clearCompleted()
        }
    }

    fun getTodoById(id: Long): Flow<TodoEntity?> {
        return flow {
            emit(repository.getTodoById(id))
        }
    }

    fun syncFromNetwork() {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                repository.syncFromNetwork()
                _errorMessage.value = null
            } catch (e: Exception) {
                _errorMessage.value = "网络同步失败: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun dismissError() {
        _errorMessage.value = null
    }

    fun showAddDialog() {
        _uiState.update { it.copy(showAddDialog = true) }
    }

    fun hideAddDialog() {
        _uiState.update { it.copy(showAddDialog = false) }
    }
}

class TodoViewModelFactory(private val repository: TodoRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(TodoViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return TodoViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}