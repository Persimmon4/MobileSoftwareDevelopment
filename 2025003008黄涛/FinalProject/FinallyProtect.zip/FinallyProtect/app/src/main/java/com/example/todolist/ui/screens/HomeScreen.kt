package com.example.todolist.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.todolist.data.entity.CategoryEntity
import com.example.todolist.data.entity.TodoEntity
import com.example.todolist.navigation.Screen
import com.example.todolist.ui.theme.PriorityHigh
import com.example.todolist.ui.theme.PriorityLow
import com.example.todolist.ui.theme.PriorityMedium
import com.example.todolist.data.repository.FilterMode
import com.example.todolist.viewmodel.CategoryViewModel
import com.example.todolist.viewmodel.TodoViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(navController: NavController, todoViewModel: TodoViewModel, categoryViewModel: CategoryViewModel) {
    val uiState by todoViewModel.uiState.collectAsState()
    val todos by todoViewModel.todos.collectAsState(initial = emptyList())
    val categories by categoryViewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("待办清单") },
                actions = {
                    IconButton(onClick = { navController.navigate(Screen.Settings.route) }) {
                        Icon(Icons.Filled.Settings, contentDescription = "设置")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    actionIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { navController.navigate(Screen.AddTodo.route) },
                icon = { Icon(Icons.Filled.Add, contentDescription = "添加") },
                text = { Text("新增") },
                containerColor = MaterialTheme.colorScheme.primary
            )
        },
        snackbarHost = {
            SnackbarHost(hostState = snackbarHostState)
        }
    ) { paddingValues ->
        Column(modifier = Modifier.padding(paddingValues)) {
            SearchBar(
                query = uiState.searchQuery,
                onQueryChange = { todoViewModel.setSearchQuery(it) },
                onRefresh = { todoViewModel.syncFromNetwork() },
                isLoading = uiState.isLoading
            )

            CategoryRow(
                categories = categories.categories,
                selectedCategoryId = uiState.selectedCategoryId,
                onCategorySelect = { todoViewModel.setSelectedCategoryId(it) }
            )

            FilterTabs(
                currentFilter = uiState.filterMode,
                onFilterChange = { todoViewModel.setFilterMode(it) }
            )

            if (todos.isNotEmpty()) {
                TaskSummary(
                    totalCount = todos.size,
                    activeCount = todos.count { !it.isCompleted },
                    completedCount = todos.count { it.isCompleted },
                    onClearCompleted = { todoViewModel.clearCompleted() }
                )
            }

            if (uiState.isLoading) {
                LoadingState()
            } else if (todos.isEmpty()) {
                EmptyState(filterMode = uiState.filterMode, hasSearch = uiState.searchQuery.isNotBlank())
            } else {
                TaskList(
                    todos = todos,
                    onToggleComplete = { todoViewModel.toggleComplete(it) },
                    onTodoClick = { navController.navigate(Screen.Detail.withArgs(it.id.toString())) },
                    onDelete = { todoViewModel.deleteTodo(it) }
                )
            }
        }
    }

    LaunchedEffect(uiState.errorMessage) {
        uiState.errorMessage?.let {
            snackbarHostState.showSnackbar(
                message = it,
                actionLabel = "关闭"
            )
            todoViewModel.dismissError()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchBar(query: String, onQueryChange: (String) -> Unit, onRefresh: () -> Unit, isLoading: Boolean) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        shape = RoundedCornerShape(16.dp),
        shadowElevation = 4.dp
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.Search, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.width(8.dp))
            TextField(
                value = query,
                onValueChange = onQueryChange,
                placeholder = { Text("搜索任务...") },
                modifier = Modifier.weight(1f),
                singleLine = true,
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    disabledContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    disabledIndicatorColor = Color.Transparent
                )
            )
            if (isLoading) {
                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
            } else {
                IconButton(onClick = onRefresh) {
                    Icon(Icons.Filled.Refresh, contentDescription = "刷新", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
fun CategoryRow(categories: List<CategoryEntity>, selectedCategoryId: Long?, onCategorySelect: (Long?) -> Unit) {
    LazyRow(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            FilterChip(
                selected = selectedCategoryId == null,
                onClick = { onCategorySelect(null) },
                label = { Text("全部") },
                leadingIcon = { Icon(Icons.Filled.AllInclusive, contentDescription = null, modifier = Modifier.size(18.dp)) }
            )
        }
        items(categories, key = { it.id }) { category ->
            FilterChip(
                selected = selectedCategoryId == category.id,
                onClick = { onCategorySelect(category.id) },
                label = { Text(category.name) },
                leadingIcon = {
                    Box(
                        modifier = Modifier
                            .size(20.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(parseColor(category.color).copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            when (category.icon) {
                                "book" -> "📚"
                                "briefcase" -> "💼"
                                "home" -> "🏠"
                                "heart" -> "❤️"
                                "gamepad" -> "🎮"
                                else -> "📌"
                            },
                            fontSize = MaterialTheme.typography.bodySmall.fontSize
                        )
                    }
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = parseColor(category.color).copy(alpha = 0.15f),
                    selectedLabelColor = parseColor(category.color)
                )
            )
        }
    }
}

@Composable
fun FilterTabs(currentFilter: FilterMode, onFilterChange: (FilterMode) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        FilterMode.entries.forEach { mode ->
            FilterChip(
                selected = currentFilter == mode,
                onClick = { onFilterChange(mode) },
                label = {
                    Text(
                        when (mode) {
                            FilterMode.ALL -> "全部"
                            FilterMode.ACTIVE -> "进行中"
                            FilterMode.COMPLETED -> "已完成"
                        }
                    )
                }
            )
        }
    }
}

@Composable
fun TaskSummary(totalCount: Int, activeCount: Int, completedCount: Int, onClearCompleted: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "共 $totalCount 项 · 待完成 $activeCount 项",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(1f)
        )
        if (completedCount > 0) {
            TextButton(onClick = onClearCompleted) {
                Text("清除已完成", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
fun LoadingState() {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator()
            Spacer(modifier = Modifier.height(16.dp))
            Text("加载中...", style = MaterialTheme.typography.bodyLarge)
        }
    }
}

@Composable
fun EmptyState(filterMode: FilterMode, hasSearch: Boolean) {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = if (hasSearch) Icons.Filled.SearchOff else Icons.Filled.Inbox,
                contentDescription = null,
                modifier = Modifier.size(80.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = when {
                    hasSearch -> "没有找到匹配的任务"
                    filterMode == FilterMode.ACTIVE -> "没有进行中的任务"
                    filterMode == FilterMode.COMPLETED -> "还没有已完成的任务"
                    else -> "还没有任务\n点击右下角按钮添加吧"
                },
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TaskList(todos: List<TodoEntity>, onToggleComplete: (TodoEntity) -> Unit, onTodoClick: (TodoEntity) -> Unit, onDelete: (TodoEntity) -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(todos, key = { it.id }) { todo ->
            TodoCard(todo = todo, onToggleComplete = onToggleComplete, onClick = onTodoClick, onDelete = onDelete)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TodoCard(todo: TodoEntity, onToggleComplete: (TodoEntity) -> Unit, onClick: (TodoEntity) -> Unit, onDelete: (TodoEntity) -> Unit) {
    var showDeleteConfirm by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        onClick = { onClick(todo) },
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (todo.isCompleted) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                modifier = Modifier
                    .width(4.dp)
                    .height(48.dp),
                color = when (todo.priority) {
                    2 -> PriorityHigh
                    1 -> PriorityMedium
                    else -> PriorityLow
                },
                shape = MaterialTheme.shapes.small
            ) {}

            Spacer(modifier = Modifier.width(12.dp))

            Checkbox(
                checked = todo.isCompleted,
                onCheckedChange = { onToggleComplete(todo) }
            )

            Spacer(modifier = Modifier.width(8.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = todo.title,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textDecoration = if (todo.isCompleted) TextDecoration.LineThrough else TextDecoration.None,
                    color = if (todo.isCompleted) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
                )
                if (todo.description.isNotEmpty()) {
                    Text(
                        text = todo.description,
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                todo.dueDate?.let { dueDate ->
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "📅 ${formatDate(dueDate)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            IconButton(onClick = { showDeleteConfirm = true }) {
                Icon(
                    Icons.Filled.Delete,
                    contentDescription = "删除",
                    tint = MaterialTheme.colorScheme.error
                )
            }
        }
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("确认删除") },
            text = { Text("确定要删除「${todo.title}」吗？") },
            confirmButton = {
                TextButton(onClick = {
                    onDelete(todo)
                    showDeleteConfirm = false
                }) {
                    Text("删除", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("取消")
                }
            }
        )
    }
}

private fun formatDate(timestamp: Long): String {
    val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault())
    return sdf.format(java.util.Date(timestamp))
}

private fun parseColor(colorString: String): Color {
    return try {
        Color(android.graphics.Color.parseColor(colorString))
    } catch (e: Exception) {
        Color.Gray
    }
}