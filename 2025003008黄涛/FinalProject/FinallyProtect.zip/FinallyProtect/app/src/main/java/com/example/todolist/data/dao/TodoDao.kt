package com.example.todolist.data.dao

import androidx.room.*
import com.example.todolist.data.entity.TodoEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TodoDao {

    @Query("SELECT * FROM todos ORDER BY priority DESC, createdAt DESC")
    fun getAllTodos(): Flow<List<TodoEntity>>

    @Query("SELECT * FROM todos WHERE isCompleted = 0 ORDER BY priority DESC, createdAt DESC")
    fun getActiveTodos(): Flow<List<TodoEntity>>

    @Query("SELECT * FROM todos WHERE isCompleted = 1 ORDER BY createdAt DESC")
    fun getCompletedTodos(): Flow<List<TodoEntity>>

    @Query("SELECT * FROM todos WHERE id = :id")
    suspend fun getTodoById(id: Long): TodoEntity?

    @Query("SELECT * FROM todos WHERE categoryId = :categoryId ORDER BY priority DESC, createdAt DESC")
    fun getTodosByCategory(categoryId: Long): Flow<List<TodoEntity>>

    @Query("SELECT * FROM todos WHERE title LIKE '%' || :query || '%' OR description LIKE '%' || :query || '%' ORDER BY priority DESC, createdAt DESC")
    fun searchTodos(query: String): Flow<List<TodoEntity>>

    @Query("SELECT * FROM todos WHERE isCompleted = 0 AND categoryId = :categoryId ORDER BY priority DESC, createdAt DESC")
    fun getActiveTodosByCategory(categoryId: Long): Flow<List<TodoEntity>>

    @Query("SELECT COUNT(*) FROM todos")
    suspend fun getTodoCount(): Int

    @Query("SELECT COUNT(*) FROM todos WHERE isCompleted = 1")
    suspend fun getCompletedCount(): Int

    @Query("SELECT COUNT(*) FROM todos WHERE categoryId = :categoryId")
    suspend fun getCountByCategory(categoryId: Long): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTodo(todo: TodoEntity): Long

    @Update
    suspend fun updateTodo(todo: TodoEntity)

    @Delete
    suspend fun deleteTodo(todo: TodoEntity)

    @Query("DELETE FROM todos WHERE id = :id")
    suspend fun deleteTodoById(id: Long)

    @Query("UPDATE todos SET isCompleted = :completed WHERE id = :id")
    suspend fun setCompleted(id: Long, completed: Boolean)

    @Query("DELETE FROM todos WHERE isCompleted = 1")
    suspend fun clearCompleted()

    @Query("UPDATE todos SET categoryId = :newCategoryId WHERE categoryId = :oldCategoryId")
    suspend fun updateTodosCategory(oldCategoryId: Long, newCategoryId: Long)
}
