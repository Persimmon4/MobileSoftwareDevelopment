package com.example.todolist.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.todolist.datastore.ThemeMode
import com.example.todolist.datastore.UserPreferencesRepository
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(navController: NavController, userPreferencesRepository: UserPreferencesRepository) {
    val coroutineScope = rememberCoroutineScope()
    val themeMode by userPreferencesRepository.themeMode.collectAsState(initial = ThemeMode.SYSTEM)
    val defaultPriority by userPreferencesRepository.defaultPriority.collectAsState(initial = 0)
    val showCompleted by userPreferencesRepository.showCompleted.collectAsState(initial = true)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("设置") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "返回")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .padding(paddingValues)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
        ) {
            Card(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("外观设置", style = MaterialTheme.typography.headlineSmall)
                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Palette, contentDescription = null, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("主题模式", style = MaterialTheme.typography.titleMedium)
                            Text(
                                when (themeMode) {
                                    ThemeMode.LIGHT -> "浅色模式"
                                    ThemeMode.DARK -> "深色模式"
                                    ThemeMode.SYSTEM -> "跟随系统"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        DropdownMenuBox(
                            expanded = remember { mutableStateOf(false) },
                            onToggle = {},
                            selectedItem = when (themeMode) {
                                ThemeMode.LIGHT -> "浅色模式"
                                ThemeMode.DARK -> "深色模式"
                                ThemeMode.SYSTEM -> "跟随系统"
                            },
                            items = listOf("浅色模式", "深色模式", "跟随系统"),
                            onItemSelected = { item ->
                                coroutineScope.launch {
                                    when (item) {
                                        "浅色模式" -> userPreferencesRepository.setThemeMode(ThemeMode.LIGHT)
                                        "深色模式" -> userPreferencesRepository.setThemeMode(ThemeMode.DARK)
                                        "跟随系统" -> userPreferencesRepository.setThemeMode(ThemeMode.SYSTEM)
                                    }
                                }
                            }
                        )
                    }
                }
            }

            Card(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("任务设置", style = MaterialTheme.typography.headlineSmall)
                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Flag, contentDescription = null, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("默认优先级", style = MaterialTheme.typography.titleMedium)
                            Text(
                                when (defaultPriority) {
                                    0 -> "低"
                                    1 -> "中"
                                    2 -> "高"
                                    else -> "低"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        DropdownMenuBox(
                            expanded = remember { mutableStateOf(false) },
                            onToggle = {},
                            selectedItem = when (defaultPriority) {
                                0 -> "低"
                                1 -> "中"
                                2 -> "高"
                                else -> "低"
                            },
                            items = listOf("低", "中", "高"),
                            onItemSelected = { item ->
                                coroutineScope.launch {
                                    userPreferencesRepository.setDefaultPriority(
                                        when (item) {
                                            "低" -> 0
                                            "中" -> 1
                                            "高" -> 2
                                            else -> 0
                                        }
                                    )
                                }
                            }
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.CheckCircle, contentDescription = null, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("显示已完成任务", style = MaterialTheme.typography.titleMedium)
                        }
                        Switch(
                            checked = showCompleted,
                            onCheckedChange = {
                                coroutineScope.launch {
                                    userPreferencesRepository.setShowCompleted(it)
                                }
                            }
                        )
                    }
                }
            }

            Card(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("关于", style = MaterialTheme.typography.headlineSmall)
                    Spacer(modifier = Modifier.height(16.dp))

                    Text("待办清单 v1.0", style = MaterialTheme.typography.bodyLarge)
                    Text("使用 Jetpack Compose 构建", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
fun DropdownMenuBox(expanded: MutableState<Boolean>, onToggle: () -> Unit, selectedItem: String, items: List<String>, onItemSelected: (String) -> Unit) {
    Box(modifier = Modifier.width(150.dp)) {
        Button(
            onClick = { expanded.value = !expanded.value },
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Text(selectedItem, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Left)
            Icon(Icons.Filled.ArrowDropDown, contentDescription = null)
        }
        DropdownMenu(
            expanded = expanded.value,
            onDismissRequest = { expanded.value = false }
        ) {
            items.forEach { item ->
                DropdownMenuItem(
                    onClick = {
                        onItemSelected(item)
                        expanded.value = false
                    },
                    text = { Text(item) }
                )
            }
        }
    }
}