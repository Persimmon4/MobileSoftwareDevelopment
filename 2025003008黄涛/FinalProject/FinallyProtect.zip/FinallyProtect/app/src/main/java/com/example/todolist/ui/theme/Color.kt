package com.example.todolist.ui.theme

import androidx.compose.ui.graphics.Color

val Primary = Color(0xFF6366F1)
val PrimaryLight = Color(0xFF818CF8)
val PrimaryDark = Color(0xFF4F46E5)

val Secondary = Color(0xFFEC4899)
val SecondaryLight = Color(0xFFF472B6)
val SecondaryDark = Color(0xFFDB2777)

val Tertiary = Color(0xFF14B8A6)
val TertiaryLight = Color(0xFF2DD4BF)
val TertiaryDark = Color(0xFF0D9488)

val BackgroundLight = Color(0xFFFAFAFA)
val BackgroundDark = Color(0xFF0F172A)

val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceDark = Color(0xFF1E293B)

val SurfaceVariantLight = Color(0xFFF1F5F9)
val SurfaceVariantDark = Color(0xFF334155)

val OnPrimaryLight = Color(0xFFFFFFFF)
val OnPrimaryDark = Color(0xFFFFFFFF)

val OnSecondaryLight = Color(0xFFFFFFFF)
val OnSecondaryDark = Color(0xFFFFFFFF)

val OnBackgroundLight = Color(0xFF1E293B)
val OnBackgroundDark = Color(0xFFF1F5F9)

val OnSurfaceLight = Color(0xFF0F172A)
val OnSurfaceDark = Color(0xFFF8FAFC)

val OnSurfaceVariantLight = Color(0xFF64748B)
val OnSurfaceVariantDark = Color(0xFF94A3B8)

val PriorityHigh = Color(0xFFEF4444)
val PriorityMedium = Color(0xFFF59E0B)
val PriorityLow = Color(0xFF22C55E)