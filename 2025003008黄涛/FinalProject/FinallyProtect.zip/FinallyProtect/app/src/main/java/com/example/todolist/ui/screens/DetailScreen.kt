package com.example.todolist.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.todolist.data.entity.TodoEntity
import com.example.todolist.navigation.Screen
import com.example.todolist.ui.theme.PriorityHigh
import com.example.todolist.ui.theme.PriorityLow
import com.example.todolist.ui.theme.PriorityMedium
import com.example.todolist.viewmodel.TodoViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(navController: NavController, todoViewModel: TodoViewModel, todoId: Long) {
    val todo by todoViewModel.getTodoById(todoId).collectAsState(initial = null)
    var showDeleteConfirm by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("任务详情") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "返回")
                    }
                },
                actions = {
                    IconButton(onClick = { navController.navigate(Screen.EditTodo.withArgs(todoId.toString())) }) {
                        Icon(Icons.Filled.Edit, contentDescription = "编辑")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary,
                    actionIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { paddingValues ->
        if (todo != null) {
            val todoItem = todo!!
            Column(
                modifier = Modifier
                    .padding(paddingValues)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                modifier = Modifier
                                    .width(6.dp)
                                    .height(32.dp),
                                color = when (todoItem.priority) {
                                    2 -> PriorityHigh
                                    1 -> PriorityMedium
                                    else -> PriorityLow
                                },
                                shape = MaterialTheme.shapes.small
                            ) {}
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = todoItem.title,
                                style = MaterialTheme.typography.headlineMedium,
                                textDecoration = if (todoItem.isCompleted) TextDecoration.LineThrough else TextDecoration.None
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = todoItem.isCompleted,
                                onCheckedChange = { todoViewModel.toggleComplete(todoItem) }
                            )
                            Text(
                                text = if (todoItem.isCompleted) "已完成" else "未完成",
                                style = MaterialTheme.typography.bodyLarge
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        if (todoItem.description.isNotEmpty()) {
                            Text(
                                text = "备注",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = todoItem.description,
                                style = MaterialTheme.typography.bodyLarge
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                        }

                        Text(
                            text = "优先级",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                modifier = Modifier.size(24.dp),
                                color = when (todoItem.priority) {
                                    2 -> PriorityHigh
                                    1 -> PriorityMedium
                                    else -> PriorityLow
                                },
                                shape = MaterialTheme.shapes.small
                            ) {}
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = when (todoItem.priority) {
                                    2 -> "高优先级"
                                    1 -> "中优先级"
                                    else -> "低优先级"
                                },
                                style = MaterialTheme.typography.bodyLarge
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = "创建时间",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = formatDateTime(todoItem.createdAt),
                            style = MaterialTheme.typography.bodyLarge
                        )

                        if (todoItem.dueDate != null) {
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "截止日期",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = formatDateTime(todoItem.dueDate!!),
                                style = MaterialTheme.typography.bodyLarge,
                                color = if (todoItem.dueDate!! < System.currentTimeMillis() && !todoItem.isCompleted) Color.Red else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = { showDeleteConfirm = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Icon(Icons.Filled.Delete, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("删除任务")
                }
            }
        } else {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("任务不存在", style = MaterialTheme.typography.headlineMedium)
            }
        }
    }

    if (showDeleteConfirm) {
        todo?.let { todoItem ->
            AlertDialog(
                onDismissRequest = { showDeleteConfirm = false },
                title = { Text("确认删除") },
                text = { Text("确定要删除「${todoItem.title}」吗？此操作无法撤销。") },
                confirmButton = {
                    TextButton(onClick = {
                        todoViewModel.deleteTodo(todoItem)
                        navController.popBackStack()
                    }) {
                        Text("删除", color = MaterialTheme.colorScheme.error)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showDeleteConfirm = false }) {
                        Text("取消")
                    }
                }
            )
        }
    }
}

private fun formatDateTime(timestamp: Long): String {
    val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault())
    return sdf.format(java.util.Date(timestamp))
}