package com.example.todolist.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

enum class ThemeMode {
    LIGHT, DARK, SYSTEM
}

class UserPreferencesRepository(private val context: Context) {

    private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "user_preferences")

    companion object {
        private val THEME_MODE = intPreferencesKey("theme_mode")
        private val DEFAULT_PRIORITY = intPreferencesKey("default_priority")
        private val SHOW_COMPLETED = booleanPreferencesKey("show_completed")
        private val LAST_SEARCH_QUERY = intPreferencesKey("last_search_query")
    }

    val themeMode: Flow<ThemeMode> = context.dataStore.data
        .map { preferences ->
            when (preferences[THEME_MODE] ?: 2) {
                0 -> ThemeMode.LIGHT
                1 -> ThemeMode.DARK
                else -> ThemeMode.SYSTEM
            }
        }

    val defaultPriority: Flow<Int> = context.dataStore.data
        .map { preferences ->
            preferences[DEFAULT_PRIORITY] ?: 0
        }

    val showCompleted: Flow<Boolean> = context.dataStore.data
        .map { preferences ->
            preferences[SHOW_COMPLETED] ?: true
        }

    suspend fun setThemeMode(themeMode: ThemeMode) {
        context.dataStore.edit { preferences ->
            preferences[THEME_MODE] = when (themeMode) {
                ThemeMode.LIGHT -> 0
                ThemeMode.DARK -> 1
                ThemeMode.SYSTEM -> 2
            }
        }
    }

    suspend fun setDefaultPriority(priority: Int) {
        context.dataStore.edit { preferences ->
            preferences[DEFAULT_PRIORITY] = priority
        }
    }

    suspend fun setShowCompleted(show: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[SHOW_COMPLETED] = show
        }
    }
}