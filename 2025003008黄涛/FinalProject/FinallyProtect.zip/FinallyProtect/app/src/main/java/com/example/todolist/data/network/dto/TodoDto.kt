package com.example.todolist.data.network.dto

import com.google.gson.annotations.SerializedName

data class TodoDto(
    @SerializedName("id") val id: Long,
    @SerializedName("title") val title: String,
    @SerializedName("description") val description: String,
    @SerializedName("isCompleted") val isCompleted: Boolean,
    @SerializedName("priority") val priority: Int,
    @SerializedName("createdAt") val createdAt: Long,
    @SerializedName("dueDate") val dueDate: Long?
)

data class CategoryDto(
    @SerializedName("id") val id: Long,
    @SerializedName("name") val name: String,
    @SerializedName("icon") val icon: String,
    @SerializedName("color") val color: String
)