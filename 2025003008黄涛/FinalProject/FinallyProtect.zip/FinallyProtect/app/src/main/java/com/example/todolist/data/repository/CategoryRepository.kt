package com.example.todolist.data.repository

import com.example.todolist.data.dao.CategoryDao
import com.example.todolist.data.entity.CategoryEntity
import com.example.todolist.data.network.NetworkDataSource
import kotlinx.coroutines.flow.Flow

class CategoryRepository(
    private val categoryDao: CategoryDao,
    private val networkDataSource: NetworkDataSource
) {

    fun getAllCategories(): Flow<List<CategoryEntity>> {
        return categoryDao.getAllCategories()
    }

    suspend fun getCategoryById(id: Long): CategoryEntity? {
        return categoryDao.getCategoryById(id)
    }

    suspend fun getDefaultCategory(): CategoryEntity? {
        return categoryDao.getDefaultCategory()
    }

    suspend fun addCategory(name: String, icon: String, color: String) {
        val category = CategoryEntity(name = name, icon = icon, color = color)
        categoryDao.insertCategory(category)
    }

    suspend fun updateCategory(category: CategoryEntity) {
        categoryDao.updateCategory(category)
    }

    suspend fun deleteCategory(category: CategoryEntity) {
        val default = getDefaultCategory()
        default?.let {
            if (category.id != it.id) {
                categoryDao.deleteCategory(category)
            }
        }
    }

    suspend fun syncFromNetwork() {
        val result = networkDataSource.fetchCategories()
        if (result.isSuccess) {
            val networkCategories = result.getOrDefault(emptyList())
            networkCategories.forEach { dto ->
                val existing = categoryDao.getCategoryById(dto.id)
                if (existing == null) {
                    categoryDao.insertCategory(
                        CategoryEntity(
                            id = dto.id,
                            name = dto.name,
                            icon = dto.icon,
                            color = dto.color
                        )
                    )
                }
            }
        }
    }
}