package com.example.todolist.data.network

import com.example.todolist.data.network.dto.CategoryDto
import com.example.todolist.data.network.dto.TodoDto
import retrofit2.http.GET

interface ApiService {
    @GET("todos")
    suspend fun getTodos(): List<TodoDto>

    @GET("categories")
    suspend fun getCategories(): List<CategoryDto>
}