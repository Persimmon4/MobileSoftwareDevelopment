package com.example.todolist.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "todos")
data class TodoEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val description: String = "",
    val isCompleted: Boolean = false,
    val priority: Int = 0,
    val categoryId: Long = 1,
    val createdAt: Long = System.currentTimeMillis(),
    val dueDate: Long? = null
)
