package com.example.todolist.data.repository

import com.example.todolist.data.dao.TodoDao
import com.example.todolist.data.entity.TodoEntity
import com.example.todolist.data.network.NetworkDataSource
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

class TodoRepository(
    private val todoDao: TodoDao,
    private val networkDataSource: NetworkDataSource
) {

    fun getTodos(filterMode: FilterMode, categoryId: Long? = null): Flow<List<TodoEntity>> {
        return when (filterMode) {
            FilterMode.ALL -> {
                categoryId?.let { todoDao.getTodosByCategory(it) } ?: todoDao.getAllTodos()
            }
            FilterMode.ACTIVE -> {
                categoryId?.let { todoDao.getActiveTodosByCategory(it) } ?: todoDao.getActiveTodos()
            }
            FilterMode.COMPLETED -> {
                categoryId?.let {
                    todoDao.getTodosByCategory(it).map { todos -> todos.filter { t -> t.isCompleted } }
                } ?: todoDao.getCompletedTodos()
            }
        }
    }

    fun searchTodos(query: String): Flow<List<TodoEntity>> {
        return todoDao.searchTodos(query)
    }

    suspend fun getTodoById(id: Long): TodoEntity? {
        return todoDao.getTodoById(id)
    }

    suspend fun addTodo(title: String, description: String, priority: Int, categoryId: Long = 1) {
        val todo = TodoEntity(
            title = title,
            description = description,
            priority = priority,
            categoryId = categoryId
        )
        todoDao.insertTodo(todo)
    }

    suspend fun updateTodo(todo: TodoEntity, title: String, description: String, priority: Int, categoryId: Long) {
        todoDao.updateTodo(
            todo.copy(title = title, description = description, priority = priority, categoryId = categoryId)
        )
    }

    suspend fun toggleComplete(todo: TodoEntity) {
        todoDao.setCompleted(todo.id, !todo.isCompleted)
    }

    suspend fun deleteTodo(todo: TodoEntity) {
        todoDao.deleteTodo(todo)
    }

    suspend fun clearCompleted() {
        todoDao.clearCompleted()
    }

    suspend fun syncFromNetwork() {
        val result = networkDataSource.fetchTodos()
        if (result.isSuccess) {
            val networkTodos = result.getOrDefault(emptyList())
            networkTodos.forEach { dto ->
                val existing = todoDao.getTodoById(dto.id)
                if (existing == null) {
                    todoDao.insertTodo(
                        TodoEntity(
                            id = dto.id,
                            title = dto.title,
                            description = dto.description,
                            isCompleted = dto.isCompleted,
                            priority = dto.priority,
                            createdAt = dto.createdAt,
                            dueDate = dto.dueDate
                        )
                    )
                }
            }
        }
    }

    suspend fun getStats(): Stats {
        val total = todoDao.getTodoCount()
        val completed = todoDao.getCompletedCount()
        return Stats(total, completed, total - completed)
    }
}

data class Stats(val total: Int, val completed: Int, val active: Int)

enum class FilterMode { ALL, ACTIVE, COMPLETED }