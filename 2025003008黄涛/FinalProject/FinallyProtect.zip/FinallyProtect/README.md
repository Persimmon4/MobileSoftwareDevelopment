# TodoList - 待办清单应用

一个基于 Jetpack Compose 和 Material 3 构建的现代化待办清单应用，支持任务管理、分类筛选、主题切换等功能。

## 功能特性

- ✅ **任务管理**：新增、编辑、删除任务，支持优先级设置
- 🔍 **搜索功能**：支持模糊搜索任务标题和描述
- 🏷️ **分类管理**：按分类筛选任务，自定义分类颜色和图标
- 📊 **状态筛选**：全部/进行中/已完成任务筛选
- 🎨 **主题切换**：支持浅色模式、深色模式、跟随系统
- 💾 **数据持久化**：使用 Room 数据库存储任务数据
- ☁️ **网络同步**：支持从网络获取初始任务数据
- ⚙️ **用户偏好**：使用 DataStore 保存主题和设置偏好

## 技术栈

- **UI Framework**: Jetpack Compose + Material 3
- **Architecture**: MVVM (Model-View-ViewModel)
- **Database**: Room
- **Network**: Retrofit + OkHttp
- **State Management**: ViewModel + StateFlow
- **Persistence**: DataStore Preferences
- **Navigation**: Navigation Compose
- **Async**: Kotlin Coroutines + Flow

## 项目结构

```
app/src/main/java/com/example/todolist/
├── MainActivity.kt                    # 主入口，导航配置
├── data/
│   ├── dao/                           # 数据访问对象
│   │   ├── TodoDao.kt
│   │   └── CategoryDao.kt
│   ├── database/                      # 数据库配置
│   │   └── TodoDatabase.kt
│   ├── entity/                        # 实体类
│   │   ├── TodoEntity.kt
│   │   └── CategoryEntity.kt
│   ├── network/                       # 网络层
│   │   ├── dto/                       # 数据传输对象
│   │   ├── ApiService.kt              # 网络接口
│   │   ├── NetworkDataSource.kt       # 网络数据源
│   │   └── NetworkModule.kt           # 网络配置
│   └── repository/                    # 数据仓库
│       ├── TodoRepository.kt
│       └── CategoryRepository.kt
├── datastore/                         # DataStore 配置
│   └── UserPreferencesRepository.kt
├── navigation/                        # 导航配置
│   └── AppNavigation.kt
├── ui/
│   ├── screens/                       # 页面组件
│   │   ├── HomeScreen.kt              # 首页
│   │   ├── DetailScreen.kt            # 详情页
│   │   ├── AddTodoScreen.kt           # 新增页
│   │   ├── EditTodoScreen.kt          # 编辑页
│   │   └── SettingsScreen.kt          # 设置页
│   └── theme/                         # 主题配置
│       ├── Color.kt
│       ├── Theme.kt
│       └── Type.kt
└── viewmodel/                         # 视图模型
    ├── TodoViewModel.kt
    └── CategoryViewModel.kt
```

## 快速开始

### 环境要求

- Android Studio Hedgehog (2023.1.1) 或更高版本
- Kotlin 1.9+
- Gradle 8.5+
- 最低 Android SDK: API 26 (Android 8.0)

### 运行步骤

1. 克隆仓库到本地

```bash
git clone https://github.com/你的用户名/学号-FinalProject.git
```

2. 使用 Android Studio 打开项目

3. 等待 Gradle 同步完成

4. 连接 Android 模拟器或真机

5. 点击 "Run" 按钮启动应用

## 使用说明

1. **添加任务**：点击右下角浮动按钮，填写任务标题、描述、优先级和分类
2. **完成任务**：在任务列表中点击复选框标记任务完成
3. **查看详情**：点击任务卡片进入详情页
4. **搜索任务**：在搜索栏输入关键词进行搜索
5. **筛选任务**：使用底部标签切换全部/进行中/已完成状态
6. **分类筛选**：点击顶部分类标签筛选特定分类的任务
7. **主题设置**：进入设置页切换主题模式

## License

MIT License
