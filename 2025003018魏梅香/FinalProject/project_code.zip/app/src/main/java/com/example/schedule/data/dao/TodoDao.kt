package com.example.schedule.data.dao

import androidx.room.*
import com.example.schedule.data.entity.TodoTask
import kotlinx.coroutines.flow.Flow

@Dao
interface TodoDao {
    @Query("SELECT * FROM todo_tasks ORDER BY is_done, created_at DESC")
    fun getAllTasks(): Flow<List<TodoTask>>

    @Insert
    suspend fun insert(task: TodoTask)

    @Update
    suspend fun update(task: TodoTask)

    @Delete
    suspend fun delete(task: TodoTask)
}
