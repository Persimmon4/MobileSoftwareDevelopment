package com.example.schedule.data.repository

import com.example.schedule.data.dao.CourseDao
import com.example.schedule.data.dao.TodoDao
import com.example.schedule.data.entity.Course
import com.example.schedule.data.entity.TodoTask
import kotlinx.coroutines.flow.Flow

class ScheduleRepository(private val courseDao: CourseDao, private val todoDao: TodoDao) {
    fun getAllCourses(): Flow<List<Course>> = courseDao.getAllCourses()
    fun getCoursesByDay(day: Int): Flow<List<Course>> = courseDao.getCoursesByDay(day)
    fun getCoursesForWeek(week: Int): Flow<List<Course>> = courseDao.getCoursesForWeek(week)
    fun searchCourses(query: String): Flow<List<Course>> = courseDao.searchCourses(query)
    suspend fun insertCourse(c: Course) = courseDao.insert(c)
    suspend fun updateCourse(c: Course) = courseDao.update(c)
    suspend fun deleteCourse(c: Course) = courseDao.delete(c)

    fun getAllTasks(): Flow<List<TodoTask>> = todoDao.getAllTasks()
    suspend fun insertTask(t: TodoTask) = todoDao.insert(t)
    suspend fun updateTask(t: TodoTask) = todoDao.update(t)
    suspend fun deleteTask(t: TodoTask) = todoDao.delete(t)
}
