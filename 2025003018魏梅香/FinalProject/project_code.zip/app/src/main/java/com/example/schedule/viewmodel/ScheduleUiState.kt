package com.example.schedule.viewmodel

import com.example.schedule.data.entity.Course

sealed interface CourseListState {
    data object Loading : CourseListState
    data class Success(val courses: List<Course>) : CourseListState
    data class Error(val msg: String) : CourseListState
}

data class CourseFormState(
    val name: String = "", val teacher: String = "", val classroom: String = "",
    val dayOfWeek: Int = 1, val startSlot: Int = 1, val endSlot: Int = 2,
    val weekStart: Int = 1, val weekEnd: Int = 16, val color: String = "#409EFF",
    val notes: String = "", val isEdit: Boolean = false, val editId: Long? = null,
    val nameError: String? = null, val saved: Boolean = false
)

sealed interface SemesterState {
    data object Loading : SemesterState
    data class Success(val currentWeek: Int) : SemesterState
    data class Error(val msg: String) : SemesterState
}
