package com.example.schedule.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.schedule.data.entity.Course
import com.example.schedule.data.entity.TodoTask
import com.example.schedule.ui.theme.courseColors
import com.example.schedule.viewmodel.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(vm: ScheduleViewModel, onAddCourse: (Int) -> Unit, onEditCourse: (Course) -> Unit) {
    val courses by vm.courseState.collectAsState()
    val week by vm.currentWeek.collectAsState()
    val semester by vm.semesterState.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("课程表") },
                actions = {
                    IconButton(onClick = { onAddCourse(1) }) {
                        Icon(Icons.Default.Add, "添加课程", tint = MaterialTheme.colorScheme.onPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primary, titleContentColor = MaterialTheme.colorScheme.onPrimary)
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { onAddCourse(1) },
                containerColor = MaterialTheme.colorScheme.primary
            ) { Icon(Icons.Default.Add, "添加课程", tint = MaterialTheme.colorScheme.onPrimary) }
        }
    ) { pad ->
        Column(Modifier.padding(pad)) {
            WeekSelector(week, vm::setWeek, semester)

            // 搜索栏
            val searchQuery by vm.searchQuery.collectAsState()
            val searchResult by vm.searchResult.collectAsState()
            var searchText by remember { mutableStateOf("") }
            SearchBar(searchText, { s ->
                searchText = s
                vm.setSearchQuery(s)
            }, { vm.setSearchQuery("") })

            // 待办事项区域
            var todoInput by remember { mutableStateOf("") }
            val todos by vm.todoTasks.collectAsState()
            TodoSection(todoInput, { todoInput = it }, { vm.addTodo(todoInput); todoInput = "" }, todos, vm::toggleTodo, vm::deleteTodo)

            // 课程列表：搜索模式显示搜索结果，否则显示周课程
            if (searchQuery.isNotBlank()) {
                if (searchResult.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("未找到匹配课程", color = MaterialTheme.colorScheme.outline)
                    }
                } else {
                    LazyColumn(modifier = Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(searchResult.groupBy { it.dayOfWeek }.toList().sortedBy { it.first }) { (day, list) ->
                            DaySection(day, list, onEditCourse, vm::deleteCourse)
                        }
                        item { Spacer(Modifier.height(80.dp)) }
                    }
                }
            } else {
                when (val state = courses) {
                    is CourseListState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                    is CourseListState.Error -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(state.msg, color = MaterialTheme.colorScheme.error) }
                    is CourseListState.Success -> {
                        if (state.courses.isEmpty()) EmptyWeek(onAddCourse)
                        else LazyColumn(modifier = Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(state.courses.groupBy { it.dayOfWeek }.toList().sortedBy { it.first }) { (day, list) ->
                                DaySection(day, list, onEditCourse, vm::deleteCourse)
                            }
                            item { Spacer(Modifier.height(80.dp)) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WeekSelector(week: Int, onChange: (Int) -> Unit, semester: SemesterState) {
    Surface(Modifier.fillMaxWidth(), tonalElevation = 2.dp) {
        Column {
            Row(Modifier.padding(12.dp, 8.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { onChange(maxOf(1, week - 1)) }) { Icon(Icons.Default.KeyboardArrowLeft, "上一周") }
                Text("第 $week 周", fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 16.dp))
                IconButton(onClick = { onChange(week + 1) }) { Icon(Icons.Default.KeyboardArrowRight, "下一周") }
            }
            when (semester) {
                is SemesterState.Loading -> LinearProgressIndicator(Modifier.fillMaxWidth())
                is SemesterState.Error -> if (semester.msg.isNotBlank()) Text(semester.msg, fontSize = 11.sp, color = MaterialTheme.colorScheme.error, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                else -> {}
            }
        }
    }
}

@Composable
fun DaySection(day: Int, courses: List<Course>, onEdit: (Course) -> Unit, onDelete: (Course) -> Unit) {
    val dayNames = listOf("", "周一", "周二", "周三", "周四", "周五", "周六", "周日")
    Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(8.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
        Column(Modifier.padding(12.dp)) {
            Text(dayNames[day], fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Spacer(Modifier.height(6.dp))
            courses.forEach { course ->
                val idx = (course.dayOfWeek * 7 + course.startSlot) % courseColors.size
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).background(courseColors[idx].copy(alpha = 0.15f)).clickable { onEdit(course) }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.width(4.dp).height(36.dp).clip(RoundedCornerShape(2.dp)).background(courseColors[idx]))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(course.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${course.startSlot}-${course.endSlot}节  ${course.classroom}  ${course.teacher}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(0.6f))
                    }
                    IconButton(onClick = { onDelete(course) }, Modifier.size(32.dp)) { Icon(Icons.Default.Delete, "删除", Modifier.size(16.dp), tint = MaterialTheme.colorScheme.error) }
                }
                Spacer(Modifier.height(4.dp))
            }
        }
    }
}

@Composable
fun EmptyWeek(onAdd: (Int) -> Unit) {
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text("📅", fontSize = 48.sp)
        Text("本周暂无课程", fontSize = 16.sp, color = MaterialTheme.colorScheme.outline)
        Spacer(Modifier.height(16.dp))
        FilledTonalButton(onClick = { onAdd(1) }) { Text("添加课程") }
    }
}

@Composable
fun SearchBar(text: String, onTextChange: (String) -> Unit, onClear: () -> Unit) {
    OutlinedTextField(
        value = text,
        onValueChange = onTextChange,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
        placeholder = { Text("搜索课程或教师...", fontSize = 13.sp) },
        leadingIcon = { Icon(Icons.Default.Search, "搜索", Modifier.size(18.dp)) },
        trailingIcon = {
            if (text.isNotEmpty()) {
                IconButton(onClick = { onTextChange(""); onClear() }) {
                    Icon(Icons.Default.Close, "清除", Modifier.size(16.dp))
                }
            }
        },
        singleLine = true,
        textStyle = LocalTextStyle.current.copy(fontSize = 13.sp)
    )
}

@Composable
fun TodoSection(input: String, onInput: (String) -> Unit, onAdd: () -> Unit, todos: List<TodoTask>, onToggle: (TodoTask) -> Unit, onDelete: (TodoTask) -> Unit) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CheckCircle, null, Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(6.dp))
                Text("待办事项", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(value = input, onValueChange = onInput, modifier = Modifier.weight(1f).height(48.dp), placeholder = { Text("输入待办...", fontSize = 13.sp) }, singleLine = true, textStyle = LocalTextStyle.current.copy(fontSize = 13.sp))
                Spacer(Modifier.width(6.dp))
                IconButton(onClick = onAdd, Modifier.size(36.dp), enabled = input.isNotBlank()) { Icon(Icons.Default.Send, "添加", tint = MaterialTheme.colorScheme.primary) }
            }
            if (todos.isEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text("暂无待办", fontSize = 12.sp, color = MaterialTheme.colorScheme.outline)
            } else {
                todos.forEach { t ->
                    Spacer(Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = t.isDone, onCheckedChange = { onToggle(t) }, modifier = Modifier.size(24.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(t.content, fontSize = 13.sp, modifier = Modifier.weight(1f), color = if (t.isDone) MaterialTheme.colorScheme.outline else MaterialTheme.colorScheme.onSurface, textDecoration = if (t.isDone) TextDecoration.LineThrough else null)
                        IconButton(onClick = { onDelete(t) }, Modifier.size(24.dp)) { Icon(Icons.Default.Close, "删除", Modifier.size(14.dp), tint = MaterialTheme.colorScheme.error) }
                    }
                }
            }
        }
    }
}
