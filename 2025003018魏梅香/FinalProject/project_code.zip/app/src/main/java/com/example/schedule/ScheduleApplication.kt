package com.example.schedule

import android.app.Application

class ScheduleApplication : Application()
