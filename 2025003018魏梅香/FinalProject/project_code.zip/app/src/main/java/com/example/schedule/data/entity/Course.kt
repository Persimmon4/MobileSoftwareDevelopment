package com.example.schedule.data.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "courses")
data class Course(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,                          // 课程名称
    val teacher: String = "",                  // 教师
    val classroom: String = "",                // 教室
    @ColumnInfo(name = "day_of_week")
    val dayOfWeek: Int,                        // 星期几 1-7
    @ColumnInfo(name = "start_slot")
    val startSlot: Int,                        // 开始节次 1-12
    @ColumnInfo(name = "end_slot")
    val endSlot: Int,                          // 结束节次 1-12
    val color: String = "#409EFF",            // 课程颜色
    @ColumnInfo(name = "week_start")
    val weekStart: Int = 1,                    // 起始周
    @ColumnInfo(name = "week_end")
    val weekEnd: Int = 16,                     // 结束周
    val notes: String = ""                     // 备注
)
