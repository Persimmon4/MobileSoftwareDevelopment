package com.example.schedule.navigation

import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.example.schedule.ui.screens.*
import com.example.schedule.viewmodel.ScheduleViewModel

object Routes {
    const val HOME = "home"
    const val EDIT = "edit/{id}"
    fun edit(id: Long = -1) = "edit/$id"
}

@Composable
fun AppNavigation(navController: NavHostController, vm: ScheduleViewModel = viewModel()) {
    NavHost(navController, Routes.HOME) {
        composable(Routes.HOME) {
            HomeScreen(vm = vm,
                onAddCourse = { day -> vm.startNewCourse(day); navController.navigate(Routes.edit()) },
                onEditCourse = { c -> vm.startEdit(c); navController.navigate(Routes.edit(c.id)) })
        }
        composable(Routes.EDIT, arguments = listOf(navArgument("id") { type = NavType.LongType; defaultValue = -1L })) {
            EditCourseScreen(vm = vm, onBack = { navController.popBackStack() })
        }
    }
}
