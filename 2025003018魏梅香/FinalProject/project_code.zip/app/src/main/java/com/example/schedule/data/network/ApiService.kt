package com.example.schedule.data.network

import retrofit2.http.GET

data class SemesterInfo(
    val semester: String,
    val startDate: String,
    val totalWeeks: Int,
    val currentWeek: Int
)

interface ApiService {
    @GET("semester/info")
    suspend fun getSemesterInfo(): List<SemesterInfo>
}
