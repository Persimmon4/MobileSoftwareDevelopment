package com.example.schedule.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.schedule.ui.theme.courseColors
import com.example.schedule.viewmodel.ScheduleViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditCourseScreen(vm: ScheduleViewModel, onBack: () -> Unit) {
    val form by vm.formState.collectAsState()
    LaunchedEffect(form.saved) { if (form.saved) onBack() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (form.isEdit) "编辑课程" else "添加课程") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "返回") } },
                actions = { IconButton(onClick = { vm.saveCourse() }) { Icon(Icons.Default.Check, "保存") } }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            OutlinedTextField(form.name, { newVal -> vm.updateForm { it.copy(name = newVal, nameError = null) } }, label = { Text("课程名称") }, isError = form.nameError != null, supportingText = form.nameError?.let { { Text(it) } }, singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(10.dp))
            OutlinedTextField(form.teacher, { newVal -> vm.updateForm { it.copy(teacher = newVal) } }, label = { Text("教师") }, singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(10.dp))
            OutlinedTextField(form.classroom, { newVal -> vm.updateForm { it.copy(classroom = newVal) } }, label = { Text("教室") }, singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(10.dp))

            // 星期
            Text("星期", style = MaterialTheme.typography.labelLarge)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                listOf("一","二","三","四","五","六","日").forEachIndexed { i, d ->
                    FilterChip(
                        selected = form.dayOfWeek == i + 1,
                        onClick = { vm.updateForm { it.copy(dayOfWeek = i + 1) } },
                        label = { Text("周$d", fontSize = 12.sp) },
                        modifier = Modifier.weight(1f).padding(horizontal = 2.dp)
                    )
                }
            }

            // 节次
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Column(Modifier.weight(1f)) {
                    Text("开始节次", style = MaterialTheme.typography.labelSmall)
                    Spacer(Modifier.height(4.dp))
                    var expanded by remember { mutableStateOf(false) }
                    ExposedDropdownMenuBox(expanded, { expanded = it }) {
                        OutlinedTextField((1..12).first { it == form.startSlot }.toString(), {}, readOnly = true, modifier = Modifier.menuAnchor(), trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) })
                        ExposedDropdownMenu(expanded, { expanded = false }) {
                            (1..12).forEach { s -> DropdownMenuItem(text = { Text("第$s 节") }, onClick = { vm.updateForm { it.copy(startSlot = s, endSlot = maxOf(it.endSlot, s)) }; expanded = false }) }
                        }
                    }
                }
                Column(Modifier.weight(1f)) {
                    Text("结束节次", style = MaterialTheme.typography.labelSmall)
                    Spacer(Modifier.height(4.dp))
                    var expanded by remember { mutableStateOf(false) }
                    ExposedDropdownMenuBox(expanded, { expanded = it }) {
                        OutlinedTextField((form.startSlot..12).first { it == form.endSlot }.toString(), {}, readOnly = true, modifier = Modifier.menuAnchor(), trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) })
                        ExposedDropdownMenu(expanded, { expanded = false }) {
                            (form.startSlot..12).forEach { s -> DropdownMenuItem(text = { Text("第$s 节") }, onClick = { vm.updateForm { it.copy(endSlot = s) }; expanded = false }) }
                        }
                    }
                }
            }

            // 周范围
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Column(Modifier.weight(1f)) {
                    Text("起始周", style = MaterialTheme.typography.labelSmall)
                    Spacer(Modifier.height(4.dp))
                    var expanded by remember { mutableStateOf(false) }
                    ExposedDropdownMenuBox(expanded, { expanded = it }) {
                        OutlinedTextField(form.weekStart.toString(), {}, readOnly = true, modifier = Modifier.menuAnchor(), trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) })
                        ExposedDropdownMenu(expanded, { expanded = false }) {
                            (1..20).forEach { w -> DropdownMenuItem(text = { Text("第$w 周") }, onClick = { vm.updateForm { it.copy(weekStart = w, weekEnd = maxOf(it.weekEnd, w)) }; expanded = false }) }
                        }
                    }
                }
                Column(Modifier.weight(1f)) {
                    Text("结束周", style = MaterialTheme.typography.labelSmall)
                    Spacer(Modifier.height(4.dp))
                    var expanded by remember { mutableStateOf(false) }
                    ExposedDropdownMenuBox(expanded, { expanded = it }) {
                        OutlinedTextField(form.weekEnd.toString(), {}, readOnly = true, modifier = Modifier.menuAnchor(), trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) })
                        ExposedDropdownMenu(expanded, { expanded = false }) {
                            (form.weekStart..20).forEach { w -> DropdownMenuItem(text = { Text("第$w 周") }, onClick = { vm.updateForm { it.copy(weekEnd = w) }; expanded = false }) }
                        }
                    }
                }
            }

            // 颜色
            Text("课程颜色", style = MaterialTheme.typography.labelLarge)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                courseColors.forEachIndexed { i, c ->
                    val hex = String.format("#%06X", 0xFFFFFF and c.hashCode())
                    FilterChip(selected = form.color == hex, onClick = { vm.updateForm { it.copy(color = hex) } }, colors = FilterChipDefaults.filterChipColors(selectedContainerColor = c), label = { Text("") })
                }
            }

            OutlinedTextField(form.notes, { newVal -> vm.updateForm { it.copy(notes = newVal) } }, label = { Text("备注") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(10.dp))

            Spacer(Modifier.height(8.dp))
            Button(onClick = { vm.saveCourse() }, Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(10.dp)) { Text("保存课程") }
        }
    }
}
