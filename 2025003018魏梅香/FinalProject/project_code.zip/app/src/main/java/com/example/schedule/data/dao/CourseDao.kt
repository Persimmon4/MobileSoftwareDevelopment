package com.example.schedule.data.dao

import androidx.room.*
import com.example.schedule.data.entity.Course
import kotlinx.coroutines.flow.Flow

@Dao
interface CourseDao {
    @Query("SELECT * FROM courses ORDER BY day_of_week, start_slot")
    fun getAllCourses(): Flow<List<Course>>

    @Query("SELECT * FROM courses WHERE day_of_week = :day ORDER BY start_slot")
    fun getCoursesByDay(day: Int): Flow<List<Course>>

    @Query("SELECT * FROM courses WHERE :currentWeek BETWEEN week_start AND week_end ORDER BY day_of_week, start_slot")
    fun getCoursesForWeek(currentWeek: Int): Flow<List<Course>>

    @Query("SELECT * FROM courses WHERE name LIKE '%' || :query || '%' OR teacher LIKE '%' || :query || '%'")
    fun searchCourses(query: String): Flow<List<Course>>

    @Query("SELECT COUNT(*) FROM courses")
    fun getCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(course: Course): Long

    @Update
    suspend fun update(course: Course)

    @Delete
    suspend fun delete(course: Course)
}
