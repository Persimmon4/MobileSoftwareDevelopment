package com.example.schedule.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(primary = Primary, onPrimary = OnPrimary, secondary = Secondary, background = Background, surface = Surface, surfaceVariant = SurfaceVariant, onSurface = OnSurface, outline = Outline)
private val DarkColors = darkColorScheme(primary = PrimaryDark, onPrimary = Color(0xFF0D47A1), secondary = Secondary, background = BackgroundDark, surface = SurfaceDark)

@Composable
fun ScheduleTheme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors, content = content)
}
