package com.example.schedule.ui.theme

import androidx.compose.ui.graphics.Color

val Primary = Color(0xFF1565C0)
val OnPrimary = Color.White
val Secondary = Color(0xFF42A5F5)
val Surface = Color(0xFFF5F7FA)
val SurfaceVariant = Color(0xFFE3F2FD)
val Background = Color(0xFFFFFFFF)
val OnSurface = Color(0xFF212121)
val Outline = Color(0xFFBDBDBD)

// 深色
val PrimaryDark = Color(0xFF90CAF9)
val SurfaceDark = Color(0xFF1E1E1E)
val BackgroundDark = Color(0xFF121212)

// 课程颜色
val courseColors = listOf(
    Color(0xFF42A5F5), Color(0xFFEF5350), Color(0xFF66BB6A),
    Color(0xFFFFA726), Color(0xFFAB47BC), Color(0xFF26C6DA),
    Color(0xFFEC407A), Color(0xFF8D6E63)
)
