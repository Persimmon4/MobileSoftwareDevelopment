package com.example.schedule.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.schedule.data.dao.CourseDao
import com.example.schedule.data.dao.TodoDao
import com.example.schedule.data.entity.Course
import com.example.schedule.data.entity.TodoTask

@Database(entities = [Course::class, TodoTask::class], version = 1, exportSchema = false)
abstract class ScheduleDatabase : RoomDatabase() {
    abstract fun courseDao(): CourseDao
    abstract fun todoDao(): TodoDao

    companion object {
        @Volatile private var INSTANCE: ScheduleDatabase? = null
        fun getDatabase(ctx: Context) = INSTANCE ?: synchronized(this) {
            Room.databaseBuilder(ctx.applicationContext, ScheduleDatabase::class.java, "schedule_db").build().also { INSTANCE = it }
        }
    }
}
