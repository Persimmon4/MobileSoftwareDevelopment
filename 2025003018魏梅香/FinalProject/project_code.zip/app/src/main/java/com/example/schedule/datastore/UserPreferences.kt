package com.example.schedule.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "schedule_prefs")

class UserPreferences(private val context: Context) {
    companion object {
        val KEY_CURRENT_WEEK = intPreferencesKey("current_week")
    }

    val currentWeek: Flow<Int> = context.dataStore.data.map { it[KEY_CURRENT_WEEK] ?: 1 }

    suspend fun setCurrentWeek(week: Int) {
        context.dataStore.edit { it[KEY_CURRENT_WEEK] = week }
    }
}
