package com.example.schedule.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.schedule.data.database.ScheduleDatabase
import com.example.schedule.data.entity.Course
import com.example.schedule.data.network.RetrofitClient
import com.example.schedule.data.repository.ScheduleRepository
import com.example.schedule.datastore.UserPreferences
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class ScheduleViewModel(app: Application) : AndroidViewModel(app) {
    private val db = ScheduleDatabase.getDatabase(app)
    private val repo = ScheduleRepository(db.courseDao(), db.todoDao())
    private val prefs = UserPreferences(app)

    // 课程列表（按周筛选）
    private val _currentWeek = MutableStateFlow(1)
    @OptIn(ExperimentalCoroutinesApi::class)
    val courseState: StateFlow<CourseListState> = _currentWeek
        .flatMapLatest { repo.getCoursesForWeek(it) }
        .map { CourseListState.Success(it) as CourseListState }
        .catch { emit(CourseListState.Error(it.message ?: "加载失败")) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), CourseListState.Loading)

    val currentWeek: StateFlow<Int> = _currentWeek.asStateFlow()

    // 学期信息（网络）
    private val _semesterState = MutableStateFlow<SemesterState>(SemesterState.Loading)
    val semesterState: StateFlow<SemesterState> = _semesterState.asStateFlow()

    // 表单
    private val _form = MutableStateFlow(CourseFormState())
    val formState: StateFlow<CourseFormState> = _form.asStateFlow()

    // 当前星期
    val prefWeek: StateFlow<Int> = prefs.currentWeek.stateIn(viewModelScope, SharingStarted.Eagerly, 1)

    init {
        viewModelScope.launch { _currentWeek.value = prefs.currentWeek.first() }
        fetchSemester()
    }

    fun setWeek(week: Int) {
        viewModelScope.launch { prefs.setCurrentWeek(week); _currentWeek.value = week }
    }

    fun fetchSemester() {
        viewModelScope.launch {
            _semesterState.value = SemesterState.Loading
            try {
                val info = RetrofitClient.api.getSemesterInfo()
                if (info.isNotEmpty()) {
                    _semesterState.value = SemesterState.Success(info[0].currentWeek)
                    _currentWeek.value = info[0].currentWeek
                } else {
                    _semesterState.value = SemesterState.Error("暂无数据")
                }
            } catch (e: Exception) {
                _semesterState.value = SemesterState.Error("")
            }
        }
    }

    fun updateForm(f: (CourseFormState) -> CourseFormState) { _form.update(f) }
    fun startNewCourse(day: Int = 1) { _form.value = CourseFormState(dayOfWeek = day) }
    fun startEdit(c: Course) {
        _form.value = CourseFormState(c.name, c.teacher, c.classroom, c.dayOfWeek,
            c.startSlot, c.endSlot, c.weekStart, c.weekEnd, c.color, c.notes, true, c.id)
    }

    fun saveCourse() {
        val f = _form.value
        if (f.name.isBlank()) { _form.update { it.copy(nameError = "课程名不能为空") }; return }
        viewModelScope.launch {
            val c = Course(f.editId ?: 0, f.name.trim(), f.teacher.trim(), f.classroom.trim(),
                f.dayOfWeek, f.startSlot, f.endSlot, f.color, f.weekStart, f.weekEnd, f.notes.trim())
            if (f.isEdit) repo.updateCourse(c) else repo.insertCourse(c)
            _form.update { it.copy(saved = true) }
        }
    }

    fun deleteCourse(c: Course) { viewModelScope.launch { repo.deleteCourse(c) } }

    // ========== 课程搜索 ==========
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _searchResult = MutableStateFlow<List<Course>>(emptyList())
    val searchResult: StateFlow<List<Course>> = _searchResult.asStateFlow()

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
        if (query.isBlank()) {
            _searchResult.value = emptyList()
        } else {
            viewModelScope.launch {
                repo.searchCourses(query).first().let { _searchResult.value = it }
            }
        }
    }

    // ========== 待办事项 ==========
    val todoTasks: StateFlow<List<com.example.schedule.data.entity.TodoTask>> = repo.getAllTasks()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addTodo(content: String) {
        if (content.isBlank()) return
        viewModelScope.launch { repo.insertTask(com.example.schedule.data.entity.TodoTask(content = content.trim())) }
    }

    fun toggleTodo(t: com.example.schedule.data.entity.TodoTask) {
        viewModelScope.launch { repo.updateTask(t.copy(isDone = !t.isDone)) }
    }

    fun deleteTodo(t: com.example.schedule.data.entity.TodoTask) {
        viewModelScope.launch { repo.deleteTask(t) }
    }
}
