# 课程表 (Schedule App)

Android 移动端软件开发期末大作业

## 技术栈
- Kotlin + Jetpack Compose + Material 3
- Room (Course + TodoTask 双表)
- DataStore (当前周偏好)
- ViewModel + StateFlow
- Navigation Compose
- Retrofit + OkHttp (学期信息 API)
- Kotlin Coroutines

## 功能
- 📅 课程表周视图，按周筛选
- ➕ 添加/编辑/删除课程（名称、教师、教室、节次、周范围、颜色）
- 📋 待办事项管理（添加、勾选完成、删除）
- 🌐 网络获取学期信息
- 💾 DataStore 保存当前周

## 运行
Android Studio 打开 → Sync → Run | minSdk 24
