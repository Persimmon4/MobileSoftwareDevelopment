package com.example.studyplanner.model

data class RecommendedTask(
    val id: Int,
    val title: String,
    val description: String,
    val priority: Int,
)
