package com.example.studyplanner.data.repository

import android.content.Context
import com.example.studyplanner.data.database.StudyPlannerDatabase
import com.example.studyplanner.data.network.ApiConfig
import com.example.studyplanner.data.network.StudyPlannerApiService
import com.example.studyplanner.datastore.UserPreferencesRepository
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class AppContainer(context: Context) {
    private val database = StudyPlannerDatabase.getDatabase(context)

    val userPreferencesRepository = UserPreferencesRepository(context)

    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BASIC
    }

    private val okHttpClient = OkHttpClient.Builder()
        .addInterceptor(loggingInterceptor)
        .build()

    private val retrofit = Retrofit.Builder()
        .baseUrl(ApiConfig.BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    private val apiService: StudyPlannerApiService by lazy {
        retrofit.create(StudyPlannerApiService::class.java)
    }

    val studyPlannerRepository: StudyPlannerRepository by lazy {
        StudyPlannerRepository(
            courseDao = database.courseDao(),
            taskDao = database.taskDao(),
            apiService = apiService,
        )
    }
}
