package com.example.studyplanner.data.repository

import com.example.studyplanner.data.dao.CourseDao
import com.example.studyplanner.data.dao.TaskDao
import com.example.studyplanner.data.entity.CourseEntity
import com.example.studyplanner.data.entity.TaskEntity
import com.example.studyplanner.data.network.StudyPlannerApiService
import com.example.studyplanner.data.network.dto.asRecommendedTask
import com.example.studyplanner.model.RecommendedTask
import com.example.studyplanner.model.TaskWithCourse
import kotlinx.coroutines.flow.Flow

class StudyPlannerRepository(
    private val courseDao: CourseDao,
    private val taskDao: TaskDao,
    private val apiService: StudyPlannerApiService,
) {
    fun getAllCourses(): Flow<List<CourseEntity>> = courseDao.getAllCourses()

    fun getTaskItems(
        query: String,
        showCompleted: Boolean,
        sortMode: String,
    ): Flow<List<TaskWithCourse>> {
        return taskDao.getTaskItems(
            query = query,
            showCompleted = showCompleted,
            sortMode = sortMode,
        )
    }

    fun getTask(taskId: Int): Flow<TaskWithCourse?> = taskDao.getTaskItem(taskId)

    fun getTasksByCourse(courseId: Int): Flow<List<TaskWithCourse>> {
        return taskDao.getTasksByCourse(courseId)
    }

    suspend fun insertCourse(course: CourseEntity): Long = courseDao.insert(course)

    suspend fun deleteCourse(course: CourseEntity) = courseDao.delete(course)

    suspend fun insertTask(task: TaskEntity): Long = taskDao.insert(task)

    suspend fun updateTask(task: TaskEntity) = taskDao.update(task)

    suspend fun deleteTask(taskId: Int) = taskDao.deleteById(taskId)

    suspend fun setTaskDone(taskId: Int, done: Boolean) = taskDao.setDone(taskId, done)

    suspend fun getTaskEntity(taskId: Int): TaskEntity? = taskDao.getTaskEntity(taskId)

    suspend fun loadRecommendedTasks(): List<RecommendedTask> {
        return apiService.getRecommendedTodos(limit = 12).map { it.asRecommendedTask() }
    }

    suspend fun ensureSeedData() {
        if (courseDao.countCourses() > 0) return

        val androidCourseId = courseDao.insert(
            CourseEntity(
                name = "移动端软件开发",
                teacher = "刘老师",
                classroom = "A101",
                colorHex = "#6750A4",
            )
        ).toInt()
        val englishCourseId = courseDao.insert(
            CourseEntity(
                name = "考研英语",
                teacher = "自学计划",
                classroom = "图书馆",
                colorHex = "#006C4C",
            )
        ).toInt()
        val aiCourseId = courseDao.insert(
            CourseEntity(
                name = "人工智能引论",
                teacher = "课程复习",
                classroom = "B202",
                colorHex = "#9A3412",
            )
        ).toInt()

        if (taskDao.countTasks() == 0) {
            taskDao.insert(
                TaskEntity(
                    courseId = androidCourseId,
                    title = "完成期末项目报告",
                    description = "补充技术栈、Room、DataStore、网络请求和运行截图说明。",
                    deadline = "2026-07-03",
                    priority = 3,
                )
            )
            taskDao.insert(
                TaskEntity(
                    courseId = androidCourseId,
                    title = "检查网络推荐任务功能",
                    description = "确认 Retrofit 请求可以加载在线任务，并能一键加入本地数据库。",
                    deadline = "2026-06-30",
                    priority = 2,
                )
            )
            taskDao.insert(
                TaskEntity(
                    courseId = englishCourseId,
                    title = "精读一篇英语阅读",
                    description = "标记长难句和高频词，整理错题原因。",
                    deadline = "2026-07-01",
                    priority = 2,
                )
            )
            taskDao.insert(
                TaskEntity(
                    courseId = aiCourseId,
                    title = "复习搜索算法和专家系统",
                    description = "整理人工智能引论前五章核心概念。",
                    deadline = "2026-07-02",
                    priority = 1,
                )
            )
        }
    }
}
