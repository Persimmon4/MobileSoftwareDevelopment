package com.example.studyplanner

import android.app.Application
import com.example.studyplanner.data.repository.AppContainer

class StudyPlannerApplication : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
