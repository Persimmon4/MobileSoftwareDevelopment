package com.example.studyplanner.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.studyplanner.data.entity.CourseEntity
import com.example.studyplanner.model.RecommendedTask
import com.example.studyplanner.viewmodel.RecommendedUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecommendedScreen(
    uiState: RecommendedUiState,
    courses: List<CourseEntity>,
    onRefresh: () -> Unit,
    onAddRecommendedTask: (RecommendedTask, Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    var selectedCourseId by remember(courses) { mutableIntStateOf(courses.firstOrNull()?.id ?: 0) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("在线推荐任务") }) },
        modifier = modifier,
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                text = "这里会加载一些在线学习任务模板，可以选择课程后加入自己的任务列表。",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            CoursePicker(
                selectedCourseId = selectedCourseId,
                courses = courses,
                onCourseSelected = { selectedCourseId = it },
            )
            when (uiState) {
                RecommendedUiState.Loading -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
                is RecommendedUiState.Error -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(uiState.message)
                            Button(onClick = onRefresh, modifier = Modifier.padding(top = 12.dp)) {
                                Text("重试")
                            }
                        }
                    }
                }
                is RecommendedUiState.Success -> {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text("已加载 ${uiState.tasks.size} 条在线任务")
                        Button(onClick = onRefresh) { Text("刷新") }
                    }
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        contentPadding = PaddingValues(bottom = 24.dp),
                    ) {
                        items(uiState.tasks, key = { it.id }) { task ->
                            RecommendedTaskCard(
                                task = task,
                                onAdd = { onAddRecommendedTask(task, selectedCourseId) },
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RecommendedTaskCard(
    task: RecommendedTask,
    onAdd: () -> Unit,
) {
    Card {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(task.title, fontWeight = FontWeight.Bold)
            Text(task.description, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("优先级：${"★".repeat(task.priority)}")
                Button(onClick = onAdd) {
                    Text("加入任务")
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CoursePicker(
    selectedCourseId: Int,
    courses: List<CourseEntity>,
    onCourseSelected: (Int) -> Unit,
) {
    var expanded by remember { mutableStateOf(false) }
    val selectedName = courses.firstOrNull { it.id == selectedCourseId }?.name ?: "暂无课程"
    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = !expanded },
    ) {
        OutlinedTextField(
            value = selectedName,
            onValueChange = {},
            readOnly = true,
            label = { Text("加入到课程") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier
                .menuAnchor()
                .fillMaxWidth(),
        )
        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
        ) {
            courses.forEach { course ->
                DropdownMenuItem(
                    text = { Text(course.name) },
                    onClick = {
                        onCourseSelected(course.id)
                        expanded = false
                    },
                )
            }
        }
    }
}
