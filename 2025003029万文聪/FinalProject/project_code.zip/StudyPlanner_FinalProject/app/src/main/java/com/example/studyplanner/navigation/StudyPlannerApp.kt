package com.example.studyplanner.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.studyplanner.datastore.UserPreferences
import com.example.studyplanner.ui.screens.CourseDetailScreen
import com.example.studyplanner.ui.screens.CoursesScreen
import com.example.studyplanner.ui.screens.EditTaskScreen
import com.example.studyplanner.ui.screens.HomeScreen
import com.example.studyplanner.ui.screens.RecommendedScreen
import com.example.studyplanner.ui.screens.SettingsScreen
import com.example.studyplanner.ui.screens.TaskDetailScreen
import com.example.studyplanner.viewmodel.CoursesUiState
import com.example.studyplanner.viewmodel.HomeUiState
import com.example.studyplanner.viewmodel.StudyPlannerViewModel

private sealed class MainDestination(
    val route: String,
    val title: String,
    val icon: @Composable () -> Unit,
) {
    data object Home : MainDestination("home", "首页", { Icon(Icons.Default.Home, contentDescription = null) })
    data object Courses : MainDestination("courses", "课程", { Icon(Icons.Default.Book, contentDescription = null) })
    data object Recommended : MainDestination("recommended", "推荐", { Icon(Icons.Default.Lightbulb, contentDescription = null) })
    data object Settings : MainDestination("settings", "设置", { Icon(Icons.Default.Settings, contentDescription = null) })
}

@Composable
fun StudyPlannerApp(
    modifier: Modifier = Modifier,
) {
    val navController = rememberNavController()
    val viewModel: StudyPlannerViewModel = viewModel(factory = StudyPlannerViewModel.Factory)
    val snackbarHostState = remember { SnackbarHostState() }
    val snackbarMessage by viewModel.snackbarMessage.collectAsState()
    val homeUiState by viewModel.homeUiState.collectAsState()
    val coursesUiState by viewModel.coursesUiState.collectAsState()
    val recommendedUiState by viewModel.recommendedUiState.collectAsState()
    val editTaskUiState by viewModel.editTaskUiState.collectAsState()

    LaunchedEffect(snackbarMessage) {
        snackbarMessage?.let { message ->
            snackbarHostState.showSnackbar(message)
            viewModel.clearMessage()
        }
    }

    val mainDestinations = listOf(
        MainDestination.Home,
        MainDestination.Courses,
        MainDestination.Recommended,
        MainDestination.Settings,
    )
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route
    val showBottomBar = currentRoute in mainDestinations.map { it.route }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            if (showBottomBar) {
                NavigationBar {
                    mainDestinations.forEach { destination ->
                        NavigationBarItem(
                            selected = currentRoute == destination.route,
                            onClick = {
                                navController.navigate(destination.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = destination.icon,
                            label = { Text(destination.title) },
                        )
                    }
                }
            }
        },
        modifier = modifier,
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = MainDestination.Home.route,
            modifier = Modifier.padding(innerPadding),
        ) {
            composable(MainDestination.Home.route) {
                HomeScreen(
                    uiState = homeUiState,
                    onSearchChange = viewModel::updateSearchQuery,
                    onShowCompletedChange = viewModel::updateShowCompleted,
                    onSortModeChange = viewModel::updateSortMode,
                    onAddTask = { navController.navigate("edit") },
                    onTaskClick = { taskId -> navController.navigate("detail/$taskId") },
                    onTaskChecked = viewModel::setTaskDone,
                    onTaskEdit = { taskId -> navController.navigate("edit?taskId=$taskId") },
                    onTaskDelete = viewModel::deleteTask,
                )
            }
            composable(MainDestination.Courses.route) {
                CoursesScreen(
                    uiState = coursesUiState,
                    onAddCourse = viewModel::addCourse,
                    onDeleteCourse = viewModel::deleteCourse,
                    onCourseClick = { courseId -> navController.navigate("course/$courseId") },
                )
            }
            composable(MainDestination.Recommended.route) {
                RecommendedScreen(
                    uiState = recommendedUiState,
                    courses = coursesUiState.courseList(),
                    onRefresh = viewModel::loadRecommendedTasks,
                    onAddRecommendedTask = viewModel::addRecommendedTask,
                )
            }
            composable(MainDestination.Settings.route) {
                SettingsScreen(
                    preferences = homeUiState.preferencesOrDefault(),
                    onShowCompletedChange = viewModel::updateShowCompleted,
                    onDarkThemeChange = viewModel::updateDarkTheme,
                )
            }
            composable(
                route = "edit?taskId={taskId}",
                arguments = listOf(
                    navArgument("taskId") {
                        type = NavType.StringType
                        nullable = true
                        defaultValue = null
                    }
                ),
            ) { backStackEntry ->
                val taskId = backStackEntry.arguments?.getString("taskId")?.toIntOrNull()
                LaunchedEffect(taskId) {
                    if (taskId == null) {
                        val defaultCourseId = coursesUiState.courseList().firstOrNull()?.id ?: 0
                        viewModel.startAddTask(defaultCourseId = defaultCourseId)
                    } else {
                        viewModel.startEditTask(taskId)
                    }
                }
                EditTaskScreen(
                    editTaskUiState = editTaskUiState,
                    courses = coursesUiState.courseList(),
                    onBack = { navController.popBackStack() },
                    onTitleChange = viewModel::updateEditTitle,
                    onDescriptionChange = viewModel::updateEditDescription,
                    onDeadlineChange = viewModel::updateEditDeadline,
                    onPriorityChange = viewModel::updateEditPriority,
                    onCourseChange = viewModel::updateEditCourse,
                    onSave = {
                        viewModel.saveTask {
                            navController.popBackStack()
                        }
                    },
                )
            }
            composable(
                route = "detail/{taskId}",
                arguments = listOf(navArgument("taskId") { type = NavType.IntType }),
            ) { backStackEntry ->
                val taskId = backStackEntry.arguments?.getInt("taskId") ?: 0
                val task by viewModel.getTaskDetail(taskId).collectAsState(initial = null)
                TaskDetailScreen(
                    task = task,
                    onBack = { navController.popBackStack() },
                )
            }
            composable(
                route = "course/{courseId}",
                arguments = listOf(navArgument("courseId") { type = NavType.IntType }),
            ) { backStackEntry ->
                val courseId = backStackEntry.arguments?.getInt("courseId") ?: 0
                val tasks by viewModel.getTasksByCourse(courseId).collectAsState(initial = emptyList())
                CourseDetailScreen(
                    tasks = tasks,
                    onBack = { navController.popBackStack() },
                    onTaskClick = { taskId -> navController.navigate("detail/$taskId") },
                    onTaskChecked = viewModel::setTaskDone,
                    onTaskEdit = { taskId -> navController.navigate("edit?taskId=$taskId") },
                    onTaskDelete = viewModel::deleteTask,
                )
            }
        }
    }
}

private fun CoursesUiState.courseList() = when (this) {
    CoursesUiState.Loading -> emptyList()
    is CoursesUiState.Success -> courses
}

private fun HomeUiState.preferencesOrDefault() = when (this) {
    HomeUiState.Loading -> UserPreferences()
    is HomeUiState.Error -> UserPreferences()
    is HomeUiState.Success -> preferences
}
