package com.example.studyplanner.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.studyplanner.data.dao.CourseDao
import com.example.studyplanner.data.dao.TaskDao
import com.example.studyplanner.data.entity.CourseEntity
import com.example.studyplanner.data.entity.TaskEntity

@Database(
    entities = [CourseEntity::class, TaskEntity::class],
    version = 1,
    exportSchema = false
)
abstract class StudyPlannerDatabase : RoomDatabase() {
    abstract fun courseDao(): CourseDao
    abstract fun taskDao(): TaskDao

    companion object {
        @Volatile
        private var Instance: StudyPlannerDatabase? = null

        fun getDatabase(context: Context): StudyPlannerDatabase {
            return Instance ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    StudyPlannerDatabase::class.java,
                    "study_planner_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { Instance = it }
            }
        }
    }
}
