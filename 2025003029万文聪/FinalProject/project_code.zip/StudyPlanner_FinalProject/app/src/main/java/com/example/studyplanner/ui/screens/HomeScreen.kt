package com.example.studyplanner.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.studyplanner.model.TaskWithCourse
import com.example.studyplanner.ui.components.TaskCard
import com.example.studyplanner.viewmodel.HomeUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    uiState: HomeUiState,
    onSearchChange: (String) -> Unit,
    onShowCompletedChange: (Boolean) -> Unit,
    onSortModeChange: (String) -> Unit,
    onAddTask: () -> Unit,
    onTaskClick: (Int) -> Unit,
    onTaskChecked: (Int, Boolean) -> Unit,
    onTaskEdit: (Int) -> Unit,
    onTaskDelete: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("学习计划助手") }) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onAddTask,
                icon = { Icon(Icons.Default.Add, contentDescription = "新增") },
                text = { Text("新增任务") },
            )
        },
        modifier = modifier,
    ) { innerPadding ->
        when (uiState) {
            HomeUiState.Loading -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding),
                    contentAlignment = Alignment.Center,
                ) {
                    CircularProgressIndicator()
                }
            }
            is HomeUiState.Error -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(uiState.message)
                }
            }
            is HomeUiState.Success -> {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    OutlinedTextField(
                        value = uiState.searchQuery,
                        onValueChange = onSearchChange,
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("搜索任务或课程") },
                        singleLine = true,
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("显示已完成")
                            Switch(
                                checked = uiState.preferences.showCompleted,
                                onCheckedChange = onShowCompletedChange,
                            )
                        }
                        SortDropdown(
                            sortMode = uiState.preferences.sortMode,
                            onSortModeChange = onSortModeChange,
                        )
                    }
                    ProgressSummaryCard(tasks = uiState.tasks)
                    if (uiState.tasks.isEmpty()) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center,
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "暂无任务",
                                    style = MaterialTheme.typography.titleMedium,
                                )
                                Button(onClick = onAddTask, modifier = Modifier.padding(top = 12.dp)) {
                                    Text("添加第一个任务")
                                }
                            }
                        }
                    } else {
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            contentPadding = PaddingValues(bottom = 96.dp),
                        ) {
                            items(uiState.tasks, key = { it.id }) { task ->
                                TaskCard(
                                    task = task,
                                    onClick = { onTaskClick(task.id) },
                                    onCheckedChange = { onTaskChecked(task.id, it) },
                                    onEdit = { onTaskEdit(task.id) },
                                    onDelete = { onTaskDelete(task.id) },
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}


@Composable
private fun ProgressSummaryCard(tasks: List<TaskWithCourse>) {
    val total = tasks.size
    val done = tasks.count { it.isDone }
    val pending = total - done
    val highPriority = tasks.count { it.priority == 3 && !it.isDone }
    val progress = if (total == 0) 0f else done.toFloat() / total.toFloat()

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text("学习进度", style = MaterialTheme.typography.titleMedium)
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth(),
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                SummaryText(label = "全部", value = total)
                SummaryText(label = "待完成", value = pending)
                SummaryText(label = "已完成", value = done)
                SummaryText(label = "高优先级", value = highPriority)
            }
        }
    }
}

@Composable
private fun SummaryText(label: String, value: Int) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value.toString(),
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.primary,
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SortDropdown(
    sortMode: String,
    onSortModeChange: (String) -> Unit,
) {
    var expanded by remember { mutableStateOf(false) }
    val label = when (sortMode) {
        "priority" -> "按优先级"
        else -> "按截止时间"
    }
    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = !expanded },
    ) {
        OutlinedTextField(
            value = label,
            onValueChange = {},
            readOnly = true,
            label = { Text("排序") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier.menuAnchor(),
        )
        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
        ) {
            DropdownMenuItem(
                text = { Text("按截止时间") },
                onClick = {
                    onSortModeChange("deadline")
                    expanded = false
                },
            )
            DropdownMenuItem(
                text = { Text("按优先级") },
                onClick = {
                    onSortModeChange("priority")
                    expanded = false
                },
            )
        }
    }
}
