package com.example.studyplanner.ui.theme

import androidx.compose.ui.graphics.Color

val PlannerPurple = Color(0xFF6750A4)
val PlannerPurpleLight = Color(0xFFEADDFF)
val PlannerGreen = Color(0xFF006C4C)
val PlannerOrange = Color(0xFF9A3412)
val PlannerSurface = Color(0xFFFFFBFE)
val PlannerDarkSurface = Color(0xFF141218)
