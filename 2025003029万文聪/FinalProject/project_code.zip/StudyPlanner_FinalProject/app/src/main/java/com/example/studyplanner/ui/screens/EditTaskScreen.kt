package com.example.studyplanner.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.studyplanner.data.entity.CourseEntity
import com.example.studyplanner.viewmodel.EditTaskUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditTaskScreen(
    editTaskUiState: EditTaskUiState,
    courses: List<CourseEntity>,
    onBack: () -> Unit,
    onTitleChange: (String) -> Unit,
    onDescriptionChange: (String) -> Unit,
    onDeadlineChange: (String) -> Unit,
    onPriorityChange: (Int) -> Unit,
    onCourseChange: (Int) -> Unit,
    onSave: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (editTaskUiState.taskId == null) "新增任务" else "编辑任务") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "返回")
                    }
                },
            )
        },
        modifier = modifier,
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            CourseDropdown(
                selectedCourseId = editTaskUiState.courseId,
                courses = courses,
                onCourseChange = onCourseChange,
            )
            OutlinedTextField(
                value = editTaskUiState.title,
                onValueChange = onTitleChange,
                label = { Text("任务标题") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = editTaskUiState.description,
                onValueChange = onDescriptionChange,
                label = { Text("任务说明") },
                minLines = 3,
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = editTaskUiState.deadline,
                onValueChange = onDeadlineChange,
                label = { Text("截止日期，例如 2026-07-03") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            Text("优先级：${"★".repeat(editTaskUiState.priority)}")
            Slider(
                value = editTaskUiState.priority.toFloat(),
                onValueChange = { onPriorityChange(it.toInt()) },
                valueRange = 1f..3f,
                steps = 1,
            )
            editTaskUiState.errorMessage?.let { message ->
                Text(
                    text = message,
                    color = MaterialTheme.colorScheme.error,
                )
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                Button(onClick = onSave) {
                    Text("保存")
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CourseDropdown(
    selectedCourseId: Int,
    courses: List<CourseEntity>,
    onCourseChange: (Int) -> Unit,
) {
    var expanded by remember { mutableStateOf(false) }
    val selectedCourseName = courses.firstOrNull { it.id == selectedCourseId }?.name ?: "请选择课程"

    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = !expanded },
    ) {
        OutlinedTextField(
            value = selectedCourseName,
            onValueChange = {},
            readOnly = true,
            label = { Text("所属课程") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier
                .menuAnchor()
                .fillMaxWidth(),
        )
        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
        ) {
            courses.forEach { course ->
                DropdownMenuItem(
                    text = { Text(course.name) },
                    onClick = {
                        onCourseChange(course.id)
                        expanded = false
                    },
                )
            }
        }
    }
}
