package com.example.studyplanner.viewmodel

import com.example.studyplanner.data.entity.CourseEntity
import com.example.studyplanner.datastore.UserPreferences
import com.example.studyplanner.model.RecommendedTask
import com.example.studyplanner.model.TaskWithCourse

sealed interface HomeUiState {
    data object Loading : HomeUiState
    data class Success(
        val tasks: List<TaskWithCourse>,
        val preferences: UserPreferences,
        val searchQuery: String,
    ) : HomeUiState
    data class Error(val message: String) : HomeUiState
}

sealed interface CoursesUiState {
    data object Loading : CoursesUiState
    data class Success(val courses: List<CourseEntity>) : CoursesUiState
}

sealed interface RecommendedUiState {
    data object Loading : RecommendedUiState
    data class Success(val tasks: List<RecommendedTask>) : RecommendedUiState
    data class Error(val message: String) : RecommendedUiState
}

data class EditTaskUiState(
    val taskId: Int? = null,
    val courseId: Int = 0,
    val title: String = "",
    val description: String = "",
    val deadline: String = "",
    val priority: Int = 1,
    val isDone: Boolean = false,
    val errorMessage: String? = null,
)
