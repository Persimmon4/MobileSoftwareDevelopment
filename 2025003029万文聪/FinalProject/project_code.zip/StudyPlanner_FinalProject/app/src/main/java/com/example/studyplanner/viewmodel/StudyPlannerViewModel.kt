package com.example.studyplanner.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.studyplanner.StudyPlannerApplication
import com.example.studyplanner.data.entity.CourseEntity
import com.example.studyplanner.data.entity.TaskEntity
import com.example.studyplanner.data.repository.StudyPlannerRepository
import com.example.studyplanner.datastore.UserPreferencesRepository
import com.example.studyplanner.model.TaskWithCourse
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class StudyPlannerViewModel(
    private val repository: StudyPlannerRepository,
    private val preferencesRepository: UserPreferencesRepository,
) : ViewModel() {

    private val searchQuery = MutableStateFlow("")

    private val preferencesFlow = preferencesRepository.userPreferencesFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = preferencesRepository.defaultPreferences,
    )

    val homeUiState: StateFlow<HomeUiState> = combine(searchQuery, preferencesFlow) { query, preferences ->
        Pair(query, preferences)
    }.flatMapLatest { (query, preferences) ->
        repository.getTaskItems(
            query = query,
            showCompleted = preferences.showCompleted,
            sortMode = preferences.sortMode,
        ).map { tasks ->
            HomeUiState.Success(
                tasks = tasks,
                preferences = preferences,
                searchQuery = query,
            ) as HomeUiState
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = HomeUiState.Loading,
    )

    val coursesUiState: StateFlow<CoursesUiState> = repository.getAllCourses()
        .map { courses -> CoursesUiState.Success(courses) as CoursesUiState }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = CoursesUiState.Loading,
        )

    private val _recommendedUiState = MutableStateFlow<RecommendedUiState>(RecommendedUiState.Loading)
    val recommendedUiState: StateFlow<RecommendedUiState> = _recommendedUiState

    private val _editTaskUiState = MutableStateFlow(EditTaskUiState())
    val editTaskUiState: StateFlow<EditTaskUiState> = _editTaskUiState

    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage

    init {
        viewModelScope.launch {
            repository.ensureSeedData()
        }
        loadRecommendedTasks()
    }

    fun updateSearchQuery(query: String) {
        searchQuery.value = query
        viewModelScope.launch {
            preferencesRepository.updateRecentSearch(query)
        }
    }

    fun updateShowCompleted(showCompleted: Boolean) {
        viewModelScope.launch {
            preferencesRepository.updateShowCompleted(showCompleted)
        }
    }

    fun updateSortMode(sortMode: String) {
        viewModelScope.launch {
            preferencesRepository.updateSortMode(sortMode)
        }
    }

    fun updateDarkTheme(enabled: Boolean) {
        viewModelScope.launch {
            preferencesRepository.updateDarkTheme(enabled)
        }
    }

    fun addCourse(name: String, teacher: String, classroom: String) {
        val courseName = name.trim()
        if (courseName.isEmpty()) {
            showMessage("课程名称不能为空")
            return
        }
        viewModelScope.launch {
            repository.insertCourse(
                CourseEntity(
                    name = courseName,
                    teacher = teacher.trim(),
                    classroom = classroom.trim(),
                )
            )
            showMessage("课程已添加")
        }
    }

    fun deleteCourse(course: CourseEntity) {
        viewModelScope.launch {
            repository.deleteCourse(course)
            showMessage("课程已删除，相关任务也已删除")
        }
    }

    fun startAddTask(defaultCourseId: Int = 0) {
        _editTaskUiState.value = EditTaskUiState(courseId = defaultCourseId)
    }

    fun startEditTask(taskId: Int) {
        viewModelScope.launch {
            val task = repository.getTaskEntity(taskId)
            if (task == null) {
                _editTaskUiState.value = EditTaskUiState(errorMessage = "任务不存在")
            } else {
                _editTaskUiState.value = EditTaskUiState(
                    taskId = task.id,
                    courseId = task.courseId,
                    title = task.title,
                    description = task.description,
                    deadline = task.deadline,
                    priority = task.priority,
                    isDone = task.isDone,
                )
            }
        }
    }

    fun updateEditTitle(title: String) {
        _editTaskUiState.update { it.copy(title = title, errorMessage = null) }
    }

    fun updateEditDescription(description: String) {
        _editTaskUiState.update { it.copy(description = description) }
    }

    fun updateEditDeadline(deadline: String) {
        _editTaskUiState.update { it.copy(deadline = deadline) }
    }

    fun updateEditPriority(priority: Int) {
        _editTaskUiState.update { it.copy(priority = priority.coerceIn(1, 3)) }
    }

    fun updateEditCourse(courseId: Int) {
        _editTaskUiState.update { it.copy(courseId = courseId, errorMessage = null) }
    }

    fun saveTask(onSaved: () -> Unit) {
        val state = _editTaskUiState.value
        if (state.title.trim().isEmpty()) {
            _editTaskUiState.update { it.copy(errorMessage = "任务标题不能为空") }
            return
        }
        if (state.courseId == 0) {
            _editTaskUiState.update { it.copy(errorMessage = "请选择课程") }
            return
        }
        viewModelScope.launch {
            val task = TaskEntity(
                id = state.taskId ?: 0,
                courseId = state.courseId,
                title = state.title.trim(),
                description = state.description.trim(),
                deadline = state.deadline.trim(),
                priority = state.priority,
                isDone = state.isDone,
            )
            if (state.taskId == null) {
                repository.insertTask(task)
                showMessage("任务已添加")
            } else {
                repository.updateTask(task)
                showMessage("任务已保存")
            }
            onSaved()
        }
    }

    fun deleteTask(taskId: Int) {
        viewModelScope.launch {
            repository.deleteTask(taskId)
            showMessage("任务已删除")
        }
    }

    fun setTaskDone(taskId: Int, done: Boolean) {
        viewModelScope.launch {
            repository.setTaskDone(taskId, done)
        }
    }

    fun getTaskDetail(taskId: Int): Flow<TaskWithCourse?> = repository.getTask(taskId)

    fun getTasksByCourse(courseId: Int): Flow<List<TaskWithCourse>> {
        return repository.getTasksByCourse(courseId)
    }

    fun loadRecommendedTasks() {
        viewModelScope.launch {
            _recommendedUiState.value = RecommendedUiState.Loading
            _recommendedUiState.value = try {
                val tasks = repository.loadRecommendedTasks()
                if (tasks.isEmpty()) {
                    RecommendedUiState.Error("在线推荐任务为空")
                } else {
                    RecommendedUiState.Success(tasks)
                }
            } catch (exception: Exception) {
                RecommendedUiState.Error("网络加载失败：${exception.message ?: "未知错误"}")
            }
        }
    }

    fun addRecommendedTask(recommendedTask: com.example.studyplanner.model.RecommendedTask, courseId: Int) {
        if (courseId == 0) {
            showMessage("请先选择课程")
            return
        }
        viewModelScope.launch {
            repository.insertTask(
                TaskEntity(
                    courseId = courseId,
                    title = recommendedTask.title,
                    description = recommendedTask.description,
                    deadline = "2026-07-03",
                    priority = recommendedTask.priority,
                )
            )
            showMessage("已加入本地任务")
        }
    }

    fun showMessage(message: String) {
        _snackbarMessage.value = message
    }

    fun clearMessage() {
        _snackbarMessage.value = null
    }

    companion object {
        val Factory = viewModelFactory {
            initializer {
                val application = this[APPLICATION_KEY] as StudyPlannerApplication
                StudyPlannerViewModel(
                    repository = application.container.studyPlannerRepository,
                    preferencesRepository = application.container.userPreferencesRepository,
                )
            }
        }
    }
}
