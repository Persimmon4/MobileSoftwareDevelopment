package com.example.studyplanner.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

private const val USER_PREFERENCES_NAME = "study_planner_preferences"
private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(
    name = USER_PREFERENCES_NAME
)

class UserPreferencesRepository(private val context: Context) {
    val defaultPreferences = UserPreferences()

    private object PreferencesKeys {
        val SHOW_COMPLETED = booleanPreferencesKey("show_completed")
        val SORT_MODE = stringPreferencesKey("sort_mode")
        val DARK_THEME = booleanPreferencesKey("dark_theme")
        val RECENT_SEARCH = stringPreferencesKey("recent_search")
    }

    val userPreferencesFlow: Flow<UserPreferences> = context.dataStore.data
        .catch { exception ->
            if (exception is IOException) {
                emit(androidx.datastore.preferences.core.emptyPreferences())
            } else {
                throw exception
            }
        }
        .map { preferences ->
            UserPreferences(
                showCompleted = preferences[PreferencesKeys.SHOW_COMPLETED] ?: true,
                sortMode = preferences[PreferencesKeys.SORT_MODE] ?: "deadline",
                darkTheme = preferences[PreferencesKeys.DARK_THEME] ?: false,
                recentSearch = preferences[PreferencesKeys.RECENT_SEARCH] ?: "",
            )
        }

    suspend fun updateShowCompleted(showCompleted: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.SHOW_COMPLETED] = showCompleted
        }
    }

    suspend fun updateSortMode(sortMode: String) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.SORT_MODE] = sortMode
        }
    }

    suspend fun updateDarkTheme(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.DARK_THEME] = enabled
        }
    }

    suspend fun updateRecentSearch(query: String) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.RECENT_SEARCH] = query
        }
    }
}
