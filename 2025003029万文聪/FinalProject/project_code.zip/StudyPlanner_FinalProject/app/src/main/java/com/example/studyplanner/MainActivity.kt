package com.example.studyplanner

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.example.studyplanner.navigation.StudyPlannerApp
import com.example.studyplanner.ui.theme.StudyPlannerTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val appContainer = (application as StudyPlannerApplication).container
        setContent {
            val preferences by appContainer.userPreferencesRepository.userPreferencesFlow.collectAsState(
                initial = appContainer.userPreferencesRepository.defaultPreferences
            )
            StudyPlannerTheme(darkTheme = preferences.darkTheme) {
                StudyPlannerApp()
            }
        }
    }
}
