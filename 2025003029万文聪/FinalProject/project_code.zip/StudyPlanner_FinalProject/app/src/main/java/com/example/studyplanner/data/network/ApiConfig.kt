package com.example.studyplanner.data.network

object ApiConfig {
    const val BASE_URL = "https://jsonplaceholder.typicode.com/"
}
