package com.example.studyplanner.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.studyplanner.data.entity.TaskEntity
import com.example.studyplanner.model.TaskWithCourse
import kotlinx.coroutines.flow.Flow

@Dao
interface TaskDao {
    @Query(
        """
        SELECT
            t.id AS id,
            t.course_id AS courseId,
            c.name AS courseName,
            t.title AS title,
            t.description AS description,
            t.deadline AS deadline,
            t.priority AS priority,
            t.is_done AS isDone
        FROM study_tasks AS t
        INNER JOIN courses AS c ON t.course_id = c.id
        WHERE (:query = '' OR t.title LIKE '%' || :query || '%' OR c.name LIKE '%' || :query || '%')
          AND (:showCompleted = 1 OR t.is_done = 0)
        ORDER BY
            CASE WHEN :sortMode = 'priority' THEN t.priority END DESC,
            CASE WHEN :sortMode = 'deadline' THEN t.deadline END ASC,
            t.id DESC
        """
    )
    fun getTaskItems(
        query: String,
        showCompleted: Boolean,
        sortMode: String,
    ): Flow<List<TaskWithCourse>>

    @Query(
        """
        SELECT
            t.id AS id,
            t.course_id AS courseId,
            c.name AS courseName,
            t.title AS title,
            t.description AS description,
            t.deadline AS deadline,
            t.priority AS priority,
            t.is_done AS isDone
        FROM study_tasks AS t
        INNER JOIN courses AS c ON t.course_id = c.id
        WHERE t.id = :taskId
        LIMIT 1
        """
    )
    fun getTaskItem(taskId: Int): Flow<TaskWithCourse?>

    @Query(
        """
        SELECT
            t.id AS id,
            t.course_id AS courseId,
            c.name AS courseName,
            t.title AS title,
            t.description AS description,
            t.deadline AS deadline,
            t.priority AS priority,
            t.is_done AS isDone
        FROM study_tasks AS t
        INNER JOIN courses AS c ON t.course_id = c.id
        WHERE t.course_id = :courseId
        ORDER BY t.is_done ASC, t.deadline ASC
        """
    )
    fun getTasksByCourse(courseId: Int): Flow<List<TaskWithCourse>>

    @Query("SELECT * FROM study_tasks WHERE id = :taskId LIMIT 1")
    suspend fun getTaskEntity(taskId: Int): TaskEntity?

    @Query("SELECT COUNT(*) FROM study_tasks")
    suspend fun countTasks(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(task: TaskEntity): Long

    @Update
    suspend fun update(task: TaskEntity)

    @Delete
    suspend fun delete(task: TaskEntity)

    @Query("UPDATE study_tasks SET is_done = :done WHERE id = :taskId")
    suspend fun setDone(taskId: Int, done: Boolean)

    @Query("DELETE FROM study_tasks WHERE id = :taskId")
    suspend fun deleteById(taskId: Int)
}
