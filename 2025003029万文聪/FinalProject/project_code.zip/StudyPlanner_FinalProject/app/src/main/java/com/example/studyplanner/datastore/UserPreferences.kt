package com.example.studyplanner.datastore

data class UserPreferences(
    val showCompleted: Boolean = true,
    val sortMode: String = "deadline",
    val darkTheme: Boolean = false,
    val recentSearch: String = "",
)
