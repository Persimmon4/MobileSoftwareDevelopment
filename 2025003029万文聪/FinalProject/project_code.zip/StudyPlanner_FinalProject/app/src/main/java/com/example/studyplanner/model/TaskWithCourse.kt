package com.example.studyplanner.model

/**
 * 首页列表使用的联合查询模型。
 * 数据来自 study_tasks 与 courses 两张表的 JOIN 查询。
 */
data class TaskWithCourse(
    val id: Int,
    val courseId: Int,
    val courseName: String,
    val title: String,
    val description: String,
    val deadline: String,
    val priority: Int,
    val isDone: Boolean,
)
