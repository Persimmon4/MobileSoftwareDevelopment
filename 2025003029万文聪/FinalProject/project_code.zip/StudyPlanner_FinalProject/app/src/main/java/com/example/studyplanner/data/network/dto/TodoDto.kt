package com.example.studyplanner.data.network.dto

import com.example.studyplanner.model.RecommendedTask

/**
 * 在线推荐任务接口返回的数据结构。
 */
data class TodoDto(
    val userId: Int = 0,
    val id: Int = 0,
    val title: String = "",
    val completed: Boolean = false,
)

fun TodoDto.asRecommendedTask(): RecommendedTask {
    val templates = listOf(
        "整理移动端软件开发期末项目报告" to "补充项目功能说明、技术栈、运行截图和遇到的问题。",
        "复习 Room 数据库" to "梳理 Entity、Dao、Database 和 Repository 的关系。",
        "完成 Kotlin 协程笔记" to "整理 viewModelScope、suspend、Flow 和 StateFlow 的用法。",
        "复盘 Compose 页面结构" to "总结 Scaffold、LazyColumn、Card、Navigation 的使用方式。",
        "整理考研英语阅读错题" to "记录长难句、核心词和选项错误原因。",
        "制定明日学习计划" to "把课程作业、复习任务和项目调试拆成可执行小任务。",
        "检查 GitHub 提交流程" to "确认 report.md、project_code.zip 和 screenshots 文件夹完整。",
        "复习人工智能基础概念" to "整理搜索算法、专家系统和机器学习基础概念。",
        "完成一轮代码自测" to "运行新增、编辑、删除、筛选、推荐任务加入本地等流程。",
        "整理课程重点清单" to "把本周课程重点按优先级分成必做、应做和可选。",
        "补充项目讲解稿" to "按文件位置、功能和作用准备项目答辩说明。",
        "清理项目提交文件" to "删除 build、.gradle、.idea、local.properties 等不应提交的文件。",
    )
    val (taskTitle, taskDescription) = templates[(id.coerceAtLeast(1) - 1) % templates.size]
    return RecommendedTask(
        id = id,
        title = taskTitle,
        description = taskDescription,
        priority = when {
            id % 5 == 0 -> 3
            completed -> 1
            else -> 2
        },
    )
}
