package com.example.studyplanner.data.network

import com.example.studyplanner.data.network.dto.TodoDto
import retrofit2.http.GET
import retrofit2.http.Query

interface StudyPlannerApiService {
    @GET("todos")
    suspend fun getRecommendedTodos(
        @Query("_limit") limit: Int = 12,
    ): List<TodoDto>
}
