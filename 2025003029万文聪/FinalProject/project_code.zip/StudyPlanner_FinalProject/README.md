# Study Planner 学习计划助手

这是移动软件开发期末项目，用来管理课程、作业和学习任务。项目不是单纯的待办清单，而是把课程、任务、在线推荐和设置偏好放在一个完整流程里。

## 主要功能

- 查看首页学习任务列表
- 新增、编辑、删除任务
- 切换任务完成状态
- 按关键词搜索任务或课程
- 按截止时间、优先级排序
- 显示学习进度统计：全部、待完成、已完成、高优先级
- 管理课程，并查看课程对应的任务
- 从在线接口加载推荐学习任务
- 将推荐任务加入本地任务列表
- 保存显示偏好、排序偏好和深色模式设置

## 技术使用

项目使用 Kotlin、Jetpack Compose、Material 3、Navigation、Room、DataStore、ViewModel、StateFlow、Retrofit 和协程实现。

Room 用来保存课程和任务，DataStore 用来保存设置页偏好，Retrofit 用来加载在线推荐任务。在线接口使用公开测试接口，不需要 API key。

## 运行方式

使用 Android Studio 打开 `StudyPlanner_FinalProject` 目录，等待 Gradle Sync 完成后运行到模拟器或真机。

如果模拟器仍然打开之前实验的旧 App，可以先卸载旧应用，再重新运行当前项目。
