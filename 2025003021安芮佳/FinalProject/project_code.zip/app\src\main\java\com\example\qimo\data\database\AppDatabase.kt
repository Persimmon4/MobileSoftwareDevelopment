package com.example.qimo.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.qimo.data.dao.CourseDao
import com.example.qimo.data.dao.CourseInfoEntity
import com.example.qimo.data.dao.SemesterDao
import com.example.qimo.data.entity.CourseEntity
import com.example.qimo.data.entity.SemesterEntity

@Database(
    entities = [CourseEntity::class, SemesterEntity::class, CourseInfoEntity::class],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun courseDao(): CourseDao
    abstract fun semesterDao(): SemesterDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        // 数据库迁移 1 → 2：新增 course_info_cache 表
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("""
                    CREATE TABLE IF NOT EXISTS course_info_cache (
                        id TEXT NOT NULL PRIMARY KEY,
                        courseName TEXT NOT NULL,
                        teacher TEXT NOT NULL,
                        description TEXT,
                        credit REAL NOT NULL,
                        rating REAL,
                        coverUrl TEXT NOT NULL
                    )
                """)
            }
        }

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "course_database"
                )
                    .addMigrations(MIGRATION_1_2)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
