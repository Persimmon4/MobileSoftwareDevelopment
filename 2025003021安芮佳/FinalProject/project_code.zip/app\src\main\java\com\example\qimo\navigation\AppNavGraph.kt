package com.example.qimo.navigation

import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.qimo.ui.theme.screens.AddCourseScreen
import com.example.qimo.ui.theme.screens.CourseDetailScreen
import com.example.qimo.ui.theme.screens.CourseListScreen
import com.example.qimo.ui.theme.screens.SettingsScreen
import com.example.qimo.ui.theme.screens.StatisticsScreen
import com.example.qimo.ui.theme.screens.WeekViewScreen
import com.example.qimo.viewmodel.CourseViewModel

@Composable
fun AppNavGraph(
    navController: NavHostController = rememberNavController(),
    courseViewModel: CourseViewModel
) {
    NavHost(
        navController = navController,
        startDestination = "course_list",
        enterTransition = { slideInHorizontally(initialOffsetX = { it }) + fadeIn() },
        exitTransition = { slideOutHorizontally(targetOffsetX = { -it / 3 }) + fadeOut() },
        popEnterTransition = { slideInHorizontally(initialOffsetX = { -it / 3 }) + fadeIn() },
        popExitTransition = { slideOutHorizontally(targetOffsetX = { it }) + fadeOut() }
    ) {
        // 课程列表页
        composable("course_list") {
            CourseListScreen(
                navController = navController,
                viewModel = courseViewModel
            )
        }

        // 课程详情页
        composable("course_detail/{courseId}") { backStackEntry ->
            val courseId = backStackEntry.arguments?.getString("courseId") ?: "0"
            CourseDetailScreen(
                navController = navController,
                viewModel = courseViewModel,
                courseId = courseId
            )
        }

        // 添加课程页
        composable("add_course") {
            AddCourseScreen(
                navController = navController,
                viewModel = courseViewModel
            )
        }

        // 编辑课程页
        composable("edit_course/{courseId}") { backStackEntry ->
            val courseId = backStackEntry.arguments?.getString("courseId") ?: "0"
            AddCourseScreen(
                navController = navController,
                viewModel = courseViewModel,
                editCourseId = courseId.toIntOrNull()
            )
        }

        // 周视图课表页
        composable("week_view") {
            WeekViewScreen(
                navController = navController,
                viewModel = courseViewModel
            )
        }

        // 统计页
        composable("statistics") {
            StatisticsScreen(
                navController = navController,
                viewModel = courseViewModel
            )
        }

        // 设置页
        composable("settings") {
            SettingsScreen(
                navController = navController,
                viewModel = courseViewModel
            )
        }
    }
}
