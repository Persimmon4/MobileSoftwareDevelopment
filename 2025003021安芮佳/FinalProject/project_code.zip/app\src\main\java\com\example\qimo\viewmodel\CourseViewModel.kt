package com.example.qimo.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.qimo.data.entity.CourseEntity
import com.example.qimo.data.entity.SemesterEntity
import com.example.qimo.data.repository.CourseRepository
import com.example.qimo.datastore.UserPreferencesRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import retrofit2.HttpException
import java.io.IOException

class CourseViewModel(
    private val courseRepository: CourseRepository,
    private val userPreferencesRepository: UserPreferencesRepository
) : ViewModel() {
    // 课程列表状态
    private val _courseListUiState = MutableStateFlow<CourseListUiState>(CourseListUiState.Loading)
    val courseListUiState: StateFlow<CourseListUiState> = _courseListUiState.asStateFlow()

    // 课程详情状态
    private val _courseDetailUiState = MutableStateFlow<CourseDetailUiState>(CourseDetailUiState.Loading)
    val courseDetailUiState: StateFlow<CourseDetailUiState> = _courseDetailUiState.asStateFlow()

    // 热门课程（网络）状态
    private val _hotCourseUiState = MutableStateFlow<HotCourseUiState>(HotCourseUiState.Loading)
    val hotCourseUiState: StateFlow<HotCourseUiState> = _hotCourseUiState.asStateFlow()

    // 课程冲突检测结果
    private val _conflictMessage = MutableStateFlow<String?>(null)
    val conflictMessage: StateFlow<String?> = _conflictMessage.asStateFlow()

    // 操作成功提示
    private val _successMessage = MutableStateFlow<String?>(null)
    val successMessage: StateFlow<String?> = _successMessage.asStateFlow()

    // 搜索关键词
    private val _searchKeyword = MutableStateFlow("")
    val searchKeyword: StateFlow<String> = _searchKeyword.asStateFlow()

    // 标记是否已初始化，避免重复加载
    private var initialized = false

    // 由 Compose 触发的初始化方法
    fun initialize() {
        if (initialized) return
        initialized = true
        viewModelScope.launch {
            loadCurrentSemesterCourses()
            loadHotCourses()
        }
    }

    // 加载当前学期课程（供外部调用，如重试）
    fun loadCurrentSemesterCourses() {
        viewModelScope.launch {
            _courseListUiState.value = CourseListUiState.Loading
            try {
                val currentSemester = courseRepository.getCurrentSemester()
                val semesters = courseRepository.getAllSemesters().first()

                // 如果没有学期，创建默认学期
                val targetSemesterId = if (currentSemester != null) {
                    currentSemester.id
                } else {
                    val defaultSemester = SemesterEntity(
                        semesterName = "2024-2025学年第一学期",
                        isCurrent = true,
                        startDate = System.currentTimeMillis(),
                        endDate = System.currentTimeMillis() + 157784760000 // 5个月后
                    )
                    courseRepository.insertSemester(defaultSemester)
                    defaultSemester.id
                }

                // 保存当前学期ID到DataStore
                userPreferencesRepository.saveCurrentSemesterId(targetSemesterId)

                // 监听课程列表
                courseRepository.getCoursesBySemester(targetSemesterId).collect { courses ->
                    if (courses.isEmpty()) {
                        _courseListUiState.value = CourseListUiState.Empty
                    } else {
                        _courseListUiState.value = CourseListUiState.Success(courses, semesters)
                    }
                }
            } catch (e: Exception) {
                _courseListUiState.value = CourseListUiState.Error(e.message ?: "加载课程失败")
            }
        }
    }

    // 搜索课程
    fun searchCourses(keyword: String) {
        _searchKeyword.value = keyword
        viewModelScope.launch {
            _courseListUiState.value = CourseListUiState.Loading
            courseRepository.searchCourses(keyword).collect { courses ->
                val semesters = courseRepository.getAllSemesters().first()
                if (courses.isEmpty()) {
                    _courseListUiState.value = CourseListUiState.Empty
                } else {
                    _courseListUiState.value = CourseListUiState.Success(courses, semesters)
                }
            }
        }
    }

    // 加载课程详情（本地+网络，支持离线缓存）
    fun loadCourseDetail(courseId: Int) {
        viewModelScope.launch {
            _courseDetailUiState.value = CourseDetailUiState.Loading
            try {
                val course = courseRepository.getCourseById(courseId)
                if (course == null) {
                    _courseDetailUiState.value = CourseDetailUiState.Error("课程不存在")
                    return@launch
                }

                // 尝试从网络获取额外信息
                try {
                    val courseInfoResponse = courseRepository.getCourseInfo(courseId.toString())
                    val courseInfo = if (courseInfoResponse.isSuccessful) {
                        val body = courseInfoResponse.body()
                        // 缓存到本地
                        if (body != null) {
                            courseRepository.cacheCourseInfo(body)
                        }
                        body
                    } else null

                    _courseDetailUiState.value = CourseDetailUiState.Success(course, courseInfo)
                } catch (e: IOException) {
                    // 网络失败，尝试从缓存加载
                    val cachedInfo = courseRepository.getCachedCourseInfo(courseId.toString())
                    _courseDetailUiState.value = CourseDetailUiState.Success(
                        course, cachedInfo, isOffline = true
                    )
                } catch (e: HttpException) {
                    val cachedInfo = courseRepository.getCachedCourseInfo(courseId.toString())
                    _courseDetailUiState.value = CourseDetailUiState.Success(
                        course, cachedInfo, isOffline = true
                    )
                }
            } catch (e: Exception) {
                _courseDetailUiState.value = CourseDetailUiState.Error(e.message ?: "加载详情失败")
            }
        }
    }

    // 加载热门课程（网络，支持离线缓存）
    fun loadHotCourses() {
        viewModelScope.launch {
            _hotCourseUiState.value = HotCourseUiState.Loading
            try {
                val response = courseRepository.getHotCourses()
                if (response.isSuccessful) {
                    val courses = response.body() ?: emptyList()
                    // 缓存到本地
                    courseRepository.cacheHotCourses(courses)
                    _hotCourseUiState.value = HotCourseUiState.Success(courses)
                } else {
                    // 请求失败，尝试缓存
                    val cached = courseRepository.getCachedHotCourses()
                    if (cached.isNotEmpty()) {
                        _hotCourseUiState.value = HotCourseUiState.Success(cached, isOffline = true)
                    } else {
                        _hotCourseUiState.value = HotCourseUiState.Error("请求失败：${response.code()}")
                    }
                }
            } catch (e: IOException) {
                val cached = courseRepository.getCachedHotCourses()
                if (cached.isNotEmpty()) {
                    _hotCourseUiState.value = HotCourseUiState.Success(cached, isOffline = true)
                } else {
                    _hotCourseUiState.value = HotCourseUiState.Error("网络连接失败，请检查网络")
                }
            } catch (e: Exception) {
                val cached = courseRepository.getCachedHotCourses()
                if (cached.isNotEmpty()) {
                    _hotCourseUiState.value = HotCourseUiState.Success(cached, isOffline = true)
                } else {
                    _hotCourseUiState.value = HotCourseUiState.Error(e.message ?: "加载热门课程失败")
                }
            }
        }
    }

    // 检查课程冲突
    fun checkConflict(dayOfWeek: Int, startTime: String, endTime: String): String? {
        // 这里返回 null 表示无冲突，否则返回冲突信息
        val startMin = timeToMinutes(startTime)
        val endMin = timeToMinutes(endTime)
        if (startMin == -1 || endMin == -1) return null

        // 这个检查是同步的，用于在添加课程时快速反馈
        // 实际冲突检测在 addCourse 中通过数据库查询完成
        return null
    }

    // 添加课程（带冲突检测）
    fun addCourse(course: CourseEntity, onConflict: ((String) -> Unit)? = null) {
        viewModelScope.launch {
            try {
                _conflictMessage.value = null
                // 冲突检测：查询同一天、同一时间段的课程
                val currentSemester = courseRepository.getCurrentSemester()
                val semesterId = currentSemester?.id ?: 1
                val existingCourses = courseRepository.getCoursesBySemester(semesterId).first()
                val conflicts = existingCourses.filter { existing ->
                    existing.dayOfWeek == course.dayOfWeek &&
                            isTimeOverlap(
                                course.startTime, course.endTime,
                                existing.startTime, existing.endTime
                            )
                }
                if (conflicts.isNotEmpty()) {
                    val conflictNames = conflicts.joinToString("、") { it.courseName }
                    val msg = "与「$conflictNames」时间冲突！\n${dayName(course.dayOfWeek)} ${course.startTime}-${course.endTime} 已有课程"
                    _conflictMessage.value = msg
                    onConflict?.invoke(msg)
                    return@launch
                }

                courseRepository.insertCourse(course)
                _successMessage.value = "课程「${course.courseName}」添加成功！"
                loadCurrentSemesterCourses()
            } catch (e: Exception) {
                _courseListUiState.value = CourseListUiState.Error("添加课程失败：${e.message}")
            }
        }
    }

    // 删除课程
    fun deleteCourse(course: CourseEntity) {
        viewModelScope.launch {
            try {
                courseRepository.deleteCourse(course)
                _successMessage.value = "课程「${course.courseName}」已删除"
                loadCurrentSemesterCourses()
            } catch (e: Exception) {
                _courseListUiState.value = CourseListUiState.Error("删除课程失败：${e.message}")
            }
        }
    }

    // 更新课程（带冲突检测，排除自身）
    fun updateCourseWithConflict(course: CourseEntity, onConflict: ((String) -> Unit)? = null) {
        viewModelScope.launch {
            try {
                _conflictMessage.value = null
                // 冲突检测：排除当前课程自身
                val currentSemester = courseRepository.getCurrentSemester()
                val semesterId = currentSemester?.id ?: 1
                val existingCourses = courseRepository.getCoursesBySemester(semesterId).first()
                val conflicts = existingCourses.filter { existing ->
                    existing.id != course.id && // 排除自身
                            existing.dayOfWeek == course.dayOfWeek &&
                            isTimeOverlap(
                                course.startTime, course.endTime,
                                existing.startTime, existing.endTime
                            )
                }
                if (conflicts.isNotEmpty()) {
                    val conflictNames = conflicts.joinToString("、") { it.courseName }
                    val msg = "与「$conflictNames」时间冲突！\n${dayName(course.dayOfWeek)} ${course.startTime}-${course.endTime} 已有课程"
                    _conflictMessage.value = msg
                    onConflict?.invoke(msg)
                    return@launch
                }

                courseRepository.updateCourse(course)
                _successMessage.value = "课程「${course.courseName}」修改成功！"
                loadCurrentSemesterCourses()
            } catch (e: Exception) {
                _courseListUiState.value = CourseListUiState.Error("更新课程失败：${e.message}")
            }
        }
    }

    // 更新课程（无冲突检测，直接更新）
    fun updateCourse(course: CourseEntity) {
        viewModelScope.launch {
            try {
                courseRepository.updateCourse(course)
                loadCurrentSemesterCourses()
            } catch (e: Exception) {
                _courseListUiState.value = CourseListUiState.Error("更新课程失败：${e.message}")
            }
        }
    }

    // 切换深色模式
    fun toggleDarkMode(enabled: Boolean) {
        viewModelScope.launch {
            userPreferencesRepository.saveDarkModePreference(enabled)
        }
    }

    // 清除冲突消息
    fun clearConflict() {
        _conflictMessage.value = null
    }

    // 清除成功消息
    fun clearSuccessMessage() {
        _successMessage.value = null
    }

    // 获取所有课程（用于统计和周视图）
    fun getAllCourses(): List<CourseEntity> {
        val state = _courseListUiState.value
        return if (state is CourseListUiState.Success) state.courses else emptyList()
    }

    // 根据 ID 获取课程（用于编辑模式回填数据）
    suspend fun getCourseById(courseId: Int): CourseEntity? {
        return courseRepository.getCourseById(courseId)
    }

    companion object {
        private val dayNames = listOf("", "周一", "周二", "周三", "周四", "周五", "周六", "周日")
        fun dayName(day: Int): String = dayNames.getOrElse(day) { "周$day" }

        private fun timeToMinutes(time: String): Int {
            val parts = time.split(":")
            if (parts.size != 2) return -1
            val hour = parts[0].toIntOrNull() ?: return -1
            val min = parts[1].toIntOrNull() ?: return -1
            return hour * 60 + min
        }

        private fun isTimeOverlap(
            start1: String, end1: String,
            start2: String, end2: String
        ): Boolean {
            val s1 = timeToMinutes(start1)
            val e1 = timeToMinutes(end1)
            val s2 = timeToMinutes(start2)
            val e2 = timeToMinutes(end2)
            if (s1 == -1 || e1 == -1 || s2 == -1 || e2 == -1) return false
            return s1 < e2 && s2 < e1
        }
    }
}
