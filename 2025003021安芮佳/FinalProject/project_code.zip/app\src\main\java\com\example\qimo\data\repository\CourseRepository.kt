package com.example.qimo.data.repository

import com.example.qimo.data.dao.CourseDao
import com.example.qimo.data.dao.CourseInfoEntity
import com.example.qimo.data.dao.SemesterDao
import com.example.qimo.data.dao.toEntity
import com.example.qimo.data.entity.CourseEntity
import com.example.qimo.data.entity.SemesterEntity
import com.example.qimo.data.network.NetworkCourseDataSource
import com.example.qimo.data.network.dto.CourseInfoDto
import kotlinx.coroutines.flow.Flow
import retrofit2.Response

class CourseRepository(
    private val courseDao: CourseDao,
    private val semesterDao: SemesterDao,
    private val networkDataSource: NetworkCourseDataSource = NetworkCourseDataSource()
) {
    // ========== 本地数据库操作 ==========
    fun getCoursesBySemester(semesterId: Int): Flow<List<CourseEntity>> =
        courseDao.getCoursesBySemester(semesterId)

    fun searchCourses(keyword: String): Flow<List<CourseEntity>> =
        courseDao.searchCourses(keyword)

    suspend fun getCourseById(courseId: Int): CourseEntity? =
        courseDao.getCourseById(courseId)

    suspend fun insertCourse(course: CourseEntity) =
        courseDao.insertCourse(course)

    suspend fun updateCourse(course: CourseEntity) =
        courseDao.updateCourse(course)

    suspend fun deleteCourse(course: CourseEntity) =
        courseDao.deleteCourse(course)

    // 获取同一天同一时间段的课程（冲突检测用）
    suspend fun getConflictingCourses(dayOfWeek: Int, startTime: String, endTime: String, semesterId: Int): List<CourseEntity> =
        courseDao.getConflictingCourses(dayOfWeek, startTime, endTime, semesterId)

    // ========== 学期相关操作 ==========
    fun getAllSemesters(): Flow<List<SemesterEntity>> =
        semesterDao.getAllSemesters()

    suspend fun getCurrentSemester(): SemesterEntity? =
        semesterDao.getCurrentSemester()

    suspend fun insertSemester(semester: SemesterEntity) =
        semesterDao.insertSemester(semester)

    suspend fun updateSemester(semester: SemesterEntity) =
        semesterDao.updateSemester(semester)

    // ========== 网络请求操作 ==========
    suspend fun getCourseInfo(courseId: String): Response<CourseInfoDto> =
        networkDataSource.getCourseInfo(courseId)

    suspend fun getHotCourses(): Response<List<CourseInfoDto>> =
        networkDataSource.getHotCourses()

    // ========== 离线缓存 ==========
    // 缓存单个课程信息
    suspend fun cacheCourseInfo(courseInfo: CourseInfoDto) {
        courseDao.insertCourseInfo(courseInfo.toEntity())
    }

    // 获取缓存的课程信息
    suspend fun getCachedCourseInfo(courseId: String): CourseInfoDto? {
        return courseDao.getCachedCourseInfo(courseId)?.toDto()
    }

    // 缓存热门课程列表
    suspend fun cacheHotCourses(courses: List<CourseInfoDto>) {
        courseDao.clearAllCourseInfo()
        courses.forEach { courseDao.insertCourseInfo(it.toEntity()) }
    }

    // 获取缓存的热门课程
    suspend fun getCachedHotCourses(): List<CourseInfoDto> {
        return courseDao.getAllCachedCourseInfo().map { it.toDto() }
    }
}
