package com.example.qimo.data.network

import com.example.qimo.data.network.dto.CourseInfoDto
import retrofit2.Response

class NetworkCourseDataSource(
    private val apiService: ApiService = ApiService.create()
) {
    suspend fun getCourseInfo(courseId: String): Response<CourseInfoDto> {
        return apiService.getCourseInfo(courseId)
    }

    suspend fun getHotCourses(): Response<List<CourseInfoDto>> {
        return apiService.getHotCourses()
    }
}