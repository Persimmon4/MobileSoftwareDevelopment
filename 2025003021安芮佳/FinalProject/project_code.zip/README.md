# Qimo 课程表管理 App

## 应用名称
Qimo 课程表

## 运行环境
- 最低 Android 版本：API 24（Android 7.0）
- 推荐 Android 版本：API 36（Android 14）
- 开发工具：Android Studio Hedgehog 或更新版本
- 构建工具：Gradle + Kotlin DSL

## 项目简介
Qimo 是一款面向在校大学生的课程表管理应用，支持新增、编辑、删除、搜索课程，并提供周视图课表、课程统计图表、深色模式切换以及在线课程信息浏览等功能。

## 如何运行
1. 使用 Android Studio 打开该项目
2. 等待 Gradle 同步完成
3. 连接模拟器或真机，点击 Run ▶ 运行

## Git 信息
- 仓库地址：https://github.com/An-ruijia1/2025003021-FinalProject
