package com.example.qimo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.navigation.compose.rememberNavController
import com.example.qimo.data.database.AppDatabase
import com.example.qimo.data.repository.CourseRepository
import com.example.qimo.datastore.UserPreferencesRepository
import com.example.qimo.navigation.AppNavGraph
import com.example.qimo.ui.theme.QimoTheme
import com.example.qimo.viewmodel.CourseViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 构建依赖
        val database = AppDatabase.getInstance(applicationContext)
        val courseRepository = CourseRepository(
            courseDao = database.courseDao(),
            semesterDao = database.semesterDao()
        )
        val preferencesRepository = UserPreferencesRepository(applicationContext)
        val courseViewModel = CourseViewModel(courseRepository, preferencesRepository)

        setContent {
            val isDarkMode by preferencesRepository.getDarkModeEnabled()
                .collectAsState(initial = false)

            QimoTheme(darkTheme = isDarkMode) {
                AppNavGraph(
                    navController = rememberNavController(),
                    courseViewModel = courseViewModel
                )
            }
        }
    }
}
