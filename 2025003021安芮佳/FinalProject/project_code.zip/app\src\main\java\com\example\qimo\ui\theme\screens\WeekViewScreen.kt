package com.example.qimo.ui.theme.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.example.qimo.data.entity.CourseEntity
import com.example.qimo.ui.theme.CourseColors
import com.example.qimo.ui.theme.components.EmptyView
import com.example.qimo.viewmodel.CourseListUiState
import com.example.qimo.viewmodel.CourseViewModel

private val dayNames = listOf("周一", "周二", "周三", "周四", "周五", "周六", "周日")
private val timeSlots = listOf(
    "08:00", "08:50", "09:40", "10:30", "11:20", "12:10",
    "14:00", "14:50", "15:40", "16:30", "17:20", "18:10",
    "19:00", "19:50", "20:40"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WeekViewScreen(
    navController: NavController,
    viewModel: CourseViewModel
) {
    val courseListUiState by viewModel.courseListUiState.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("📅 周视图课表", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "返回")
                    }
                },
                actions = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.DateRange, contentDescription = "列表视图")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (val state = courseListUiState) {
                is CourseListUiState.Loading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("加载中...", style = MaterialTheme.typography.bodyLarge)
                    }
                }
                is CourseListUiState.Success -> {
                    WeekGridView(courses = state.courses)
                }
                is CourseListUiState.Empty -> {
                    EmptyView(message = "📋 还没有课程\n添加课程后将在此显示周视图")
                }
                is CourseListUiState.Error -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(state.message, color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }
}

@Composable
private fun WeekGridView(courses: List<CourseEntity>) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(8.dp)
    ) {
        // 表头：星期标题行
        item {
            Row(
                modifier = Modifier.fillMaxWidth()
            ) {
                // 时间列占位
                Box(
                    modifier = Modifier
                        .weight(0.6f)
                        .padding(2.dp)
                ) {
                    Text(
                        "时间",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                // 7天
                dayNames.forEachIndexed { index, day ->
                    val dayColor = CourseColors.getOrElse(index) { Color.Gray }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .padding(2.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(dayColor.copy(alpha = 0.15f))
                            .padding(vertical = 8.dp)
                    ) {
                        Text(
                            text = day,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = dayColor,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }

        // 时间槽行
        items(timeSlots) { time ->
            Row(
                modifier = Modifier.fillMaxWidth()
            ) {
                // 时间标签
                Box(
                    modifier = Modifier
                        .weight(0.6f)
                        .padding(2.dp)
                        .height(36.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = time,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 10.sp
                    )
                }
                // 7天
                for (day in 1..7) {
                    val dayColor = CourseColors.getOrElse(day - 1) { Color.Gray }
                    val courseAtSlot = courses.find {
                        it.dayOfWeek == day &&
                        it.startTime <= time &&
                        it.endTime > time
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .padding(2.dp)
                            .height(36.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .then(
                                if (courseAtSlot != null) {
                                    Modifier.background(dayColor.copy(alpha = 0.7f))
                                } else {
                                    Modifier
                                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                                        .border(
                                            0.5.dp,
                                            MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f),
                                            RoundedCornerShape(4.dp)
                                        )
                                }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (courseAtSlot != null) {
                            Text(
                                text = courseAtSlot.courseName.take(3),
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                fontSize = 8.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }
    }
}
