package com.example.qimo.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "user_preferences")

class UserPreferencesRepository(private val context: Context) {
    // 保存当前选中的学期ID
    private val CURRENT_SEMESTER_ID = intPreferencesKey("current_semester_id")
    // 保存主题偏好（是否跟随系统/强制深色模式）
    private val DARK_MODE_ENABLED = booleanPreferencesKey("dark_mode_enabled")

    // 获取当前学期ID
    fun getCurrentSemesterId(): Flow<Int?> = context.dataStore.data
        .map { preferences ->
            preferences[CURRENT_SEMESTER_ID]
        }

    // 保存当前学期ID
    suspend fun saveCurrentSemesterId(semesterId: Int) {
        context.dataStore.edit { preferences ->
            preferences[CURRENT_SEMESTER_ID] = semesterId
        }
    }

    // 获取深色模式偏好
    fun getDarkModeEnabled(): Flow<Boolean> = context.dataStore.data
        .map { preferences ->
            preferences[DARK_MODE_ENABLED] ?: false
        }

    // 保存深色模式偏好
    suspend fun saveDarkModePreference(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[DARK_MODE_ENABLED] = enabled
        }
    }
}
