package com.example.qimo.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.qimo.data.entity.CourseEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CourseDao {
    // 查询指定学期的所有课程（按星期和开始时间排序）
    @Query("SELECT * FROM courses WHERE semesterId = :semesterId ORDER BY dayOfWeek, startTime")
    fun getCoursesBySemester(semesterId: Int): Flow<List<CourseEntity>>

    // 搜索课程（模糊查询）
    @Query("SELECT * FROM courses WHERE courseName LIKE '%' || :keyword || '%' OR teacher LIKE '%' || :keyword || '%'")
    fun searchCourses(keyword: String): Flow<List<CourseEntity>>

    // 根据ID查询单条课程
    @Query("SELECT * FROM courses WHERE id = :courseId")
    suspend fun getCourseById(courseId: Int): CourseEntity?

    // 冲突检测：同一天、同一学期、时间重叠的课程
    @Query("""
        SELECT * FROM courses 
        WHERE dayOfWeek = :dayOfWeek 
        AND semesterId = :semesterId
        AND startTime < :endTime 
        AND endTime > :startTime
    """)
    suspend fun getConflictingCourses(dayOfWeek: Int, startTime: String, endTime: String, semesterId: Int): List<CourseEntity>

    @Insert
    suspend fun insertCourse(course: CourseEntity)

    @Update
    suspend fun updateCourse(course: CourseEntity)

    @Delete
    suspend fun deleteCourse(course: CourseEntity)

    // ========== 离线缓存操作（CourseInfoEntity） ==========
    @Insert
    suspend fun insertCourseInfo(courseInfo: CourseInfoEntity)

    @Query("SELECT * FROM course_info_cache WHERE id = :id")
    suspend fun getCachedCourseInfo(id: String): CourseInfoEntity?

    @Query("SELECT * FROM course_info_cache")
    suspend fun getAllCachedCourseInfo(): List<CourseInfoEntity>

    @Query("DELETE FROM course_info_cache")
    suspend fun clearAllCourseInfo()
}
