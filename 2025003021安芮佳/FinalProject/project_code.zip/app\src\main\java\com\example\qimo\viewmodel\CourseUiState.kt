package com.example.qimo.viewmodel

import com.example.qimo.data.entity.CourseEntity
import com.example.qimo.data.entity.SemesterEntity
import com.example.qimo.data.network.dto.CourseInfoDto

// 课程列表UI状态
sealed interface CourseListUiState {
    object Loading : CourseListUiState
    data class Success(val courses: List<CourseEntity>, val semesters: List<SemesterEntity>) : CourseListUiState
    data class Error(val message: String) : CourseListUiState
    object Empty : CourseListUiState
}

// 课程详情UI状态
sealed interface CourseDetailUiState {
    object Loading : CourseDetailUiState
    data class Success(
        val course: CourseEntity,
        val courseInfo: CourseInfoDto?,
        val isOffline: Boolean = false
    ) : CourseDetailUiState
    data class Error(val message: String) : CourseDetailUiState
}

// 网络课程列表UI状态
sealed interface HotCourseUiState {
    object Loading : HotCourseUiState
    data class Success(
        val courses: List<CourseInfoDto>,
        val isOffline: Boolean = false
    ) : HotCourseUiState
    data class Error(val message: String) : HotCourseUiState
}
