package com.example.qimo.data.network

import com.example.qimo.data.network.dto.CourseInfoDto
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path

interface ApiService {
    // 获取课程详情（模拟网络请求）
    @GET("courseInfo/{courseId}")
    suspend fun getCourseInfo(@Path("courseId") courseId: String): Response<CourseInfoDto>

    // 获取热门课程列表
    @GET("courseInfo")
    suspend fun getHotCourses(): Response<List<CourseInfoDto>>

    companion object {
        private const val BASE_URL = "https://660f2f69b625bf088c094038.mockapi.io/api/v1/"

        fun create(): ApiService {
            return Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(ApiService::class.java)
        }
    }
}