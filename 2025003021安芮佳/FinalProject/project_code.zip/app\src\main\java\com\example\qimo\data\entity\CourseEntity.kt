package com.example.qimo.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "courses")
data class CourseEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val courseName: String,
    val teacher: String,
    val credit: Float,
    val dayOfWeek: Int, // 1-7 代表周一到周日
    val startTime: String,
    val endTime: String,
    val semesterId: Int, // 关联Semester表
    val createdTime: Long = System.currentTimeMillis()
)