package com.example.qimo.data.dao

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.qimo.data.network.dto.CourseInfoDto

// 缓存表：存储从网络获取的课程信息
@Entity(tableName = "course_info_cache")
data class CourseInfoEntity(
    @PrimaryKey val id: String,
    val courseName: String,
    val teacher: String,
    val description: String?,
    val credit: Float,
    val rating: Float?,
    val coverUrl: String
) {
    fun toDto(): CourseInfoDto = CourseInfoDto(
        id = id,
        courseName = courseName,
        teacher = teacher,
        description = description ?: "",
        credit = credit,
        rating = rating ?: 0f,
        coverUrl = coverUrl
    )
}

fun CourseInfoDto.toEntity(): CourseInfoEntity = CourseInfoEntity(
    id = id,
    courseName = courseName,
    teacher = teacher,
    description = description.ifBlank { null },
    credit = credit,
    rating = rating,
    coverUrl = coverUrl
)
