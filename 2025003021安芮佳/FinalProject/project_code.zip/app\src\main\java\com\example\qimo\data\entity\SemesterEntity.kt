package com.example.qimo.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "semesters")
data class SemesterEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val semesterName: String, // 如 "2024-2025学年第一学期"
    val isCurrent: Boolean = false, // 是否当前学期
    val startDate: Long, // 开学时间戳
    val endDate: Long // 结束时间戳
)