package com.example.qimo.ui.theme

import androidx.compose.ui.graphics.Color

// 主色 — 清新蓝紫
val PrimaryLight = Color(0xFF4A6CF7)       // 亮蓝
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFFDDE3FF)
val OnPrimaryContainerLight = Color(0xFF001452)

val SecondaryLight = Color(0xFF585E71)
val OnSecondaryLight = Color(0xFFFFFFFF)
val SecondaryContainerLight = Color(0xFFDDE2F9)
val OnSecondaryContainerLight = Color(0xFF151B2C)

val TertiaryLight = Color(0xFF735572)
val OnTertiaryLight = Color(0xFFFFFFFF)
val TertiaryContainerLight = Color(0xFFFED7FA)
val OnTertiaryContainerLight = Color(0xFF2A132C)

val BackgroundLight = Color(0xFFF9F9FF)
val OnBackgroundLight = Color(0xFF191C20)
val SurfaceLight = Color(0xFFF9F9FF)
val OnSurfaceLight = Color(0xFF191C20)
val SurfaceVariantLight = Color(0xFFE1E2EC)
val OnSurfaceVariantLight = Color(0xFF44474E)

val ErrorLight = Color(0xFFBA1A1A)
val OnErrorLight = Color(0xFFFFFFFF)

// 深色主题
val PrimaryDark = Color(0xFFB6C4FF)
val OnPrimaryDark = Color(0xFF00206E)
val PrimaryContainerDark = Color(0xFF2E4FD3)
val OnPrimaryContainerDark = Color(0xFFDDE3FF)

val SecondaryDark = Color(0xFFC1C6DD)
val OnSecondaryDark = Color(0xFF2A3042)
val SecondaryContainerDark = Color(0xFF404659)
val OnSecondaryContainerDark = Color(0xFFDDE2F9)

val TertiaryDark = Color(0xFFE1BBDD)
val OnTertiaryDark = Color(0xFF412742)
val TertiaryContainerDark = Color(0xFF5A3E5A)
val OnTertiaryContainerDark = Color(0xFFFED7FA)

val BackgroundDark = Color(0xFF111318)
val OnBackgroundDark = Color(0xFFE2E2E9)
val SurfaceDark = Color(0xFF111318)
val OnSurfaceDark = Color(0xFFE2E2E9)
val SurfaceVariantDark = Color(0xFF44474E)
val OnSurfaceVariantDark = Color(0xFFC4C6D0)

val ErrorDark = Color(0xFFFFB4AB)
val OnErrorDark = Color(0xFF690005)

// 课程卡片颜色（星期对应的颜色）
val CourseColors = listOf(
    Color(0xFF6366F1), // 周一 靛蓝
    Color(0xFF8B5CF6), // 周二 紫
    Color(0xFF06B6D4), // 周三 青
    Color(0xFF10B981), // 周四 翠绿
    Color(0xFFF59E0B), // 周五 琥珀
    Color(0xFFEF4444), // 周六 红
    Color(0xFFEC4899), // 周日 粉
)
