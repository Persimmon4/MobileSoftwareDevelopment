package com.example.qimo.ui.theme.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.example.qimo.data.entity.CourseEntity
import com.example.qimo.viewmodel.CourseListUiState
import com.example.qimo.viewmodel.CourseViewModel

private val timeOptions = listOf(
    "08:00", "08:50", "09:40", "10:30",
    "11:20", "12:10",
    "14:00", "14:50", "15:40", "16:30",
    "17:20", "18:10",
    "19:00", "19:50", "20:40"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddCourseScreen(
    navController: NavController,
    viewModel: CourseViewModel,
    editCourseId: Int? = null  // 如果非 null，则为编辑模式
) {
    BackHandler {
        navController.popBackStack()
    }

    val isEditMode = editCourseId != null

    val currentSemester by viewModel.courseListUiState.collectAsStateWithLifecycle()
    val conflictMsg by viewModel.conflictMessage.collectAsStateWithLifecycle()
    var semesterId = 1
    if (currentSemester is CourseListUiState.Success) {
        semesterId = (currentSemester as CourseListUiState.Success)
            .semesters.firstOrNull { it.isCurrent }?.id ?: 1
    }

    var courseName by remember { mutableStateOf("") }
    var teacherName by remember { mutableStateOf("") }
    var creditValue by remember { mutableStateOf("") }
    var dayValue by remember { mutableStateOf("") }

    var startTimeShow by remember { mutableStateOf(false) }
    var endTimeShow by remember { mutableStateOf(false) }
    var startTimeValue by remember { mutableStateOf("") }
    var endTimeValue by remember { mutableStateOf("") }

    var errorMessage by remember { mutableStateOf("") }
    var isDataLoaded by remember { mutableStateOf(false) }

    val snackbarHostState = remember { SnackbarHostState() }
    val successMsg by viewModel.successMessage.collectAsStateWithLifecycle()

    // 清除冲突消息
    LaunchedEffect(Unit) {
        viewModel.clearConflict()
    }

    // 成功消息弹出 Snackbar 后自动返回
    LaunchedEffect(successMsg) {
        if (successMsg != null) {
            snackbarHostState.showSnackbar(successMsg!!)
            viewModel.clearSuccessMessage()
            navController.popBackStack()
        }
    }

    // 编辑模式：加载已有课程数据回填表单
    LaunchedEffect(editCourseId) {
        if (editCourseId != null && !isDataLoaded) {
            val course = viewModel.getCourseById(editCourseId)
            if (course != null) {
                courseName = course.courseName
                teacherName = course.teacher
                creditValue = course.credit.toString()
                dayValue = course.dayOfWeek.toString()
                startTimeValue = course.startTime
                endTimeValue = course.endTime
                semesterId = course.semesterId
                isDataLoaded = true
            }
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text(if (isEditMode) "修改课程" else "新增课程", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "返回")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 错误提示
            if (errorMessage.isNotEmpty()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = errorMessage,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }

            // 冲突提示
            if (conflictMsg != null) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Text("⚠️", style = MaterialTheme.typography.titleMedium)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "课程时间冲突",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = conflictMsg ?: "",
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }

            // 基本信息卡片
            SectionCard(title = "📚 课程信息") {
                FormField(
                    value = courseName,
                    onValueChange = { courseName = it; errorMessage = ""; viewModel.clearConflict() },
                    label = "课程名称",
                    placeholder = "如：高等数学",
                    icon = Icons.Filled.Edit,
                    isError = courseName.isEmpty() && errorMessage.isNotEmpty()
                )
                Spacer(modifier = Modifier.height(12.dp))
                FormField(
                    value = teacherName,
                    onValueChange = { teacherName = it; errorMessage = ""; viewModel.clearConflict() },
                    label = "授课教师",
                    placeholder = "如：张教授",
                    icon = Icons.Filled.Person,
                    isError = teacherName.isEmpty() && errorMessage.isNotEmpty()
                )
                Spacer(modifier = Modifier.height(12.dp))
                Row(modifier = Modifier.fillMaxWidth()) {
                    FormField(
                        value = creditValue,
                        onValueChange = { creditValue = it; errorMessage = ""; viewModel.clearConflict() },
                        label = "学分",
                        placeholder = "如：2.0",
                        icon = Icons.Filled.Star,
                        keyboardType = KeyboardType.Number,
                        isError = creditValue.isEmpty() && errorMessage.isNotEmpty(),
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    FormField(
                        value = dayValue,
                        onValueChange = { dayValue = it; errorMessage = ""; viewModel.clearConflict() },
                        label = "星期几",
                        placeholder = "1-7",
                        icon = Icons.Filled.DateRange,
                        keyboardType = KeyboardType.Number,
                        isError = dayValue.isEmpty() && errorMessage.isNotEmpty(),
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // 时间选择卡片
            SectionCard(title = "🕐 上课时间") {
                DropdownFormField(
                    value = startTimeValue,
                    label = "开始时间",
                    expanded = startTimeShow,
                    onExpandChange = { startTimeShow = it },
                    isError = startTimeValue.isEmpty() && errorMessage.isNotEmpty(),
                    options = timeOptions,
                    onOptionSelected = {
                        startTimeValue = it
                        startTimeShow = false
                        errorMessage = ""
                        viewModel.clearConflict()
                    }
                )
                Spacer(modifier = Modifier.height(12.dp))
                DropdownFormField(
                    value = endTimeValue,
                    label = "结束时间",
                    expanded = endTimeShow,
                    onExpandChange = { endTimeShow = it },
                    isError = endTimeValue.isEmpty() && errorMessage.isNotEmpty(),
                    options = timeOptions,
                    onOptionSelected = {
                        endTimeValue = it
                        endTimeShow = false
                        errorMessage = ""
                        viewModel.clearConflict()
                    }
                )
            }

            // 保存按钮
            Button(
                onClick = {
                    val dayInt = dayValue.toIntOrNull()
                    val creditFloat = creditValue.toFloatOrNull()

                    when {
                        courseName.isEmpty() -> errorMessage = "请输入课程名称"
                        teacherName.isEmpty() -> errorMessage = "请输入授课教师"
                        creditValue.isEmpty() -> errorMessage = "请输入学分"
                        creditFloat == null -> errorMessage = "请输入有效的学分（如：2.0）"
                        creditFloat <= 0f -> errorMessage = "学分必须大于 0"
                        dayValue.isEmpty() -> errorMessage = "请选择星期几"
                        dayInt == null || dayInt !in 1..7 -> errorMessage = "星期几必须在 1-7 之间"
                        startTimeValue.isEmpty() -> errorMessage = "请选择上课开始时间"
                        endTimeValue.isEmpty() -> errorMessage = "请选择下课时间"
                        startTimeValue >= endTimeValue -> errorMessage = "开始时间必须早于结束时间"
                        else -> {
                            errorMessage = ""
                            viewModel.clearConflict()
                            val course = CourseEntity(
                                id = editCourseId ?: 0,
                                courseName = courseName,
                                teacher = teacherName,
                                credit = creditFloat,
                                dayOfWeek = dayInt,
                                startTime = startTimeValue,
                                endTime = endTimeValue,
                                semesterId = semesterId
                            )
                            if (isEditMode) {
                                viewModel.updateCourseWithConflict(
                                    course = course,
                                    onConflict = { _ -> }
                                )
                            } else {
                                viewModel.addCourse(
                                    course = course,
                                    onConflict = { _ -> }
                                )
                            }
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary
                )
            ) {
                Text(
                    if (isEditMode) "✏️ 更新课程" else "💾 保存课程",
                    style = MaterialTheme.typography.titleSmall
                )
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

// 监听冲突结果，无冲突时自动返回
@Composable
fun HandleConflictNavigation(
    viewModel: CourseViewModel,
    navController: NavController
) {
    val conflictMsg by viewModel.conflictMessage.collectAsStateWithLifecycle()
    val courseListState by viewModel.courseListUiState.collectAsStateWithLifecycle()

    LaunchedEffect(courseListState) {
        // 如果课程列表变为非空 Success，说明添加成功
        if (courseListState is CourseListUiState.Success) {
            navController.popBackStack()
        }
    }
}

@Composable
fun SectionCard(
    title: String,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(16.dp))
            content()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FormField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    placeholder: String,
    icon: ImageVector,
    keyboardType: KeyboardType = KeyboardType.Text,
    isError: Boolean = false,
    modifier: Modifier = Modifier
) {
    TextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        placeholder = { Text(placeholder) },
        leadingIcon = {
            Icon(
                icon,
                contentDescription = null,
                tint = if (isError) MaterialTheme.colorScheme.error
                else MaterialTheme.colorScheme.onSurfaceVariant
            )
        },
        modifier = modifier,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        isError = isError,
        shape = RoundedCornerShape(12.dp),
        colors = TextFieldDefaults.colors(
            focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
        ),
        singleLine = true
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DropdownFormField(
    value: String,
    label: String,
    expanded: Boolean,
    onExpandChange: (Boolean) -> Unit,
    isError: Boolean,
    options: List<String>,
    onOptionSelected: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(
                indication = ripple(),
                interactionSource = remember { MutableInteractionSource() }
            ) { onExpandChange(true) }
    ) {
        TextField(
            value = if (value.isEmpty()) "" else value,
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            leadingIcon = {
                Icon(
                    Icons.Filled.DateRange,
                    contentDescription = null,
                    tint = if (isError) MaterialTheme.colorScheme.error
                    else MaterialTheme.colorScheme.onSurfaceVariant
                )
            },
            trailingIcon = {
                Icon(
                    Icons.Filled.ArrowDropDown,
                    contentDescription = null,
                    modifier = Modifier.size(24.dp)
                )
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = false,
            isError = isError,
            shape = RoundedCornerShape(12.dp),
            colors = TextFieldDefaults.colors(
                disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                disabledTextColor = MaterialTheme.colorScheme.onSurface,
                disabledLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledLeadingIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledTrailingIconColor = MaterialTheme.colorScheme.onSurfaceVariant
            )
        )
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { onExpandChange(false) }
        ) {
            options.forEach { time ->
                DropdownMenuItem(
                    text = {
                        Text(
                            time,
                            fontWeight = if (time == value) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    onClick = { onOptionSelected(time) }
                )
            }
        }
    }
}
