package com.example.qimo.data.network.dto

// 模拟课程信息API返回格式（使用Mock API：https://660f2f69b625bf088c094038.mockapi.io/api/v1/courseInfo）
data class CourseInfoDto(
    val id: String,
    val courseName: String,
    val teacher: String,
    val description: String,
    val credit: Float,
    val rating: Float, // 课程评分
    val coverUrl: String // 课程封面图
)